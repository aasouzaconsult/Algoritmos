package bank;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.sql.*;

public class ClientsDisplay extends JPanel {
	private JTable table;

	public ClientsDisplay() {
		setSize(700, 500);
	}

	public void display(Vector clients) {
		try {
			if (clients.size() == 0) {
				//JOptionPane.showMessageDialog(this, "Tabela de Clientes n�o possui registros.");
				return;
			}

			Vector columnHeads;
			Vector rows = new Vector();

			columnHeads = this.createColumnHeads();

			System.out.println("display ( clients.size()):" + clients.size());
			for (int i = 0; i < clients.size(); i++) {
				rows.addElement(getNextRow(clients, i));
			}


			this.removeAll(); //Limpa o Painel para imprimir novo Painel
			table = new JTable(rows, columnHeads);
			table.setSize(700, 500);
			JScrollPane scroller = new JScrollPane(table);
			this.add(scroller, BorderLayout.CENTER);
			validate();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	private Vector createColumnHeads() {
		Vector heads = new Vector();
		heads.addElement((String) "ID");
		heads.addElement((String) "Nome completo");
		heads.addElement((String) "Nome de usu�rio");
		heads.addElement((String) "Senha");
		heads.addElement((String) "CPF");
		heads.addElement((String) "R.G.");
		heads.addElement((String) "Endere�o");
		heads.addElement((String) "Telefone");

		return heads;
	}

	private Vector getNextRow(Vector clients, int i) {
		Vector currentRow = new Vector();
		currentRow.addElement((String) Integer.toString(((Client) clients.elementAt(i)).getId()));
		currentRow.addElement((String) ((Client) clients.elementAt(i)).getFullName());
		currentRow.addElement((String) ((Client) clients.elementAt(i)).getUserName());
		currentRow.addElement((String) ((Client) clients.elementAt(i)).getPassword());
		currentRow.addElement((String) ((Client) clients.elementAt(i)).getCPF());
		currentRow.addElement((String) ((Client) clients.elementAt(i)).getIdentity());
		currentRow.addElement((String) ((Client) clients.elementAt(i)).getAddress());
		currentRow.addElement((String) ((Client) clients.elementAt(i)).getPhone());

		return currentRow;
	}
}