package bank;

import java.sql.*;
import java.util.Vector;

public class Client {
	private Connection connection;
	private int id;
	private String userName;
	private String fullName;
	private String password;
	private String CPF;
	private String identity;
	private String address;
	private String phone;

	private java.util.Vector myAccounts;

	public Client(Connection connection) {
		this.init();
		this.connection = connection;

		this.myAccounts = new Vector();
	}

	private void init() {
		this.connection = null;
		this.id = -1;
		this.userName = "";
		this.fullName = "";
		this.password = "";
		this.identity = "";
		this.CPF = "";
		this.address = "";
		this.phone = "";
//		this.bankBox = null;
		this.myAccounts = null;
	}

	public int getId(){
		return this.id;
	}
	
	public String getUserName() {
		return this.userName;
	}

	public String getFullName() {
		return this.fullName;
	}
	
	public String getPassword() {
		return this.password;
	}
	
	public String getCPF() {
		return this.CPF;
	}
	
	public String getIdentity() {
		return this.identity;
	}
	
	public String getAddress() {
		return this.address;
	}
	
	public String getPhone() {
		return this.phone;
	}
	
	public Vector getAccounts() {
		return this.myAccounts;
	}

	//Ready
	public Vector loadAccounts() {
		try {
			this.myAccounts.clear();
			String sql = "SELECT * FROM ACCOUNTS WHERE CLIENT_ID = ?";
			PreparedStatement stm = this.connection.prepareStatement(sql);
			ResultSet rset = null;			

			stm.setInt(1, this.id );		
			rset = stm.executeQuery();
			
			while (rset.next()) {
				Account account = new Account(this.connection, this.id);
				account.setId(rset.getInt("ID"));				
				//account.setClientId(rset.getInt("CLIENT_ID"));				
				account.setType(rset.getString("ACTUAL_TYPE"));
				account.setValue(rset.getFloat("VALUE"));				
				account.setDescr(rset.getString("DESCR"));
				
				myAccounts.add(account);
			}

			rset.close();
			stm.close();
			
			if(myAccounts.size() == 0)
				System.out.println("Cliente [" + fullName +"] n�o possui conta no banco."); 
			else
				System.out.println("Cliente [" + fullName +"] n�o possui " + myAccounts.size() + " conta(s) no banco."); 				
		}
		catch (SQLException e) {
			System.out.println("Exception : " + e.toString());
		}
		return myAccounts;
	}
	
	public void removeAccount() {
		try {
			String sql = "DELETE FROM ACCOUNTS WHERE CLIENT_ID = ?";
			PreparedStatement stm = this.connection.prepareStatement(sql);

			stm.setInt(1, this.getId());
			stm.executeUpdate();
			stm.close();
		}
		catch (SQLException e) {
			System.out.println("Exception : " + e.toString());
		}
		this.loadAccounts();		
	}

	//ready
	public void save() {
		try {
			String sql =
				"UPDATE CLIENTS SET FULL_NAME = '"+ fullName + 
				"' , USER_NAME = '" + userName + 
				"' , PASSWORD = '" + password + 
				"' , CPF = '" + CPF + 
				"' , IDENTITY = '"+ identity + 
				"' , ADDRESS = '" + address + 
				"' , PHONE = '"+ phone  +
				"' WHERE ID = "+ id;
				
					
			Statement stm = this.connection.createStatement();

			/*
			stm.setString(1, "1");//this.fullName);
			stm.setString(2, "1");//this.userName);
			stm.setString(3, "1");//this.password);
			stm.setString(4, "1");//this.CPF);
			stm.setString(5, "1");//this.identity);
			stm.setString(6, "1");//this.address);
			stm.setString(7, "1");//this.phone);
			stm.setInt(8, 1);//this.id);						
			*/
			
			System.out.println(sql);
			stm.executeUpdate(sql);
			stm.close();
		}
		catch (SQLException e) {
			System.out.println("Exception : " + e.toString());
		}
	}

	public void setId(int id ) {
		this.id = id;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;		
	}
	
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setCPF(String CPF) {
		this.CPF = CPF;
	}
	
	public void setIdentity(String identity) {
		this.identity = identity;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}

}