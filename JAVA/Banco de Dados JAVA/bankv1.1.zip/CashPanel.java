package bank;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CashPanel extends JPanel implements ActionListener {
	private JButton put, get, logOut, clear;
	private JPanel buttonsPanel, labelsPanel, fieldsPanel;
	private String labels[] = { "n�mero da conta:", "Valor:" };

	private JTextField accountId, value;
	private JTextArea textArea;
	private BankBox bankBox;

	private int clientId;

	public CashPanel(BankBox bankBox, int clientId) {
		super();
		this.clientId = clientId;
		this.bankBox = bankBox;

		textArea = new JTextArea(20, 50);

		buttonsPanel = new JPanel();
		buttonsPanel.setLayout(new GridLayout(1, 2));

		buttonsPanel.add(put = new JButton("::Depositar"));
		buttonsPanel.add(get = new JButton("::sacar"));
		buttonsPanel.add(logOut = new JButton("::sair"));
		buttonsPanel.add(clear = new JButton("::limpar"));

		buttonsPanel.setSize(100, 20);

		get.addActionListener(this);
		put.addActionListener(this);
		logOut.addActionListener(this);
		clear.addActionListener(this);

		// Label panel
		labelsPanel = new JPanel();
		labelsPanel.setLayout(new GridLayout(labels.length, 1));

		ImageIcon ii = new ImageIcon("icon.jpg");

		for (int i = 0; i < labels.length; i++)
			labelsPanel.add(new JLabel(labels[i], ii, 0));

		// TextField panel
		fieldsPanel = new JPanel();
		fieldsPanel.setLayout(new GridLayout(labels.length, 1));

		accountId = new JTextField(35);
		fieldsPanel.add(accountId);

		value = new JTextField(35);
		fieldsPanel.add(value);

		JPanel panelCenter = new JPanel(new BorderLayout());
		panelCenter.add(labelsPanel, BorderLayout.CENTER);
		panelCenter.add(fieldsPanel, BorderLayout.EAST);

		JScrollPane scroller = new JScrollPane(textArea);
		setLayout(new BorderLayout());

		add(buttonsPanel, BorderLayout.NORTH);
		add(panelCenter, BorderLayout.CENTER);
		add(scroller, BorderLayout.SOUTH);

		setSize(350, 300);

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == put) {
			boolean error = false;
			String id = accountId.getText().trim();

			if (id == null || id.equals("")) {
				value.setText("Digite um n�mero de conta!");
				error = true;
			}

			String money = value.getText().trim();
			if (value == null || value.equals("")) {
				value.setText("Digite um password");
				error = true;
			}

			if (!error) {
				textArea.setText("Efetuando dep�sito...\n");
				Account account = bankBox.loadAccount(Integer.parseInt(id));
				if (account != null) {
					account.setValue((double) account.getValue() + ((double) Double.parseDouble(money)));
					account.save();
					bankBox.refreshTables();
					textArea.setText("Dep�sito efetuado com sucesso!");
				}
				else {
					textArea.append("Conta n�mero " + id + " n�o encontrada.\n");
					this.clearFields();
				}
			}
		}
		else if (e.getSource() == get) {
			boolean error = false;
			String id = accountId.getText().trim();

			if (id == null || id.equals("")) {
				value.setText("Digite um n�mero de conta!");
				error = true;
			}

			String money = value.getText().trim();
			if (value == null || value.equals("")) {
				value.setText("Digite um password");
				error = true;
			}

			if (!error) {
				textArea.setText("Efetuando saque...\n");

				Account account = bankBox.loadAccount(Integer.parseInt(id));
				if (account != null) {
					if (account.getClientId() == this.clientId) {
						if (account.getValue() >= Double.parseDouble(money)) {
							account.setValue((double) account.getValue() - ((double) Double.parseDouble(money)));
							account.save();
							bankBox.refreshTables();
							textArea.setText("Saque efetuado com sucesso!");
						}
						else {
							textArea.append("Sua conta n�o possui saldo suficiente para efetuar este saque.\n Saldo atual: " + account.getValue());
						}
					}
					else {						
						textArea.append("Esta conta n�o lhe pertence. Saque de um conta em seu nome.");
					}
				}
				else {
					textArea.append("Conta n�mero " + id + " n�o encontrada.\n");
					this.clearFields();
				}
			}

		}
		else if (e.getSource() == clear) {
			clearFields();
		}
		else if (e.getSource() == logOut) {
			clearFields();
			showLoginPanel();
		}
	}

	private void showLoginPanel() {
		this.removeAll();
		LoginPanel lp = new LoginPanel(bankBox);
		add(lp);
	}
	public void clearFields() {
		accountId.setText(null);
		value.setText(null);
	}

}