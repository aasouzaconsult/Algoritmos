package bank;

import java.sql.*;
import java.util.Vector;

public class Account {
	private Connection connection;
	private int id;
	private int clientId;
	private String type;
	private double value;
	private String descr;

	public Account(Connection connection, int clientId) {
		this.connection = connection;
		this.clientId = clientId;

	}
	
	public Account(Connection connection) {
		this.connection = connection;
	}

	protected void init() {
		this.connection = null;
		this.id = -1;
		this.clientId = -1;
		this.type = null;
		this.value = -1;
		this.descr = "";
	}

	public int getId() {
		return this.id;
	}

	public int getClientId() {
		return this.clientId;
	}

	public String getType() {
		return this.type;
	}
	
	public String getDescr(){
		return this.descr;
	}
	
	public double getValue(){
		return this.value;
	}

	public void save() {
		try {
			String sql = "UPDATE ACCOUNTS SET CLIENT_ID = "+id+", ACTUAL_TYPE = '"+type+"', ACTUAL_VALUE = "+value+", DESCR = '"+descr+"' WHERE ID = "+id;
			System.out.println(sql);
						 
			Statement stm = this.connection.createStatement();

			stm.executeUpdate(sql);
			stm.close();

			this.connection.commit();
		}
		catch (SQLException e) {
			System.out.println("Exception : " + e.toString());
		}
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setClientId(int clientId) {
		this.clientId = clientId;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public void setValue(double value) {
		this.value = value;
	}
	
	public void setDescr(String descr) {
		this.descr = descr;
	}
	


}