package bank;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ClientsFieldsPanel extends JPanel implements ActionListener {
	private JButton find, add, edit, delete, clear;
	private JPanel labelPanel, fieldsPanel, buttonsPanel;
	private String labels[] = { "ID:", "Nome de usu�rio:", "Nome completo:", "Password:", "CPF:", "R.G.:", "Endere�o:", "Telefone:" };
	private JTextField id, fullName, userName, password, CPF, identity, address, phone;
	private JTextArea textArea;
	private BankBox bankBox;

	public ClientsFieldsPanel(BankBox bankBox) {
		super();
		this.bankBox = bankBox;

		textArea = new JTextArea(10, 50);

		buttonsPanel = new JPanel();
		buttonsPanel.setLayout(new GridLayout(1, 5));

		buttonsPanel.add(find = new JButton("Procurar"));
		buttonsPanel.add(add = new JButton("Adicionar"));
		buttonsPanel.add(edit = new JButton("Editar"));
		buttonsPanel.add(delete = new JButton("Deletar"));
		buttonsPanel.add(clear = new JButton("Limpar"));
		buttonsPanel.setSize(100, 20);

		find.addActionListener(this);
		add.addActionListener(this);
		edit.addActionListener(this);
		delete.addActionListener(this);
		clear.addActionListener(this);

		// Label panel
		labelPanel = new JPanel();
		labelPanel.setLayout(new GridLayout(labels.length, 1));

		ImageIcon ii = new ImageIcon("icon.jpg");

		for (int i = 0; i < labels.length; i++)
			labelPanel.add(new JLabel(labels[i], ii, 0));

		// TextField panel
		fieldsPanel = new JPanel();
		fieldsPanel.setLayout(new GridLayout(labels.length, 1));

		id = new JTextField(35);
		//		id.setEditable(false);
		fieldsPanel.add(id);

		userName = new JTextField(35);
		fieldsPanel.add(userName);

		fullName = new JTextField(35);
		fieldsPanel.add(fullName);

		password = new JTextField(35);
		fieldsPanel.add(password);

		CPF = new JTextField(35);
		fieldsPanel.add(CPF);

		identity = new JTextField(35);
		fieldsPanel.add(identity);

		address = new JTextField(35);
		fieldsPanel.add(address);

		phone = new JTextField(35);
		fieldsPanel.add(phone);

		JPanel panelCenter = new JPanel(new BorderLayout());
		panelCenter.add(labelPanel, BorderLayout.CENTER);
		panelCenter.add(fieldsPanel, BorderLayout.EAST);

		JScrollPane scroller = new JScrollPane(textArea);
		setLayout(new BorderLayout());

		add(buttonsPanel, BorderLayout.NORTH);
		add(panelCenter, BorderLayout.CENTER);
		add(scroller, BorderLayout.SOUTH);

		setSize(350, 300);

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == find) {
			String str = userName.getText();
			if (str == null || str.equals(""))
				userName.setText("Digite um username");

			textArea.setText("Procurando cliente: " + str + "...\n");

			Client client = bankBox.loadClient((String) userName.getText());
			if (client != null)
				setFields(client.getId(), client.getUserName(), client.getFullName(), client.getPassword(), client.getCPF(), client.getIdentity(), client.getAddress(), client.getPhone());
			else {
				textArea.append("Cliente: " + str + " n�o encontrado\n");
				this.clearFields();
			}

		}
		else if (e.getSource() == add) {
			textArea.append("Adicionando cliente: " + userName.getText() + "...\n");
			Client client =
				bankBox.addClient(fullName.getText().trim(), userName.getText().trim(), password.getText().trim(), CPF.getText().trim(), identity.getText().trim(), address.getText().trim(), phone.getText().trim());
			if (client == null)
				textArea.append("N�o foi poss�vel adicionar o cliente: " + userName.getText().trim() + ".\n Preencha todos os campos ou tente outro username.");

		}
		else if (e.getSource() == edit) {
			textArea.setText("Editando cliente: " + userName.getText() + "...\n");
			Client client = new Client(bankBox.getConnection());
			client.setId(Integer.parseInt(id.getText().trim()));
			client.setFullName(fullName.getText().trim());
			client.setUserName(userName.getText().trim());
			client.setPassword(password.getText().trim());
			client.setCPF(CPF.getText().trim());
			client.setIdentity(identity.getText().trim());
			client.setAddress(address.getText().trim());
			client.setPhone(phone.getText().trim());

			client.save();
			textArea.append("Cliente: " + client.getUserName() + " salvo c/ sucesso.\n");
		}
		else if (e.getSource() == delete) {
			textArea.setText("Deletando cliente com id: " + id.getText() + "...\n");
			if (id.getText().trim() == null || id.getText().trim().equals("")) {
				id.setText("Digite um id!");
			}
			else {
				if (bankBox.removeClient(Integer.parseInt(id.getText().trim())))
					textArea.append("Client: " + id.getText() + " deletado c/ sucesso!\n");
				else
					textArea.append("N�o foi poss�vel deletar o Cliente: " + id.getText() + "!\n");
			}
		}
		else if (e.getSource() == clear) {
			clearFields();
		}
	}

	private void setFields(int id, String user, String full, String pass, String cpf, String rg, String address, String phone) {

		this.id.setText((String) Integer.toString(id).trim());
		this.userName.setText((String) user.trim());
		this.fullName.setText((String) full.trim());
		this.password.setText((String) pass.trim());
		this.CPF.setText((String) cpf.trim());
		this.identity.setText((String) rg.trim());
		this.address.setText((String) address.trim());
		this.phone.setText((String) phone.trim());

	}

	public void clearFields() {
		textArea.setText(null);
		id.setText(null);
		userName.setText(null);
		fullName.setText(null);
		password.setText(null);
		CPF.setText(null);
		identity.setText(null);
		address.setText(null);
		phone.setText(null);
	}

}