package bank;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class AccountsFieldsPanel extends JPanel implements ActionListener {
	private JButton find, add, edit, delete, clear;
	private JPanel labelPanel, fieldsPanel, buttonsPanel;
	private String labels[] = { "ID:", "ID do cliente:", "Tipo:", "Descri��o:", "Valor:" };
	private JTextField id, clientId, type, value, descr;
	private JTextArea textArea;
	private BankBox bankBox;

	public AccountsFieldsPanel(BankBox bankBox) {
		super();
		this.bankBox = bankBox;

		textArea = new JTextArea(16, 50);

		buttonsPanel = new JPanel();
		buttonsPanel.setLayout(new GridLayout(1, 5));

		buttonsPanel.add(find = new JButton("Procurar"));
		buttonsPanel.add(add = new JButton("Adicionar"));
		buttonsPanel.add(edit = new JButton("Editar"));
		buttonsPanel.add(delete = new JButton("Deletar"));
		buttonsPanel.add(clear = new JButton("Limpar"));
		buttonsPanel.setSize(100, 20);

		find.addActionListener(this);
		add.addActionListener(this);
		edit.addActionListener(this);
		delete.addActionListener(this);
		clear.addActionListener(this);

		// Label panel
		labelPanel = new JPanel();
		labelPanel.setLayout(new GridLayout(labels.length, 1));

		ImageIcon ii = new ImageIcon("icon.jpg");

		for (int i = 0; i < labels.length; i++)
			labelPanel.add(new JLabel(labels[i], ii, 0));

		// TextField panel
		fieldsPanel = new JPanel();
		fieldsPanel.setLayout(new GridLayout(labels.length, 1));

		id = new JTextField(35);
		fieldsPanel.add(id);

		clientId = new JTextField(35);
		fieldsPanel.add(clientId);

		type = new JTextField(35);
		fieldsPanel.add(type);

		descr = new JTextField(35);
		fieldsPanel.add(descr);

		value = new JTextField(35);
		fieldsPanel.add(value);

		JPanel panelCenter = new JPanel(new BorderLayout());
		panelCenter.add(labelPanel, BorderLayout.CENTER);
		panelCenter.add(fieldsPanel, BorderLayout.EAST);

		JScrollPane scroller = new JScrollPane(textArea);
		setLayout(new BorderLayout());

		add(buttonsPanel, BorderLayout.NORTH);
		add(panelCenter, BorderLayout.CENTER);
		add(scroller, BorderLayout.SOUTH);

		setSize(350, 300);

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == find) {
			String str = id.getText();
			if (str == null || str.equals(""))
				id.setText("Digite um id");
			else {
				textArea.setText("Procurando conta: " + str + "...\n");

				Account account = bankBox.loadAccount((int) Integer.parseInt(id.getText().trim()));
				if (account != null)
					setFields(account.getId(), account.getClientId(), account.getType(), account.getValue(), account.getDescr());
				else{
					textArea.append("Conta: " + str + " n�o encontrada.\n");
					this.clearFields();
				}
			}

		} else if (e.getSource() == add) {
			textArea.append("Adicionando conta ao cliente: " + clientId.getText() + "...\n");
			Account account = bankBox.createAccount(Integer.parseInt(clientId.getText().trim()), type.getText().trim(), Double.parseDouble(value.getText().trim()), descr.getText());
			System.out.println(Integer.parseInt(clientId.getText().trim()));
			System.out.println(type.getText().trim());
			System.out.println(Double.parseDouble(value.getText().trim()));
			System.out.println(descr.getText().trim());
			if (account == null)
				textArea.append("N�o foi poss�vel adicionar a conta ao cliente: " + clientId.getText().trim() + ".\n Preencha todos os campos ou tente outro Id de cliente.");

		} else if (e.getSource() == edit) {
			textArea.setText("Editando conta: " + id.getText() + "...\n");
			Account account= new Account(bankBox.getConnection());
			
			account.setId(Integer.parseInt(id.getText().trim()));
			account.setClientId(Integer.parseInt(clientId.getText().trim()));
			account.setType(type.getText().trim());
			account.setDescr(descr.getText().trim());			
			account.setValue(Double.parseDouble(value.getText().trim()));
			
			account.save();
			
			textArea.append("Conta : " + account.getId() + " salvo c/ sucesso.\n");
			
		} else if (e.getSource() == delete) {
			textArea.setText("Deletando conta id: " + id.getText() + "...\n");
				if (bankBox.removeAccount(Integer.parseInt(id.getText().trim())))
					textArea.append("Conta: " + id.getText() + " deletada c/ sucesso!\n");
				else
					textArea.append("N�o foi poss�vel deletar a Conta: " + id.getText() + "!\n");
		} else if (e.getSource() == clear) {
			clearFields();
		}

	}

	private void setFields(int id, int clientId, String type, double value, String descr) {
		this.id.setText((String) Integer.toString(id).trim());
		this.clientId.setText((String) Integer.toString(clientId).trim());
		this.type.setText((String) type.trim());
		this.descr.setText((String) descr);
		this.value.setText((String) Double.toString(value).trim());
	}

	public void clearFields() {
		textArea.setText(null);
		id.setText(null);
		clientId.setText(null);
		type.setText(null);
		descr.setText(null);
		value.setText(null);
	}

}