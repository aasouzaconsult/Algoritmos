package bank;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.sql.*;

public class TotalsDisplay extends JPanel {
	private double money;
	private int clients;
	private int accounts;

	public TotalsDisplay() {
		setSize(600, 500);
	}

	public void display(double money, int clients, int accounts) {
		try {
			this.money = money;
			this.clients = clients;
			this.accounts = accounts;
			this.removeAll(); //Limpa o Painel para imprimir novo Painel									
			this.add(makeTextPanel(), BorderLayout.CENTER);
			validate();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private JPanel makeTextPanel() {
		JPanel panel = new JPanel(false);
		JLabel moneyLabel = new JLabel("Valor total: R$ "+ money);
		JLabel clientsLabel = new JLabel("Total de clientes: "+ clients);
		JLabel accountsLabel = new JLabel("Total de contas: "+ accounts);
		
		moneyLabel.setHorizontalAlignment(JLabel.LEFT);
		clientsLabel.setHorizontalAlignment(JLabel.LEFT);
		accountsLabel.setHorizontalAlignment(JLabel.LEFT);
		
		panel.setLayout(new GridLayout(8, 1));
		panel.add(new JLabel());//espa�o vazio
		panel.add(new JLabel());//espa�o vazio
		panel.add(new JLabel());//espa�o vazio
		panel.add(moneyLabel);
		panel.add(new JLabel());//espa�o vazio
		panel.add(clientsLabel);
		panel.add(new JLabel());//espa�o vazio
		panel.add(accountsLabel);				
		
		this.add(panel);
		
		return panel;
	}
		
	
	public void setMoney(double money){
		this.money = money;	
		this.removeAll();		
		this.makeTextPanel();
	}
	
	public void setAccounts(int accounts){
		this.accounts = accounts;	
		this.removeAll();		
		this.makeTextPanel();
	}
	
	public void setClients(int clients){
		this.clients = clients;
		this.removeAll();		
		this.makeTextPanel();
	}
}