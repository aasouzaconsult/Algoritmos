package bank;

import java.sql.*;
import java.sql.Date;
import java.util.Vector;

public class BankBox {
	private Connection connection;
	private Vector clients;
	private Vector accounts;
	private double totalMoney;
	private int qtAccounts;
	private int qtClients;

	private ClientsDisplay clientsTable;
	private AccountsDisplay accountsTable;
	private TotalsDisplay totalsPanel;
	private TabbedPane tabPane;
	private ClientsFieldsPanel clientsFields;
	private AccountsFieldsPanel accountsFields;
	private LoginPanel loginPanel;

	public BankBox() {
		this.init();
		this.getConnection();
		clients = new Vector();
		accounts = new Vector();

		clientsTable = new ClientsDisplay();
		accountsTable = new AccountsDisplay();
		totalsPanel = new TotalsDisplay();
		clientsFields = new ClientsFieldsPanel(this);
		accountsFields = new AccountsFieldsPanel(this);
		loginPanel = new LoginPanel(this);

		tabPane = new TabbedPane();
		
		tabPane.setClientsTab(clientsTable);
		tabPane.setAccountsTab(accountsTable);
		tabPane.setTotalsTab(totalsPanel);
		tabPane.setClientsFieldsTab(clientsFields);
		tabPane.setAccountsFieldsTab(accountsFields);
		tabPane.setLoginTab(loginPanel);
		
		tabPane.refreshWindow();
	}

	protected void init() {
		this.connection = null;
		this.clients = null;
		this.accounts = null;
		this.totalMoney = 0;
		this.qtAccounts = 0;
		this.qtClients = 0;

	}

	public Client addClient(String fullName, String userName, String password, String CPF, String identity, String address, String phone) {
		Client client = null;
		try {
			String sql = "SELECT ID FROM CLIENTS WHERE USER_NAME = TRIM(?)";
			PreparedStatement stm = this.connection.prepareStatement(sql);
			ResultSet rset = null;
			int countClients = 0;

			stm.setString(1, userName);
			rset = stm.executeQuery();
			while (rset.next())
				countClients++;

			rset.close();
			stm.close();

			if (countClients == 0) {
				sql = "INSERT INTO CLIENTS (USER_NAME, FULL_NAME, PASSWORD, CPF, IDENTITY, ADDRESS, PHONE)" + " VALUES(?, ?, ?, ?, ?, ?, ?)";
				stm = this.getConnection().prepareStatement(sql);
				stm.setString(1, userName);
				stm.setString(2, fullName);
				stm.setString(3, password);
				stm.setString(4, CPF);
				stm.setString(5, identity);
				stm.setString(6, address);
				stm.setString(7, phone);

				stm.executeUpdate();
				stm.close();
				this.getConnection().commit();

				client = new Client(this.getConnection());
				client.setUserName(userName);
				client.setFullName(fullName);
				client.setPassword(password);
				client.setCPF(CPF);
				client.setIdentity(identity);
				client.setAddress(address);
				client.setPhone(phone);

				this.clients.add(client);				
				
				refreshTables();				

				System.out.println("Cliente [" + fullName + "] adicionado!\n");
			}
			else {
				System.out.println("J� existe um cliente cadastrado com este username!\n Tente outro username\n.");
			}
		}
		catch (SQLException e) {
			System.out.println("Exception: " + e.toString() + "\n");
		}
		catch (Exception e) {
			System.out.println("Exception: " + e.toString() + "\n");
		}

		return client;
	}

	//cria nova conta e a retorna p/ que posse ser conferida ap�s a inser��o.
	public Account createAccount(int clientId, String type, double value, String descr) {
		Account retValue = null;
		try {
			//insere dados da nova conta no B.D.
			Statement stm = null;
			String sql = "INSERT INTO ACCOUNTS (CLIENT_ID, ACTUAL_TYPE, ACTUAL_VALUE, DESCR) VALUES ("+clientId+",'"+type+"',"+value+",'"+descr+"')";
			System.out.println(sql);
			stm = this.getConnection().createStatement();

			stm.executeUpdate(sql);
			System.out.println(sql);
			stm.close();
			this.getConnection().commit();

			//cria nova conta.
			Account account = new Account(this.getConnection(), clientId);
			account.setType(type);
			account.setValue(value);
			account.setDescr(descr);

			//adiciona conta criada ao vetor de contas.			
			this.accounts.add(account);			
			
			refreshTables();
			
			retValue = account;
			System.out.println("Conta criada c/ sucesso.\n");
		}
		catch (SQLException e) {
			System.out.println("ERRO : " + e.toString() + "\n");
		}
		
		return retValue;
	}

	//fecha conex�es com o Banco de dados e limpa o caixa.
	protected void finalize() {
		try {
			this.connection.close();
			this.connection = null;
			this.accounts.clear();
			this.clients.clear();
		}
		catch (SQLException e) {
			System.out.println("ERRO : " + e.toString() + "\n");
		}
	}

	//retorna conex�o com o B.D.
	public Connection getConnection() {
		if (this.connection == null)
			this.setConnection();

		return this.connection;

	}

	//seta uma nova conex�o, caso esta seja nula, cria conex�o padr�o.
	private void setConnection(Connection conn) {
		if (conn == null)
			this.setConnection();
		else
			this.connection = conn;
	}

	//cria conex�o padr�o.
	private void setConnection() {
		if (this.connection == null) {
			System.out.println("Setando conex�o...\n");
			String url = "jdbc:odbc:Bank";
			String username = "anonymous";
			String password = "guest";

			try {
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				this.connection = DriverManager.getConnection(url, username, password);
				this.connection.setAutoCommit(true);
			}
			catch (ClassNotFoundException e) {
				System.err.println("Falha ao tentar carregar o driver JDBC/ODBC: " + e.toString() + "\n");
			}
			catch (SQLException e) {
				System.err.println("N�o foi poss�vel conectar ao B.D.: " + e.toString() + "\n");
			}
			System.out.println("Conectado com Sucesso ao B.D. :" + url);
		}
	}

	//carrega os dados de todos os clientes e todas as contas do banco.
	public void load() {
		this.loadClients();
		this.loadAccounts();
	}

	//carrega os dados de todos os clientes do banco.
	private Vector loadClients() {
		try {
			String sql = "SELECT * FROM CLIENTS ORDER BY ID,FULL_NAME";
			Statement stm = this.connection.createStatement();
			ResultSet rSet = null;

			rSet = stm.executeQuery(sql);

			this.clients.clear();
			while (rSet.next()) {
				Client client = new Client(this.getConnection());
				client.setId(rSet.getInt("ID"));
				client.setUserName(rSet.getString("USER_NAME"));
				client.setFullName(rSet.getString("FULL_NAME"));
				client.setPassword(rSet.getString("PASSWORD"));
				client.setCPF(rSet.getString("CPF"));
				client.setIdentity(rSet.getString("IDENTITY"));
				client.setAddress(rSet.getString("ADDRESS"));
				client.setPhone(rSet.getString("PHONE"));

				this.clients.add(client);
			}

			System.out.println("Cliente(s) carregado(s): [" + clients.size() + "]\n");
			rSet.close();
			stm.close();
		}
		catch (SQLException e) {
			System.err.println("\n ERRO SQL: " + e.toString() + "\n");
		}

		clientsTable.display(clients);

		return this.clients;
	}
	
	public Client loadClient(String userName) {
		Client client = new Client(this.getConnection());
		try {
			System.out.println("bb procura: "+userName );
			String sql = "SELECT * FROM CLIENTS WHERE USER_NAME = TRIM('"+userName+"') ORDER BY ID";
			Statement stm = this.connection.createStatement();
			ResultSet rSet = null;

			rSet = stm.executeQuery(sql);

			if(rSet.next()) {			
				client.setId(rSet.getInt("ID"));
				client.setUserName(rSet.getString("USER_NAME"));
				client.setFullName(rSet.getString("FULL_NAME"));
				client.setPassword(rSet.getString("PASSWORD"));
				client.setCPF(rSet.getString("CPF"));
				client.setIdentity(rSet.getString("IDENTITY"));
				client.setAddress(rSet.getString("ADDRESS"));
				client.setPhone(rSet.getString("PHONE"));
			}
			else{
				System.out.println("Cliente n�o encontrado.");
				client = null;
			}

			rSet.close();
			stm.close();
		}
		catch (SQLException e) {
			System.err.println("\n ERRO SQL: " + e.toString() + "\n");
		}
		return client;
	}
	
	public boolean removeClient(int aId) {
		boolean ret = true;
		try {
			String sql = "DELETE  FROM CLIENTS WHERE ID = "+ aId;
			Statement stm = this.connection.createStatement();

			stm.execute(sql);
			stm.close();			
		}
		catch (SQLException e) {
			System.err.println("\n ERRO SQL: " + e.toString() + "\n");
			ret = false;
		}		
		this.refreshTables();
		return ret;
	}
	
	public boolean removeAccount(int aId) {
		boolean ret = false;
		try {
			String sql = "DELETE  FROM ACCOUNTS WHERE ID = "+ aId;
			Statement stm = this.connection.createStatement();

			stm.execute(sql);
			stm.close();
			ret = true;						
		}
		catch (SQLException e) {
			System.err.println("\n ERRO SQL: " + e.toString() + "\n");
			ret = false;
		}
		this.refreshTables();
		return ret;
	}



	//carrega os dados de todas as contas do banco.
	private Vector loadAccounts() {
		try {
			this.accounts.clear();
			String sql = "SELECT * FROM ACCOUNTS ORDER BY ID, CLIENT_ID";
			Statement stm = this.connection.createStatement();
			ResultSet rSet = null;

			rSet = stm.executeQuery(sql);

			while (rSet.next()) {
				Account account = new Account(this.getConnection(), -1);
				account.setId(rSet.getInt("ID"));
				account.setClientId(rSet.getInt("CLIENT_ID"));
				account.setType(rSet.getString("ACTUAL_TYPE"));
				account.setValue(rSet.getDouble("ACTUAL_VALUE"));
				account.setDescr(rSet.getString("DESCR"));

				this.accounts.add(account);
			}

			System.out.println("Conta(s) carregada(s): [" + accounts.size() + "]\n");
			rSet.close();
			stm.close();
		}
		catch (SQLException e) {
			System.err.println("\n ERRO SQL: " + e.toString() + "\n");
		}

		accountsTable.display(accounts);
		return this.accounts;
	}

	public Account loadAccount(int aId) {
		Account account = null;
		try {
			String sql = "SELECT * FROM ACCOUNTS WHERE ID = "+aId;
			Statement stm = this.connection.createStatement();
			ResultSet rSet = null;

			rSet = stm.executeQuery(sql);

			if(rSet.next()) {
				account = new Account(this.getConnection(), -1);
				account.setId(rSet.getInt("ID"));
				account.setClientId(rSet.getInt("CLIENT_ID"));
				account.setType(rSet.getString("ACTUAL_TYPE"));
				account.setValue(rSet.getDouble("ACTUAL_VALUE"));
				account.setDescr(rSet.getString("DESCR"));
			}

			rSet.close();
			stm.close();
		}
		catch (SQLException e) {
			System.err.println("\n ERRO SQL: " + e.toString() + "\n");
		}

		accountsTable.display(accounts);
		return account;
	}

	private void loadTotals() {
		this.loadTotalMoney();
		this.loadTotalClients();
		this.loadTotalAccounts();
		
		totalsPanel.display(totalMoney, qtClients, qtAccounts);
	}
	
	private void loadTotalAccounts() {
		String sql;
		Statement stm = null;
		ResultSet rs = null;

		try {
			sql = "SELECT COUNT(*) AS QT_ACCOUNTS " +
				  "FROM ACCOUNTS";
			stm = this.getConnection().createStatement();

			rs = stm.executeQuery(sql);
			if (rs.next())
				qtAccounts = rs.getInt("QT_ACCOUNTS");

			rs.close();
			stm.close();
			System.out.println("Qtd contas: " + qtAccounts + "\n");
		}
		catch (SQLException e) {
			System.err.println("\n ERRO SQL: " + e.toString() + "\n");
		}
	}


	private void loadTotalClients() {
		String sql;
		Statement stm = null;
		ResultSet rs = null;

		try {
			sql = "SELECT COUNT(*) AS QT_CLIENTS FROM CLIENTS";
			stm = this.getConnection().createStatement();

			rs = stm.executeQuery(sql);
			if (rs.next())
				qtClients = rs.getInt("QT_CLIENTS");

			rs.close();
			stm.close();
			System.out.println("Qtd clients: " + qtClients + "\n");
		} catch (SQLException e) {
			System.err.println("\n ERRO SQL: " + e.toString() + "\n");
		}
	}

	private void loadTotalMoney() {
		String sql;
		Statement stm = null;
		ResultSet rs = null;

		try {
			sql = "SELECT SUM(ACTUAL_VALUE) AS TOTAL_MONEY " + "FROM ACCOUNTS";
			stm = this.getConnection().createStatement();

			rs = stm.executeQuery(sql);
			if (rs.next())
				totalMoney = rs.getDouble("TOTAL_MONEY");

			rs.close();
			stm.close();
			System.out.println("Total: R$ " + totalMoney + "\n");
		}
		catch (SQLException e) {
			System.err.println("\n ERRO SQL: " + e.toString() + "\n");
		}
	}
	
	public void refreshTables(){
		loadTotalClients();
		totalsPanel.setClients(qtClients);
		this.loadClients();
		
		loadTotalAccounts();
		totalsPanel.setAccounts(qtAccounts);
		loadTotalMoney();
		totalsPanel.setMoney(totalMoney);
		this.loadAccounts();
	}


	//executa o caixa do banco.
	public static void main(String[] args) {
		BankBox bb = new BankBox();
		bb.loadTotals();

		//bb.createAccount(1, 1, 1100.30, "tete01");
		//bb.addClient("Teste Refrsh", "teste03", "1234", "24523", "5423523", "PAC 150", "32435702");

		bb.load();
		bb.loadTotals();

	}

}