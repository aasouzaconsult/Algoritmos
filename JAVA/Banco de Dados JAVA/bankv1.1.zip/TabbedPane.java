package bank;

import javax.swing.JTabbedPane;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JFrame;

import java.awt.*;
import java.awt.event.*;

public class TabbedPane extends JPanel {
	private JPanel p1, p2;
	private JTabbedPane tabbedPane;
	private ImageIcon icon;
	private JFrame frame; 
	
	public TabbedPane() {
		icon = new ImageIcon("middle.gif");
		tabbedPane = new JTabbedPane();
		
		
		frame = new JFrame("Banco");
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});

	}
	
	public void setClientsTab(JPanel panel){
		removeAll();
		Component panel1 = panel;
		tabbedPane.addTab("Clientes", icon, panel1, "Lista de Clientes do banco");
		tabbedPane.setSelectedIndex(0);
	}
	
	public void setAccountsTab(JPanel panel){
		removeAll();
		Component panel2 = panel; 
		tabbedPane.addTab("Contas", icon, panel2, "Lista de contas do Banco");
		tabbedPane.setSelectedIndex(0);
	}
	
	public void setTotalsTab(JPanel panel){
		removeAll();
		Component panel3 = panel; 
		tabbedPane.addTab("Totais", icon, panel3, "Valores do Banco");
		tabbedPane.setSelectedIndex(0);
	}
	
	public void setClientsFieldsTab(JPanel panel){
		removeAll();
		Component panel4 = panel; 
		tabbedPane.addTab("Caixa/clientes", icon, panel4, "Cadastro de clientes");
		tabbedPane.setSelectedIndex(0);

	}
	
	public void setAccountsFieldsTab(JPanel panel){
		removeAll();
		Component panel5 = panel; 
		tabbedPane.addTab("Caixa/Contas", icon, panel5, "Cadastro de contas");
		tabbedPane.setSelectedIndex(0);

	}
	
	public void setLoginTab(JPanel panel){
		removeAll();
		Component panel6 = panel; 
		panel6.setSize(300, 200);
		tabbedPane.addTab("Saques/dep�sitos", icon, panel6, "Saques e dep�sitos");
		tabbedPane.setSelectedIndex(0);

	}


	public void refreshWindow(){
		setLayout(new GridLayout(1, 1));
		add(tabbedPane);
		
		frame.getContentPane().add(this, BorderLayout.CENTER);
		frame.setSize(700, 500 );
		frame.setResizable(false);
		frame.setVisible(true);

	}
	
}