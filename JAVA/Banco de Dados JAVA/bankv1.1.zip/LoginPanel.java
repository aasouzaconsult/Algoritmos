package bank;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class LoginPanel extends JPanel implements ActionListener {
	private JButton put, get, signIn, clear;
	private JPanel loginButtonsPanel, loginLabelsPanel, loginFieldsPanel;
	private String loginLabels[] = { "UserName:", "Password:" };
	private JTextField userName, password;
	private JTextArea textArea;
	private BankBox bankBox;

	public LoginPanel(BankBox bankBox) {
		super();
		this.bankBox = bankBox;

		textArea = new JTextArea(22, 50);

		loginButtonsPanel = new JPanel();
		loginButtonsPanel.setLayout(new GridLayout(1, 2));

		loginButtonsPanel.add(signIn = new JButton("Entrar"));
		loginButtonsPanel.add(clear = new JButton("Limpar"));

		loginButtonsPanel.setSize(100, 20);

		signIn.addActionListener(this);
		clear.addActionListener(this);

		// Label panel
		loginLabelsPanel = new JPanel();
		loginLabelsPanel.setLayout(new GridLayout(loginLabels.length, 1));

		ImageIcon ii = new ImageIcon("icon.jpg");

		for (int i = 0; i < loginLabels.length; i++)
			loginLabelsPanel.add(new JLabel(loginLabels[i], ii, 0));

		// TextField panel
		loginFieldsPanel = new JPanel();
		loginFieldsPanel.setLayout(new GridLayout(loginLabels.length, 1));

		userName = new JTextField(35);
		loginFieldsPanel.add(userName);

		password = new JTextField(35);
		loginFieldsPanel.add(password);

		JPanel panelCenter = new JPanel(new BorderLayout());
		panelCenter.add(loginLabelsPanel, BorderLayout.CENTER);
		panelCenter.add(loginFieldsPanel, BorderLayout.EAST);

		JScrollPane scroller = new JScrollPane(textArea);
		setLayout(new BorderLayout());

		add(loginButtonsPanel, BorderLayout.NORTH);
		add(panelCenter, BorderLayout.CENTER);
		add(scroller, BorderLayout.SOUTH);

		setSize(350, 300);

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == signIn) {
			boolean error = false;
			String usr = userName.getText().trim();
			if (usr == null || usr.equals("")) {
				userName.setText("Digite um username");
				error = true;
			}

			String pass = password.getText().trim();
			if (pass == null || pass.equals("")) {
				password.setText("Digite um password");
				error = true;
			}

			if (!error) {
				textArea.setText("Login...\n");
				Client client = bankBox.loadClient((String) userName.getText().trim());
				if (client != null) {
					if (client.getPassword().trim().equals(pass)) {
						textArea.setText(client.getFullName().trim() + " seja bem-vindo. Voc� entrou no sistema");
						showCashPanel(client.getId());
					} else{
						textArea.setText("Password errado, tente novamente. ");
						textArea.append(client.getPassword().trim()+"\n");
						textArea.append(pass.trim()+"\n");									
					}
				} else {
					textArea.append("Cliente: " + usr + " n�o encontrado\n");
					this.clearLoginFields();
				}
			}
		} else if (e.getSource() == clear) {
			clearLoginFields();
		}
	}

	private void showCashPanel(int clientId){
		this.removeAll();
		CashPanel cashPanel = new CashPanel(bankBox, clientId);	
		add(cashPanel);		
	}		

	public void clearLoginFields() {
		userName.setText(null);
		password.setText(null);
	}

}