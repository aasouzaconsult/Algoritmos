package bank;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.sql.*;

public class AccountsDisplay extends JPanel {
	private JTable table;

	public AccountsDisplay() {
		setSize(700, 600);
	}

	public void display(Vector accounts) {
		try {
			if (accounts.size() == 0) {
				//JOptionPane.showMessageDialog(this, "Tabela de contas n�o possui registros.");
				return;
			}

			Vector columnHeads;
			Vector rows = new Vector();

			columnHeads = this.createColumnHeads();

			for (int i = 0; i < accounts.size(); i++) {
				rows.addElement(getNextRow(accounts, i));
			}

			// display table with ResultSet contents
			this.removeAll();
			table = new JTable(rows, columnHeads);
			table.setSize(700, 500);
			JScrollPane scroller = new JScrollPane(table);
			this.add(scroller, BorderLayout.CENTER);
			validate();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	private Vector createColumnHeads() {
		Vector heads = new Vector();
		heads.addElement((String) "ID");
		heads.addElement((String) "Id do cliente");
		heads.addElement((String) "Tipo de conta");
		heads.addElement((String) "Valor");
		heads.addElement((String) "Descri��o");
		return heads;
	}

	private Vector getNextRow(Vector accounts, int i) {
		Vector currentRow = new Vector();

		currentRow.addElement((String) Integer.toString(((Account) accounts.elementAt(i)).getId()));
		currentRow.addElement((String) Integer.toString(((Account) accounts.elementAt(i)).getClientId()));
		currentRow.addElement((String) ((Account) accounts.elementAt(i)).getType());
		currentRow.addElement((String) Double.toString(((Account) accounts.elementAt(i)).getValue()));
		currentRow.addElement((String) ((Account) accounts.elementAt(i)).getDescr());

		return currentRow;
	}
}