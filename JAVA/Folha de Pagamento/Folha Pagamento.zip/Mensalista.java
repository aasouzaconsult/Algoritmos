///////////////////////////////////////////////////////////////////////////
//
// Projeto: Folha de Pagamento
// Arquivo: Mensalista.java
// Descricao: 
//
///////////////////////////////////////////////////////////////////////////

public class Mensalista extends CategoriaSalarial
{
  private int salario;

  public Mensalista(int umSalario)
  {
    salario= umSalario;
  }
}
