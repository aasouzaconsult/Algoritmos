///////////////////////////////////////////////////////////////////////////
//
// Projeto: Folha de Pagamento
// Arquivo: Sindicalizado.java
// Descricao: 
//
///////////////////////////////////////////////////////////////////////////
import java.util.Vector;

public class Sindicalizado extends Afiliacao
{
  private Vector deducoesSindicais;

  public Sindicalizado()
  {
    deducoesSindicais= new Vector();
  }
}
