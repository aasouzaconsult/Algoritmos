import java.io.*;

public class saidabytes{
	public static void main (String args[]){
		try{
			OutputStream saida = new FileOutputStream("d:/arquivobytes.dat");

			byte [] dados;

			dados = new byte[1024];

			for(int i = 0; i < 1024; i++)
			   dados[i] = (byte) (i % 255);
			   
			saida.write(dados);
			
		}catch(FileNotFoundException erro){
			System.out.println("Arquivo nao encontrado. " + erro);
		}catch(IOException erro){
			System.out.println("Erro na entrada/saida do Arquivo. " + erro);
		}
		
	}
}