
package manarquivos;

import java.io.*;

public class testaarquivo{
	public static void main (java.lang.String args[]){
            File diretorio = new File("d:/temp");
            diretorio.mkdir();
            File arquivo = new File(diretorio, "lixo.txt");
            File subdir = new File(diretorio, "subdir1");
            subdir.mkdir();
            String [] arquivos = diretorio.list();
            for (int i=0; i < arquivos.length; i++){
                File filho = new File(diretorio, arquivos[i]);
                System.out.println(filho.getAbsolutePath());
                System.out.println(filho.getParent());
                System.out.println(filho.getName());
                System.out.println(filho.getPath());
            }
            if (arquivo.exists()){
                arquivo.delete();
            }
        }
}
