
public class Contato{
    
    protected String nome;
    protected int idade;
    protected String fone;
    protected String email;
 
    public Contato() {
        this("",0,"","");
    }
    
    public Contato(String nm, int id, String f, String em){
        nome = nm;
        idade = id;
        fone = f;
        email = em;
    }
    
    public String getnome(){ return nome; }
    public int getidade(){ return idade; }
    public String getfone(){ return fone; }
    public String getemail(){ return email; }
    
    public void setnome(String nm){ nome = nm;}
    public void setidade(int id){ idade = id;}
    public void setfone(String fn){ fone = fn;}
    public void setemail(String em){ email = em;}
}