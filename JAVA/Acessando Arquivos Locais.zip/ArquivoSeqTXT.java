/*
 * ArquivoSeq.java
 * Created on 14 de Julho de 2003, 09:13
 * @author  Fabricio
 */
import javax.swing.*;
import java.io.*;

public class ArquivoSeqTXT extends JFrame{
    
    private BufferedReader entrada;
    private BufferedWriter saida;
    private Contato registro;
    
    public ArquivoSeqTXT() {
        saida = null;
        entrada = null;
        registro = new Contato();
        initComponents();
    }

    public void criararquivo(){
      JFileChooser fileChooser = new JFileChooser();
      fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
      int result = fileChooser.showSaveDialog(this);//posiciona a janela no centro da tela
      //usando o this a janela � centrada na janela da aplica��o. O FileChooser � modal
      if (result == JFileChooser.CANCEL_OPTION) return;//finaliza a execu�ao do metodo
      
      File arquivo = fileChooser.getSelectedFile();
      System.out.println(fileChooser.getName());
      
      if (arquivo == null || arquivo.getName().equals(""))
         JOptionPane.showMessageDialog(this,"Nome de Arquivo Inv�lido", "Nome de Arquivo Inv�lido",JOptionPane.ERROR_MESSAGE);
      else {
         try {
            if (arquivo.exists()){
               saida = new BufferedWriter(new FileWriter(arquivo, true));//true(append).
               System.out.println("existe"); 
            }else{
               saida = new BufferedWriter(new FileWriter(arquivo, false));//false(rewrite).
               System.out.println("NAO existe");
            }
         }
         catch ( IOException ioException ) {
            JOptionPane.showMessageDialog(this,"Erro ao Abrir Arquivo", "Erro",JOptionPane.ERROR_MESSAGE);
         }      
      }
   }
   
   private void fechararquivo() 
   {
      try{
          if (saida != null){saida.close();}
          if (entrada != null) {entrada.close();}
      }
      catch(IOException ioException) {
         JOptionPane.showMessageDialog(this,"Error ao Fechar Arquivo","Erro",JOptionPane.ERROR_MESSAGE);
         System.exit(1);
      }
   }   

   public void gravarregistro(){
     registro = new Contato(textnome.getText(), Integer.parseInt(textidade.getText()), textfone.getText(), textemail.getText());
     try {
         saida.write(registro.getnome()+"\n");
         saida.write(registro.getidade()+"\n");
         saida.write(registro.getfone()+"\n");
         saida.write(registro.getemail()+"\n");
         saida.write("xxx\n");
         saida.flush();
         this.limparcampos();
    }
     catch (NumberFormatException formatException) {
        JOptionPane.showMessageDialog( this, "Erro","Formato de N�mero Inv�lido.",JOptionPane.ERROR_MESSAGE );
     }
     catch (IOException ioException) {
        fechararquivo();
     }     
   }
   
   public void limparcampos(){
       textnome.setText("");
       textidade.setText("");
       textfone.setText("");
       textemail.setText("");
       textnome.requestFocus();
   }

   public void atribuircampos(){
       textnome.setText(registro.getnome());
       textidade.setText(String.valueOf(registro.getidade()));
       textfone.setText(registro.getfone());
       textemail.setText(registro.getemail());
       textnome.requestFocus();
   }

   private void abrirarquivo()
   {
      JFileChooser fileChooser = new JFileChooser();
      fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
      int result = fileChooser.showOpenDialog(this);
      if (result == JFileChooser.CANCEL_OPTION){return;}
      File arquivo = fileChooser.getSelectedFile();
      System.out.println(arquivo);

      if ( arquivo == null || arquivo.getName().equals( "" ) )
        JOptionPane.showMessageDialog(this,"Nome de Arquivo Inv�lido", "Nome de Arquivo Inv�lido",JOptionPane.ERROR_MESSAGE);
      else {
         try {
            entrada = new BufferedReader(new FileReader(arquivo));
         }
         catch ( IOException ioException ) {
            JOptionPane.showMessageDialog(this,"Error ao Abrir Arquivo","Erro",JOptionPane.ERROR_MESSAGE);
         }      
      }
   }
   
   public void lerregistro()
   {
      try {
         registro.setnome(entrada.readLine());
         registro.setidade(Integer.parseInt(entrada.readLine()));
         registro.setfone(entrada.readLine());
         registro.setemail(entrada.readLine());
         String fim = entrada.readLine();
         if (fim.equals("xxx")){
             this.atribuircampos();
         }else{
             JOptionPane.showMessageDialog( this,"Erro na leitura do Registro.","Erro de Leitura", JOptionPane.ERROR_MESSAGE);
         }
      }
      catch (EOFException endOfFileException ) {
         btnproximo.setEnabled(false);
         JOptionPane.showMessageDialog( this,"Nao existem mais registros no arquivo.","Fim do Arquivo", JOptionPane.ERROR_MESSAGE);
      }
      catch (IOException ioException) {
          JOptionPane.showMessageDialog( this,"Erro durante a leitura do arquivo","Erro de Leitura", JOptionPane.ERROR_MESSAGE);
      }
      catch (NumberFormatException err){
          JOptionPane.showMessageDialog( this,"Erro na conversao do tipo ou final do arquivo.","Erro de Leitura", JOptionPane.ERROR_MESSAGE);
      }
   }
   
   private void initComponents() {//GEN-BEGIN:initComponents
       textnome = new javax.swing.JTextField();
       textidade = new javax.swing.JTextField();
       textfone = new javax.swing.JTextField();
       textemail = new javax.swing.JTextField();
       btncriar = new javax.swing.JButton();
       btngravar = new javax.swing.JButton();
       jLabel1 = new javax.swing.JLabel();
       jLabel3 = new javax.swing.JLabel();
       jLabel4 = new javax.swing.JLabel();
       jLabel5 = new javax.swing.JLabel();
       btnfechar = new javax.swing.JButton();
       btnabrir = new javax.swing.JButton();
       btnproximo = new javax.swing.JButton();
       
       getContentPane().setLayout(null);
       
       setTitle("Acesso a Arquivo Sequencial");
       addWindowListener(new java.awt.event.WindowAdapter() {
           public void windowClosing(java.awt.event.WindowEvent evt) {
               exitForm(evt);
           }
       });
       
       getContentPane().add(textnome);
       textnome.setBounds(90, 10, 190, 20);
       
       getContentPane().add(textidade);
       textidade.setBounds(90, 40, 190, 20);
       
       getContentPane().add(textfone);
       textfone.setBounds(90, 70, 190, 20);
       
       getContentPane().add(textemail);
       textemail.setBounds(90, 100, 190, 20);
       
       btncriar.setText("Cria Arquivo");
       btncriar.addActionListener(new java.awt.event.ActionListener() {
           public void actionPerformed(java.awt.event.ActionEvent evt) {
               btncriarActionPerformed(evt);
           }
       });
       
       getContentPane().add(btncriar);
       btncriar.setBounds(10, 130, 103, 26);
       
       btngravar.setText("Grava Info");
       btngravar.addActionListener(new java.awt.event.ActionListener() {
           public void actionPerformed(java.awt.event.ActionEvent evt) {
               btngravarActionPerformed(evt);
           }
       });
       
       getContentPane().add(btngravar);
       btngravar.setBounds(120, 130, 91, 26);
       
       jLabel1.setText("Nome:");
       getContentPane().add(jLabel1);
       jLabel1.setBounds(50, 10, 40, 16);
       
       jLabel3.setText("Idade:");
       getContentPane().add(jLabel3);
       jLabel3.setBounds(50, 40, 40, 16);
       
       jLabel4.setText("Fone:");
       getContentPane().add(jLabel4);
       jLabel4.setBounds(50, 70, 40, 16);
       
       jLabel5.setText("E-mail:");
       getContentPane().add(jLabel5);
       jLabel5.setBounds(50, 100, 40, 16);
       
       btnfechar.setText("Fechar");
       btnfechar.addActionListener(new java.awt.event.ActionListener() {
           public void actionPerformed(java.awt.event.ActionEvent evt) {
               btnfecharActionPerformed(evt);
           }
       });
       
       getContentPane().add(btnfechar);
       btnfechar.setBounds(220, 130, 73, 26);
       
       btnabrir.setText("Abre (L\u00ea) Arquivo");
       btnabrir.addActionListener(new java.awt.event.ActionListener() {
           public void actionPerformed(java.awt.event.ActionEvent evt) {
               btnabrirActionPerformed(evt);
           }
       });
       
       getContentPane().add(btnabrir);
       btnabrir.setBounds(10, 170, 132, 26);
       
       btnproximo.setText("Pr\u00f3ximo Registro");
       btnproximo.addActionListener(new java.awt.event.ActionListener() {
           public void actionPerformed(java.awt.event.ActionEvent evt) {
               btnproximoActionPerformed(evt);
           }
       });
       
       getContentPane().add(btnproximo);
       btnproximo.setBounds(150, 170, 133, 26);
       
       pack();
       java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
       setSize(new java.awt.Dimension(350, 250));
       setLocation((screenSize.width-350)/2,(screenSize.height-250)/2);
   }//GEN-END:initComponents

   private void btnproximoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnproximoActionPerformed
       this.lerregistro();
   }//GEN-LAST:event_btnproximoActionPerformed

   private void btnabrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnabrirActionPerformed
       this.abrirarquivo();
       btnproximo.setEnabled(true);
   }//GEN-LAST:event_btnabrirActionPerformed

   private void btnfecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfecharActionPerformed
       this.fechararquivo();
   }//GEN-LAST:event_btnfecharActionPerformed

   private void btncriarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncriarActionPerformed
        this.criararquivo();
   }//GEN-LAST:event_btncriarActionPerformed

   private void btngravarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngravarActionPerformed
        this.gravarregistro();
   }//GEN-LAST:event_btngravarActionPerformed

    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        fechararquivo();
        System.exit(0);
    }//GEN-LAST:event_exitForm

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField textnome;
    private javax.swing.JTextField textidade;
    private javax.swing.JTextField textfone;
    private javax.swing.JTextField textemail;
    private javax.swing.JButton btncriar;
    private javax.swing.JButton btngravar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JButton btnfechar;
    private javax.swing.JButton btnabrir;
    private javax.swing.JButton btnproximo;
    // End of variables declaration//GEN-END:variables

    public static void main(String args[]) {
        new ArquivoSeqTXT().show();
    }
}