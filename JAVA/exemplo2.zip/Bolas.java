import java.lang.*;
import java.awt.*;
import java.awt.event.*;

class AreaBolas extends Canvas {
    private Dimension minSize = new Dimension( 100, 100);
    private Color cor = Color.black;	

    public AreaBolas( Color c) {
        super();
        cor = c;
        }

    public void setCor( Color c) {
        cor = c;
        }

    public Dimension getMinimumSize() {
        return minSize;
        }

    public Dimension getPreferredSize() {
        return minSize;
        }

    public void paint( Graphics g) {
        Dimension size = this.getSize();
        g.setColor( cor);
        g.fillOval( 2, 2, size.width-4, size.height-4);
        }
    }



public class Bolas extends Frame {

    private Color cores[] = { Color.blue, Color.cyan, Color.green, Color.red,
                              Color.magenta, Color.orange, Color.pink,
                              Color.yellow };
    private int usaEstaCor = 0;
    private AreaBolas desenho;
	

    // Classe interna para receber eventos associados com a janela
    class EscutaJanela extends WindowAdapter{
        public void windowClosing(WindowEvent e){
            System.out.println("janela foi fechada");
            System.exit(0);            
            }    	
        }

    // Inicializa o frame
    public Bolas() {

        System.out.println("inicio do construtor");

        // Define o layout manager
	GridLayout gl = new GridLayout(2,2);
        this.setLayout( gl );

        //Cria a area vazia
        desenho = new AreaBolas( cores[usaEstaCor] );
        this.add( desenho );

        // Para pegar o fechamento da janela
        EscutaJanela j = new EscutaJanela();
        this.addWindowListener(j);

        System.out.println("terminou criacao dos componentes");

        // Apresenta a janela
	  pack();
	  show();
	  System.out.println("mostrou janela");
        }

    public void variaCores(){
	while( true ){
  	  try{ Thread.sleep(2000); } catch(InterruptedException ie){};
	  ++usaEstaCor;
	  if( usaEstaCor == cores.length ) usaEstaCor = 0; 
	  desenho.setCor( cores[usaEstaCor] );
	  desenho.repaint();
   	  }
 	}	


    //Permite rodar como aplicacao
    public static void main( String args[]) {
        Bolas b = new Bolas();
	b.variaCores();
	System.out.println("fim do main");
        }

    }

