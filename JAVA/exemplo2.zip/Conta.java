import java.awt.*;
import java.awt.event.*;

public class Conta extends Frame
                    implements ActionListener {

    private Button botao;
    private Label mensagem;
    private int i = 0;

    // Classe interna para receber eventos associados com a janela
    class JanelaListener extends WindowAdapter{
        public void windowClosing(WindowEvent e){
	    System.out.println("janela foi fechada");
            System.exit(0);            
            }    	
        }

    // Inicializa o frame
    public Conta() {

 	System.out.println("inicio do construtor");

        // Define o layout manager
	GridLayout gl = new GridLayout();
        this.setLayout( gl );

        //Cria um campo label
        mensagem = new Label("Contagem = " + i, Label.CENTER);
        mensagem.setFont( new Font("TimesRoman", Font.BOLD, 14) );
        this.add( mensagem );

        // Cria um botao
        botao = new Button("Mais um");
        botao.addActionListener( this);
        this.add( botao );

	// Para pegar o fechamento da janela
	JanelaListener jl = new JanelaListener();
	this.addWindowListener(jl);

        System.out.println("terminou criacao dos componentes");


        // Mostra
	pack();
	show();

	System.out.println("mostrou janela");
        }


    //Lida com o click do botao
    public void actionPerformed( ActionEvent e) {
        ++i;
	mensagem.setText( "Contagem = " + i );
        mensagem.repaint();
        }

    //Permite rodar como aplicacao
    public static void main( String args[]) {
        Conta f = new Conta();
        System.out.println("fim do main");
        }

    }


