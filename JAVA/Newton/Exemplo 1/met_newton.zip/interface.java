interface Evaluar
{
	double f(double x);	
}
