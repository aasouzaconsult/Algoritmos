
class pruebaNewton
{
	
	public static void impResult(double xo, Newton n, Evaluar funcion, Evaluar derivada)
	{
		n.asignarDatos(xo);
		System.out.println("\n\tEvaluacion de punto inicial : " + xo);
		System.out.println("\tf(" + xo + ") : " + funcion.f(xo));
		
		System.out.println("\traiz : " + n.raiz(funcion,derivada));
		System.out.println("\tNumero de iteraciones : " + n.numIteraciones());	
	
	}
	
	public static void main(String arg[])
	{
		Newton n = new Newton();	
		
		/*  polinomio : (x-3)(x+2)(x-1) = 6 - 5x - 2x^2 + x^3 */
		
		double coef[] = { 6.0 , -5.0 , -2.0 , 1.0  };
		
		PolinomioNewton fx = new PolinomioNewton(coef);
		
		PolinomioNewton dx = fx.derivar(fx);
		
		
		System.out.println("\n\tPrograma de prueba para metodo de Newton");
          System.out.println("\t----------------------------------------");
		
		System.out.println("\n\tPolinomio : " + fx.toString("x"));
		System.out.println("\n\tDerivada : " + dx.toString("x"));
		
		impResult(2.5  , n , fx,dx);
		impResult( -1.7 , n , fx,dx);
		impResult( 1.4 , n , fx,dx);
	    
		System.out.println();
	}		
}