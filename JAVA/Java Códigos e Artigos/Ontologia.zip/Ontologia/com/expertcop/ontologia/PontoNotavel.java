package com.expertcop.ontologia;

import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: PontoNotavel
* @author ontology bean generator
* @version 2003/12/3, 10:35:57
*/
public class PontoNotavel extends Agente{ 

   public static final int MUITO_BAIXO=0, BAIXO=1, MEDIO=2, ALTO=3, MUITO_ALTO=4;
   /**
* Protege name: valor
   */
   private int valor;
   public void setValor(int value) { 
     pcs.firePropertyChange("valor", this.valor, value);
    this.valor=value;
   }
   public int getValor() {
     return this.valor;
   }

   /**
* Protege name: densidade
   */
   private int densidade;
   public void setDensidade(int value) { 
     pcs.firePropertyChange("densidade", this.densidade, value);
    this.densidade=value;
   }
   public int getDensidade() {
     return this.densidade;
   }

   /**
* Protege name: emAlerta
   */
   private boolean emAlerta;
   public void setEmAlerta(boolean value) { 
     pcs.firePropertyChange("emAlerta", this.emAlerta, value);
    this.emAlerta=value;
   }
   public boolean getEmAlerta() {
     return this.emAlerta;
   }

}
