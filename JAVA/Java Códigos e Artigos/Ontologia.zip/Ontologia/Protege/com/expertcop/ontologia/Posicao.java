package com.expertcop.ontologia;

import java.io.Serializable;
import java.beans.PropertyChangeSupport;
import java.beans.PropertyChangeListener;

import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: Posicao
* @author ontology bean generator
* @version 2003/12/5, 09:44:40
*/
public class Posicao implements Concept, Serializable {
   // bean stuff
   protected PropertyChangeSupport pcs = new PropertyChangeSupport(this);

   public void addPropertyChangeListener(PropertyChangeListener pcl) {
     pcs.addPropertyChangeListener(pcl);
   }

   public void removePropertyChangeListener(PropertyChangeListener pcl) {
     pcs.removePropertyChangeListener(pcl);
   }


   /**
* Protege name: latitude
   */
   private int latitude;
   public void setLatitude(int value) { 
     pcs.firePropertyChange("latitude", this.latitude, value);
    this.latitude=value;
   }
   public int getLatitude() {
     return this.latitude;
   }

   /**
* Protege name: longitude
   */
   private int longitude;
   public void setLongitude(int value) { 
     pcs.firePropertyChange("longitude", this.longitude, value);
    this.longitude=value;
   }
   public int getLongitude() {
     return this.longitude;
   }

}
