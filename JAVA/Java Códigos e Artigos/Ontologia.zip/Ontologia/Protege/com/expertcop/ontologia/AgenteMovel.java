package com.expertcop.ontologia;

import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: AgenteMovel
* @author ontology bean generator
* @version 2003/12/5, 09:44:40
*/
public class AgenteMovel extends Agente{ 

   /**
* Protege name: alcanceVisual
   */
   private int alcanceVisual;
   public void setAlcanceVisual(int value) { 
     pcs.firePropertyChange("alcanceVisual", this.alcanceVisual, value);
    this.alcanceVisual=value;
   }
   public int getAlcanceVisual() {
     return this.alcanceVisual;
   }

   /**
* Protege name: velocidade
   */
   private int velocidade;
   public void setVelocidade(int value) { 
     pcs.firePropertyChange("velocidade", this.velocidade, value);
    this.velocidade=value;
   }
   public int getVelocidade() {
     return this.velocidade;
   }

}
