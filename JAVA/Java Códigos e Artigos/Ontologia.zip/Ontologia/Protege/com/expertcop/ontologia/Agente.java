package com.expertcop.ontologia;

import java.io.Serializable;
import java.beans.PropertyChangeSupport;
import java.beans.PropertyChangeListener;

import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: Agente
* @author ontology bean generator
* @version 2003/12/5, 09:44:40
*/
public class Agente extends jade.core.Agent implements Concept, Serializable {
   // bean stuff
   protected PropertyChangeSupport pcs = new PropertyChangeSupport(this);

   public void addPropertyChangeListener(PropertyChangeListener pcl) {
     pcs.addPropertyChangeListener(pcl);
   }

   public void removePropertyChangeListener(PropertyChangeListener pcl) {
     pcs.removePropertyChangeListener(pcl);
   }


   /**
* Protege name: aid
   */
   private AID aid;
   public void setAid(AID value) { 
     pcs.firePropertyChange("aid", (this.aid==null?new AID():this.aid), value);
    this.aid=value;
   }
   public AID getAid() {
     return this.aid;
   }

   /**
* Protege name: posicao
   */
   private Posicao posicao;
   public void setPosicao(Posicao value) { 
     pcs.firePropertyChange("posicao", (this.posicao==null?new Posicao():this.posicao), value);
    this.posicao=value;
   }
   public Posicao getPosicao() {
     return this.posicao;
   }

}
