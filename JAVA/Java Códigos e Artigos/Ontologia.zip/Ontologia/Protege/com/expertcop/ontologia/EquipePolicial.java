package com.expertcop.ontologia;

import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: EquipePolicial
* @author ontology bean generator
* @version 2003/12/5, 09:44:40
*/
public class EquipePolicial extends AgenteMovel{ 

   /**
* Protege name: tipo
   */
   private int tipo;
   public void setTipo(int value) { 
     pcs.firePropertyChange("tipo", this.tipo, value);
    this.tipo=value;
   }
   public int getTipo() {
     return this.tipo;
   }

   /**
* Protege name: abrangencia
   */
   private int abrangencia;
   public void setAbrangencia(int value) { 
     pcs.firePropertyChange("abrangencia", this.abrangencia, value);
    this.abrangencia=value;
   }
   public int getAbrangencia() {
     return this.abrangencia;
   }

}
