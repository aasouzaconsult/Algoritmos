import com.expertcop.ontologia.EquipePolicial;
import com.expertcop.ontologia.Criminoso;
import com.expertcop.ontologia.Posicao;

class Teste
{
	public static void main(String args[])
	{
	   RegrasCriminoso rc = new RegrasCriminoso();
	   
	   EquipePolicial e1 = new EquipePolicial();
	   e1.setPosicao(new Posicao(0,0));
	   rc.assert(e1);
	   
	   EquipePolicial e2 = new EquipePolicial();
	   e2.setPosicao(new Posicao(15,25));
	   rc.assert(e2);
	   
	   Criminoso c = new Criminoso();
	   c.setPosicao(new Posicao(4,3));
	   rc.assert(c);
	   
	   rc.run();
	}
}