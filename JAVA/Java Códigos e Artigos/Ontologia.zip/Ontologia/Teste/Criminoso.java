package com.expertcop.ontologia;

import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: Criminoso
* @author ontology bean generator
* @version 2003/12/3, 10:35:57
*/
public class Criminoso extends AgenteMovel{ 

   /**
* Protege name: periculosidade
   */
   private int periculosidade;
   public void setPericulosidade(int value) { 
     pcs.firePropertyChange("periculosidade", this.periculosidade, value);
    this.periculosidade=value;
   }
   public int getPericulosidade() {
     return this.periculosidade;
   }

}
