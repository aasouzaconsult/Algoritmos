package com.expertcop.ontologia;

import java.io.Serializable;
import java.beans.PropertyChangeSupport;
import java.beans.PropertyChangeListener;

import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: Posicao
* @author ontology bean generator
* @version 2003/12/3, 10:35:58
*/
public class Posicao implements Concept, Serializable {
   
   public Posicao()
   {
   }
   
   public Posicao(int lat, int lon)
   {
   	this.latitude = lat;
   	this.longitude = lon;
   }
   
   // bean stuff
   protected PropertyChangeSupport pcs = new PropertyChangeSupport(this);

   public void addPropertyChangeListener(PropertyChangeListener pcl) {
     pcs.addPropertyChangeListener(pcl);
   }

   public void removePropertyChangeListener(PropertyChangeListener pcl) {
     pcs.removePropertyChangeListener(pcl);
   }


   /**
* Protege name: longitude
   */
   private int longitude;
   public void setLongitude(int value) { 
     pcs.firePropertyChange("longitude", this.longitude, value);
    this.longitude=value;
   }
   public int getLongitude() {
     return this.longitude;
   }

   /**
* Protege name: latitude
   */
   private int latitude;
   public void setLatitude(int value) { 
     pcs.firePropertyChange("latitude", this.latitude, value);
    this.latitude=value;
   }
   public int getLatitude() {
     return this.latitude;
   }
	
	/**
    * Metodo que calcula a distancia desta posi��o para outra passada como
    *par�metro.
    */
    public int distancia(Posicao p)
    {
		double dx2 = Math.pow(this.latitude - p.getLatitude(), 2);
		double dy2 = Math.pow(this.longitude - p.getLongitude(), 2);  	
    	return (int)Math.sqrt(dx2 + dy2);
    	
    }
    
    public static void main(String args[])
	 {
	    Posicao p1, p2, p3;
	    p1 = new Posicao(0,0);
	    p2 = new Posicao(4,0);
	    p3 = new Posicao(4,3);
	    
	    System.out.println("Distancia p1, p2 = "+p1.distancia(p3));
	 }
}
