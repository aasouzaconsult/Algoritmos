Decafe Pro
Java Decompiler for Windows 95/98/NT

 THE PURPOSE
Decafe is decompiler for Java which reconstructs the original source code 
from the compiled binary CLASS files (applets)
Decafe is able to decompile the most complex Java applets and binaries, 
producing accurate source code.


 INSTALLATION
The program is for Windows 95, Windows NT and Window 98
Run setup.exe
  
 THE STATUS OF DECAFE PRO
Decafe is not free, it is SHAREWARE. You are allowed 21 days to
evaluate it and decide if it's of any use to you. If you want to
continue using it after this period you must register. 
The registration fee is $29 US. Visit Decafe pro home page at:
http://decafe.hypermart.net to get more info.

 COPYRIGHT INFORMATIONS
This software is provided as-is, without warranty of ANY KIND, either expressed or implied, including but not limited to the implied
warranties of merchantability and/or fitness for a particular purpose. The author shall NOT be held liable for ANY damage to you, your
computer, or to anyone or anything else, that may result from its use, or misuse. Basically, you use it at YOUR OWN RISK.

All trademarks and other registered names contained in the Decafe
package are the property of their respective owners.  

The program uses Jad ver. 1.5.7g as its Java decompiling engine. 
The decompiled Java code is provided "as is", for your information only, without warranty of any kind, either expressed or implied.
You assume all risks concerning the suitability and accuracy of the decompiled code. The decompiled code may contain inaccuracies or errors.

Use of this software indicates that you agree to the above conditions.


 CONTACT
Home page: http://decafe.hypermart.net
Email: sunimage@home.com
