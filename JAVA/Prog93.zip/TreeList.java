import waba.ui.*;
import waba.util.IntVector;
import waba.util.Vector;
import waba.fx.*;

public class TreeList extends ListBox  {
	IntVector levels;
	IntVector hiddenNodes;

	public TreeList() {
		this(null, null);
	}
	
	public TreeList(Object[] items, int[] levels) {
		super(items);
		if (levels != null) {
			this.levels = new IntVector(levels.length);
				for (int i = 0; i < levels.length; i++) {
					this.levels.add(levels[i]);
				}
		}		
		hiddenNodes = new IntVector(0);
	}
	/**
	* Adds the items to the TreeList at level 0
	
	* @param moreItems the items to add to the TreeList
	**/
	public void add(Object[] moreItems) {
		int[] moreLevels = new int[moreItems.length];
		for (int i = 0; i < moreItems.length; i++) {
			moreLevels[i] = 0;
		}
		add(moreItems, moreLevels);
	}
	/**
	* Adds the items to the TreeList. Please ensure that moreLevels.length = moreItems.length
	
	* @param moreItems the items to add
	* @param moreLevels the levels for the items
	**/
	public void add(Object[] moreItems, int[] moreLevels) {
      if (itemCount == 0) // guich@310_5: directly assign the array if this listbox is empty
      {
         this.items = new Vector(moreItems);
         this.levels = new IntVector(moreLevels.length);
         	for (int i = 0; i < moreLevels.length; i++) {
					this.levels.add(moreLevels[i]);
			}
         itemCount = moreItems.length;
      }
      else
      {
         itemCount += moreItems.length;
         for (int i = 0; i < moreItems.length; i++) {
            items.add(moreItems[i]);
            levels.add(moreLevels[i]);
         }
      }
      sbar.setEnabled(enabled && visibleItems < itemCount);
      sbar.setMaximum(itemCount); // guich@210_12: forgot this line!
	}
  
  public void add(Object item) {
  	add(item, 0);	
  }
  
  public void add(Object item, int level) {
  	if (itemCount == 0) {
  		this.items = new Vector(1);
  		this.levels = new IntVector(1);
  	}
  	
    levels.add(level);
    super.add(item);
  }
  
  public void insert(Object item, int index) {
  	insert(item, 0, index);
  }
  
  public void insert(Object item, int level, int index) {
      levels.insert(index, level);
      super.insert(item, index);
  }
  
  public void removeAll() {
	if (itemCount > 0) {
//	waba.sys.Vm.debug("Clearing levels");	
	  	levels.clear();
//  	waba.sys.Vm.debug("Calling super.removeAll()");
	  	super.removeAll();
	  	itemCount = 0;
	}
  }
  
  public void remove(int itemIndex) {
  	if (0 <= itemIndex && itemIndex < itemCount) {
  		levels.del(itemIndex);
  	}
  	super.remove(itemIndex);
  }
  
  public void remove(Object item) {
	int index;
    if (itemCount > 0 && (index=items.find(item)) != -1)
    	remove(index);
  }
  
  public void setLevelAt(int index, int level) {
      if (0 <= index && index < itemCount)
      {
         levels.setElementAt(level, index);
         repaint();
      }
  }
  
  /**
  * Returns the level of the item at the given index.
  * If the item does not exist, -1 is returned
  * @param index the index of the item
  **/
  public int getLevelAt(int index) {
      if (0 <= index && index < itemCount)
         return levels.items[index];//get(i);
      return -1;  	// fallback
  }
  
  protected void drawItem(Graphics g, int index, int dx, int dy) {
      if (0 <= index && index < itemCount) {
	 	if (index % 2 == 0) {
		    g.setBackColor(229,253,255);
		    g.fillRect(dx - 1, dy + 2, btnX, fmH); //Math.min(fmH * visibleItems, this.height-dy));
		    g.setBackColor(backColor);
		    
		}      	
      	int myLevel = levels.items[index];
      	
      	int xStart = dx + (10 * myLevel);
      	int yStart = dy + (fmH - 10) / 2;
      	// paint the arrow
      	if (hiddenNodes.find(myLevel) == -1) {
	      	g.drawArrow(xStart, yStart, 10, Graphics.ARROW_DOWN, false, true, Color.defaultForeColor);
	    }
	    else {
	      	g.drawArrow(xStart, dy, 10, Graphics.ARROW_RIGHT, false, true, Color.defaultForeColor);
	    }	
      	//paint the text - put in an extra space if we have to
      	g.drawText(items.items[index].toString(), xStart + 20, dy);
      }
  }
  
	protected int getItemWidth(int index)
	{
		return btnX;
	}  
	
	public void onEvent(Event event) {
		super.onEvent(event);
		switch (event.type) {
		  case PenEvent.PEN_DOWN:
			if (event.target != this) break;
			PenEvent pe = (PenEvent)event;
			if (pe.x < btnX && contains(this.x+pe.x,this.y+pe.y)) {
		      	int currentLevel = levels.items[selectedIndex];
		      	if ((pe.x <= 10*currentLevel + 15) && (pe.x >= 10*currentLevel)) {
		      		int hidden= hiddenNodes.find(selectedIndex);
		      		if (hidden == -1) {
		      			hiddenNodes.add(selectedIndex);
		      			waba.sys.Vm.debug("Adding hidden node " + selectedIndex);
		      		}
		      		else {
		      			hiddenNodes.del(hidden);	
		      			waba.sys.Vm.debug("Removing hidden node " + selectedIndex);		      			
		      		}
// repaint just the little bit we have to - how?!?!?! - IT HAS PROTECTED ACCESS
//		      		this.asWindow.damageRect(0, fmH * selectedIndex, 10*currentLevel + 15, fmH);
					repaint();
		      	}
			}
		    break;	
		}
		
	}
}
