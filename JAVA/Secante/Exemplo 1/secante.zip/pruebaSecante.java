class pruebaSecante
{
	
public static void main(String arg[])
	{
		Secante s = new Secante();	
		
		double coef[] = { -1.0 , 0.0 , 0.0 , 1.0 };
		
		EvalPolinomio p = new EvalPolinomio(coef);
		
		s.asignarDatos(0.0,2.0);
		
		System.out.println("\n\tPrograma de prueba para metodo de la Secante");
		  System.out.println("\t--------------------------------------------");
		
		System.out.println("\n\tf(t) : " + p.toString("t"));
		
		System.out.println("\n\tf(0.0) : " + p.f(0.0));
		System.out.println("\tf(2.0) : " + p.f(2.0));
		
		System.out.println("\n\traiz : " + s.raiz(p));
	
		System.out.println("\n\tnumero de iteraciones : " + s.numIteraciones());

		System.out.println();
	}		
	
}