/*********************************************************************************
 *  SuperWaba Virtual Machine, version 3                                       *
 *  Copyright (C) 2002 Guilherme Campos Hazan <guich@superwaba.org.>             *
 *  Copyright (C) 2001 Daniel Tauchke                                            *
 *  All Rights Reserved                                                          *
 *                                                                               *
 *  This library and virtual machine is free software; you can redistribute      *
 *  it and/or modify it under the terms of the Amended GNU Lesser General        *
 *  Public License distributed with this software.                               *
 *                                                                               *
 *  This library and virtual machine is distributed in the hope that it will     *
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                         *
 *                                                                               *
 *  All software that links or interacts with this library and virtual machine,  *
 *  or any derivative works, require the software to prominently display the     *
 *  following notice:                                                            *
 *                                                                               *
 *                   Created with SuperWaba                                      *
 *                  http://www.superwaba.org                                     *
 *                                                                               *
 *  Please see the software license located at superwaba/license.txt             *
 *  for more details.                                                            *
 *                                                                               *
 *  You should have received a copy of the License along with this software;     *
 *  if not, write to                                                             *
 *                                                                               *
 *     Guilherme Campos Hazan                                                    *
 *     Av. Nossa Senhora de Copacabana 728 apto 605 - Copacabana                 *
 *     Rio de Janeiro / RJ - Brazil                                              *
 *     Cep: 22050-000                                                            *
 *     E-mail: guich@superwaba.org                                               *
 *                                                                               *
 *********************************************************************************/

// PopList.java written 2001 by Daniel Tauschke and a little modified by guich
// http://www.tauschke.com
// E-mail: tauschke@ tauschke.com

package ca.yourdecor.cc.midp.ui;

import waba.ui.*;
import waba.fx.*;
import waba.util.*;
import waba.sys.*;

/**
 * PopList is a simple implementation of a PopUp Listbox. Used by the ComboBox class.
 */

public class MultiPopList extends Window
{
   /** now this member is public to make this class simple */
   public MultiListBox lb = null;
   /** set to true if want to make the control popup below or above always, and not only if WinCE */
   public boolean dontHideParent = Settings.uiStyle == Settings.WinCE; // guich@200b4_205: let the user choose to not hide the parent control
   private ControlEvent ce = new ControlEvent(ControlEvent.WINDOW_MOVED, null);
   /** set to true to make this pop have the screen height */
   public boolean fullHeight; // guich@330_52


	/**
	 * Determines whether or not we close the popList after the user makes their
	 * first selection.  If the typical use case involves only a single
	 * selection from the multi list then set this value to true.  Then if the
	 * user wants to select multiple values they have to click on the poplist
	 * again and this time it will stay open so that multiple values can be
	 * selected from the list.  This option makes the common case as quick and
	 * easy as possible for the user, and the less common case still possible.
	 * Default is false: The poplist will stay open for multiple selections.
	 * The poplist will be closed when the user clicks outside of the poplist
	 * window.
	 */
	public boolean firstSelection = false;
	
	
   /** Creates a PopList with coordinates that will be set later via the setRect method. */
   public MultiPopList()
   {
      this(new MultiListBox());
   }

   /** Creates a PopList with the given ListBox. You can extend the ListBox to
     * draw the items by yourself and use this constructor so the PopList will
     * use your class and not the default ListBox one. Note that this constructor forces
     * the ListBox.simpleBorder to true.
     */
   public MultiPopList(MultiListBox lb)
   {
      highResPrepared = true;
      setDoubleBuffer(true);
      this.lb = lb;
      lb.simpleBorder = true;
      super.add(lb);
      ce.target = lb;
   }

   /** Sets the font of the controls inside this window too */
   protected void onFontChanged() // guich@200b4_153
   {
      if (lb != null) lb.setFont(font);
   }


   /** Sets the rect for this poplist. Note: the params must be the
     * same of the parent control. eg: height = height of the closed ComboBox.
     * Its used to popup the window so that the parent's area is not hidden.
     */
   public void setRect(Rect r)
   {
      setRect(r.x,r.y,r.width,r.height,null);
   }

   /** Sets the rect for this poplist. Note: the params must be the
     * same of the parent control. eg: height = height of the closed ComboBox.
     * Its used to popup the window so that the parent's area is not hidden.
     */
   public void setRect(int x, int y, int width, int height)
   {
      setRect(x,y,width,height,null);
   }

   /** Sets the rect for this poplist. Note: the params must be the
     * same of the parent control. eg: height = height of the closed ComboBox.
     * Its used to popup the window so that the parent's area is not hidden.
     */
   public void setRect(int x, int y, int width, int height, Control relative)
   {
      if (lb.size() > 0)
      {
         // Now calculate the position on the screen
         // set the x any y coordinate to fit to
         // the screen by the given width and height.

         // width fit to screen
         width = Math.min(Math.max(width-2,lb.getPreferredWidth()),Settings.screenWidth-10); // keep same size of parent control if possible, and less than the screen width
         if (x+width > Settings.screenWidth)
            x = Settings.screenWidth - width; // guich@220_24: make sure the pop doesnt go beyond the screen

         // height fit to screen
         int prefH = lb.getPreferredHeight();
         int remainsAtBottom = Settings.screenHeight - (y+height);
         int remainsAtTop = y;
         if (prefH <= remainsAtBottom) // can fit at bottom?
         {
            if (dontHideParent)
               y += height-1; // put window below parent's
            height = prefH;
         }
         else
         if (prefH <= remainsAtTop) // can fit at top?
         {
            if (dontHideParent)
               y -= prefH-1; // put window above parent's
            else
               y += height-prefH-1; // put window below parent's - guich@210_5: fix popping up a PalmOS Combo placed in the LEFT,BOTTOM.
            height = prefH;
         }
         else // cant fit in screen
         if (fullHeight && prefH > Settings.screenHeight) // guich@330_52
         {
            y = 0;
            height = ((int)((Settings.screenHeight-6) / fmH))*fmH + 6;
         }
         else
         if (remainsAtBottom >= remainsAtTop) // more area at bottom?
         {
         	// Default behaviour if we're not in fullHeight mode - alex.muc@utoronto.ca
         	if (! fullHeight) {
	            if (dontHideParent)
	               y += height; // put win below parent's using parent's height
	            height = ((int)((remainsAtBottom-6) / fmH)) * fmH + 6;
	            if (!dontHideParent)
	               height += fmH; // guich@220_24
	        // Otherwise make use of the available screen space - alex.muc@utoronto.ca
         	} else {
         		y = Settings.screenHeight - prefH;
         		height = prefH;
         	}
         }
         else
         {
         	// Default behaviour if we're not in fullHeight mode - alex.muc@utoronto.ca
         	if (! fullHeight) {
	            height = ((int)((remainsAtTop-6) / fmH)) * fmH + 6;
	            if (!dontHideParent) // guich@220_24: hide parent? add one more row to the height
	            {
	               height += fmH;
	               y += fmH;
	            }
	            y -= height-1;
       		// Otherwise make use of the available screen space - alex.muc@utoronto.ca
         	} else {
         		y = 0;
         		height = prefH;
         	}
         }
         // End of the "fit to screen part"
      }
      super.setRect(x,y,width,height,null);
      lb.setRect(0,0,width,height);
   }

   /** Close the popup list with a click outside its bounds */
   protected boolean onClickedOutside(int x,int y)
   {
      unpop();
      return true;
   }

   public void onEvent(Event event)
   {
      switch (event.type)
      {
         case ControlEvent.PRESSED:
            if (event.target == lb && firstSelection) {
               unpop();
               firstSelection = false;
            }
            break;
         case ControlEvent.WINDOW_MOVED:
            lb.onEvent(event); // guich@330_21
            break;
      }
   }
   
   public void setFirstSelection(boolean b) {
   	firstSelection = b;
   }
   public boolean getFirstSelection() {
   	return firstSelection;
   }

   public int getPreferredWidth()
   {
      return lb.getPreferredWidth();
   }
   public int getPreferredHeight()
   {
      return lb.getPreferredHeight();
   }

   protected void onPopup() // guich@321_13
   {
      lb.onEvent(ce);
   }
}