/*********************************************************************************
 *  SuperWaba Virtual Machine, version 3                                       *
 *  Copyright (C) 2002 Guilherme Campos Hazan <guich@superwaba.org.>             *
 *  Copyright (C) 2001 Daniel Tauchke                                            *
 *  All Rights Reserved                                                          *
 *                                                                               *
 *  This library and virtual machine is free software; you can redistribute      *
 *  it and/or modify it under the terms of the Amended GNU Lesser General        *
 *  Public License distributed with this software.                               *
 *                                                                               *
 *  This library and virtual machine is distributed in the hope that it will     *
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                         *
 *                                                                               *
 *  All software that links or interacts with this library and virtual machine,  *
 *  or any derivative works, require the software to prominently display the     *
 *  following notice:                                                            *
 *                                                                               *
 *                   Created with SuperWaba                                      *
 *                  http://www.superwaba.org                                     *
 *                                                                               *
 *  Please see the software license located at superwaba/license.txt             *
 *  for more details.                                                            *
 *                                                                               *
 *  You should have received a copy of the License along with this software;     *
 *  if not, write to                                                             *
 *                                                                               *
 *     Guilherme Campos Hazan                                                    *
 *     Av. Nossa Senhora de Copacabana 728 apto 605 - Copacabana                 *
 *     Rio de Janeiro / RJ - Brazil                                              *
 *     Cep: 22050-000                                                            *
 *     E-mail: guich@superwaba.org                                               *
 *                                                                               *
 *********************************************************************************/

// ComboBox.java written 2001 by Daniel Tauschke and a little modified by guich
// dant@200b3: corrected 0-sized bug
// http://www.tauschke.com
// E-mail: tauschke@ tauschke.com

package ca.yourdecor.cc.midp.ui;

import waba.ui.*;
import waba.fx.*;
import waba.util.*;
import waba.sys.*;

/**
 * ComboBox is a simple implementation of a ComboBox.
 * <p>
 * Note: the color used in the setBackground method will be used in the button
 * only. The background color of the control will be a lighter version of the
 * given color.
 */

public class MultiComboBox extends Container
{
   private MultiPopList pop;
   private Button btn;
   private boolean armed;
   private boolean opened;
   private int btnW;
   private Graphics myg;
   private Color bColor,fColor;
   private Color fourColors[] = new Color[4];
   private boolean recomputePopRect = true; // guich@300_24
   /** if set to true, the popup window will have the height of the screen */
   public boolean fullHeight;

   /** Creates an empty ComboBox */
   public MultiComboBox()
   {
      this((Object [])null);
   }

   /** Creates a ComboBox with the given items */
   public MultiComboBox(Object []items)
   {
      this (new MultiListBox(items));
   }

   /** Creates a ComboBox with a PopList with the given ListBox. You can extend the ListBox to
	  * draw the items by yourself and use this constructor so the PopList will
	  * use your class and not the default ListBox one. Note that this constructor forces
	  * the ListBox.simpleBorder to true. Note: the listbox items must be already set.
	  */
	public MultiComboBox(MultiListBox userListBox)
	{
      pop = new MultiPopList(userListBox);
      btn = Button.createArrowButton(Graphics.ARROW_DOWN,fmH*3/11,Color.BLACK); // guich@240_18
      if (Settings.uiStyle == Settings.PalmOS) btn.setBorder(Button.BORDER_NONE);
      super.add(btn);
	}

   /** do nothing */
   public void add(Control control)
   {
   }
   /** do nothing */
   public void remove(Control control)
   {
   }

   /** Adds an array of Objects to the Listbox */
   public void add(Object []items)
   {
      pop.lb.add(items);
      recomputePopRect = true;
      repaint();
   }

   /** Adds an Object to the Listbox */
   public void add(Object item)
   {
      pop.lb.add(item);
      recomputePopRect = true;
      repaint();
   }

   /** Adds an Object to the Listbox at the given index */
   public void insert(Object item, int index)
   {
      pop.lb.insert(item,index);
      recomputePopRect = true;
      repaint();
   }

   /** Empties the ListBox */
   public void removeAll() // guich@210_13
   {
      pop.lb.removeAll();
      recomputePopRect = true;
      repaint();
   }

   /** Removes an Object from the Listbox */
   public void remove(Object item)
   {
      pop.lb.remove(item);
      recomputePopRect = true;
      repaint();
   }

   /** Removes an Object from the Listbox */
   public void remove(int itemIndex)
   {
      pop.lb.remove(itemIndex);
      recomputePopRect = true;
      repaint();
   }

   /** Sets the Object at the given Index, starting from 0 */
   public void setItemAt(int i, Object s)
   {
      pop.lb.setItemAt(i,s);
      recomputePopRect = true;
      repaint();
   }

   /** Get the Object at the given Index */
   public Object getItemAt(int i)
   {
      return pop.lb.getItemAt(i);
   }

   /** Returns the selected item of the PopList */
   public Object getSelectedItem()
   {
      return pop.lb.getSelectedItem();
   }

   /** Returns the position of the selected item of the PopList */
   public int getSelectedIndex()
   {
      return pop.lb.selectedIndex;
   }
   

	public IntVector getSelectedIndexes() {
		 return pop.lb.selectedItems;
	}
   

   /** Returns all items in this ComboBox */
   public Object []getItems()
   {
      return pop.lb.getItems();
   }

   /** Returns the index of the item specified by the name */
   public int indexOf(Object name)
   {
      return pop.lb.indexOf(name);
   }

   /** Sets the cursor color for this ComboBox. The default is equal to the background slightly darker. Make sure you tested it in 2,4 and 8bpp devices. */
   public void setCursorColor(Color color) // guich@210_19
   {
      pop.lb.setCursorColor(color);
   }

   /** Select an item */
   public void select(int i)
   {
      pop.lb.select(i);
      repaint();
   }

   /** Returns the number of items */
   public int size()
   {
      return pop.lb.itemCount;
   }

   public int getPreferredWidth()
   {
      return pop.getPreferredWidth()+1;
   }
   public int getPreferredHeight()
   {
      return fmH+(Settings.uiStyle == Settings.PalmOS ? 1 : 4);
   }

   /** passes the font to the pop list */
   protected void onFontChanged() // guich@200b4_153
   {
      if (pop != null) pop.setFont(font);
   }
   protected void onBoundsChanged()
   {
      Rect r = getAbsoluteRect(); // guich@230_17
      pop.setRect(r.x, r.y, width, height); // width and height are recalculated by popList! the params could have been modified by the super.setRect, so use them. also, translate to the current parent window coords. guich@241_2: removed win.x and win.y being added to the x,y coords (it was appearing away from the control)

      btnW = btn.getPreferredWidth();
      if (Settings.uiStyle == Settings.PalmOS)
         btn.setRect(0,0,btnW,height); // move button to left
      else
         btn.setRect(width-btnW-2,2,btnW,height-4);
      recomputePopRect = true; // guich@300_24
   }

   public void onEvent(Event event)
   {
      PenEvent pe;
      boolean inside;
      if (opened && event.type != ControlEvent.WINDOW_CLOSED) return;
      switch (event.type)
      {
         case ControlEvent.WINDOW_MOVED:
            if (event.target == getParentWindow())
               onBoundsChanged();
            repaint();
            if (myg != null) myg.free();
            myg = createGraphics();
            break;
         case PenEvent.PEN_DRAG:
            pe = (PenEvent)event;
            inside = contains(x+pe.x,y+pe.y);
            if (event.target == this && inside != armed && pop.lb.itemCount > 0)
            {
               armed = inside;
               if (Settings.uiStyle == Settings.PalmOS)
                  myg.drawCursor(0,0,width,height);
               else
               btn.press(armed);
            }
            break;
         case PenEvent.PEN_DOWN:
            if (event.target == this && !armed && pop.lb.itemCount > 0)
            {
               if (Settings.uiStyle == Settings.PalmOS)
                  myg.drawCursor(0,0,width,height);
               else
                  btn.press(true);
               armed = true;
            }
            break;
         case PenEvent.PEN_UP:
            pe = (PenEvent)event;
            inside = contains(x+pe.x,y+pe.y); // contains is a method of class Control that uses absolute coords
            if (event.target == this && inside && armed)
            {
               if (Settings.uiStyle == Settings.PalmOS)
                  myg.drawCursor(0,0,width,height);
               else
                  btn.press(false);
               armed = false;
               opened = true;
               popupPop();
            }
            break;
         case ControlEvent.WINDOW_CLOSED:
            if (event.target == pop) // an item was selected
            {
               opened = false;
               repaintNow(); // guich@220_46: this repaintNow was after the postEvent, but if in the postEvent the target popped up a window, this repaint now could override the window contents.
               postEvent(new ControlEvent(ControlEvent.PRESSED, this));
            }
            break;
         case ControlEvent.PRESSED:
            if (event.target == btn && pop.lb.itemCount > 0)
            {
               this.requestFocus(); // guich@240_6: avoid openning the combobox when its popped up and the user presses the arrow again
               popupPop();
            }
            break;
         case ControlEvent.FOCUS_IN:
         case ControlEvent.FOCUS_OUT:
            if (event.target == btn) // guich@240_11: change the target focus so parents can catch the focus_in and focus_out event
               event.target = this;
            break;
      }
   }

   private void popupPop()
   {
      if (recomputePopRect)
      {
         recomputePopRect = false;
         Rect r = getAbsoluteRect();
         pop.fullHeight = fullHeight; // guich@330_52
         pop.setRect(r.x,r.y,width,height);
         // guich@320_17
         int sel = pop.lb.selectedIndex;
         pop.lb.selectedIndex = -2;
         pop.lb.select(sel);
      }

      getParentWindow().popupModal(pop);
      pop.lb.requestFocus();
   }

   protected void onColorsChanged(boolean colorsChanged)
   {
      if (colorsChanged)
      {
         btn.setBackForeColors(backColor,foreColor);
         pop.lb.setBackForeColors(backColor,foreColor);
      }
      bColor = getBackColor().brighter();
      fColor = getForeColor();
      Graphics.compute3dColors(enabled,backColor,foreColor,fourColors);
   }

   /** paint the combo's border and the current selected item */
   public void onPaint(Graphics g)
   {
      if (myg == null) myg = createGraphics();
      // guich@200b4_126: repaint the background.
      g.setBackColor(bColor);
      g.fillRect(0,0,width,height);
      if (Settings.uiStyle == Settings.PalmOS) // guich@200b4_112
         g.setClip(btnW,0,width-btnW-1,height-1);
      else
      {
         g.draw3dRect(0,0,width,height,g.R3D_CHECK,false,false,fourColors);
         g.setClip(2,2,width-btnW-3,height-4);
      }
      if (pop.lb.itemCount > 0)
      {
         g.setForeColor(fColor);
//         pop.lb.drawItem(g,pop.lb.selectedIndex,		// gao - this line is buggy
			pop.lb.drawItem(g,pop.lb.getSelectedIndexes().peek(),	// GAO - bug fix for out of date default display 
																					// GAO - show last SELECTED not last clicked on
            (Settings.uiStyle == Settings.PalmOS)?btnW+3:3,(height - fmH) >> 1); // guich@200b4: let the listbox draw the item
      }
   }
   /** Sorts the items of this combobox */
   public void qsort() // guich@220_35
   {
      pop.lb.qsort();
      select(-1);
   }
   

	public void setFirstSelection(boolean b) {
	 pop.firstSelection = b;
	}
	public boolean getFirstSelection() {
	 return pop.firstSelection;
	}


}