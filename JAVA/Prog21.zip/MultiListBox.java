/*********************************************************************************
 *  SuperWaba Virtual Machine, version 3                                       *
 *  Copyright (C) 2002 Guilherme Campos Hazan <guich@superwaba.org.>             *
 *  Copyright (C) 2001 Daniel Tauchke                                            *
 *  All Rights Reserved                                                          *
 *                                                                               *
 *  This library and virtual machine is free software; you can redistribute      *
 *  it and/or modify it under the terms of the Amended GNU Lesser General        *
 *  Public License distributed with this software.                               *
 *                                                                               *
 *  This library and virtual machine is distributed in the hope that it will     *
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of    *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                         *
 *                                                                               *
 *  All software that links or interacts with this library and virtual machine,  *
 *  or any derivative works, require the software to prominently display the     *
 *  following notice:                                                            *
 *                                                                               *
 *                   Created with SuperWaba                                      *
 *                  http://www.superwaba.org                                     *
 *                                                                               *
 *  Please see the software license located at superwaba/license.txt             *
 *  for more details.                                                            *
 *                                                                               *
 *  You should have received a copy of the License along with this software;     *
 *  if not, write to                                                             *
 *                                                                               *
 *     Guilherme Campos Hazan                                                    *
 *     Av. Nossa Senhora de Copacabana 728 apto 605 - Copacabana                 *
 *     Rio de Janeiro / RJ - Brazil                                              *
 *     Cep: 22050-000                                                            *
 *     E-mail: guich@superwaba.org                                               *
 *                                                                               *
 *********************************************************************************/

// ListBox.java written 2001 by Daniel Tauschke and a little modified by guich
// http://www.tauschke.com
// E-mail: tauschke@ tauschke.com

package ca.yourdecor.cc.midp.ui;

import waba.ui.*;
import waba.fx.*;
import waba.util.*;
import waba.sys.*;

/**
 * ListBox is a simple implementation of a Listbox.
 * You can use the up/down keys to scroll and enter the first
 * letter of an item to select it.
 * <p>
 * Note: the color used in the setBackground method will be used in the scrollbar
 * only. The background color of the control will be a lighter version of the
 * given color.
 * <p>
 * Here is an example showing how it can be used:
 *
 * <pre>
 * import waba.ui.*;
 *
 * public class MyProgram extends MainWindow
 * {
 * ListBox lb;
 *
 * public void onStart()
 * {
 *   lb = new ListBox();
 *   add(lb);
 *   lb.add(new String[]{"Daniel","Jenny","Helge","Sandra"});
 *   lb.add("Marc");
 *   // you may set the rect by using PREFERRED only after the items were added.
 *   lb.setRect(10,10,PREFERRED,PREFERRED); // use control's preferred width based on the size of the elements
 * }
 *
 * public void onEvent(Event event)
 * {
 *    switch (event.type)
 *    {
 *       case ControlEvent.PRESSED:
 *          if (event.target == lb)
 *             Object element = lb.getSelectedItem(); // in most cases, this is just a String and may be casted to such
 *    }
 * }
 * }
 * </pre>
 * The first item has index 0.
 */

public class MultiListBox extends Container
{
   protected Vector items = new Vector();
   /**
    * The items which have been selected.  The elements of the Vector are the
    * indexes in the Vector of the items.  So if this Vector is holding
    * [3, 5, 12] it means that the items 3, 5 and 12 have been selected.
    */
   protected IntVector selectedItems = new IntVector();
   protected int offset;
   protected int selectedIndex=-1;
   protected int itemCount;
   protected int visibleItems;
   protected int btnX;
   protected ScrollBar sbar;
   protected boolean simpleBorder; // used by PopList
   private Color fColor,back0,back1;
   private Color fourColors[] = new Color[4];
   private Graphics myg;
   private Color userCursorColor;

   /** Creates an empty Listbox. */
   public MultiListBox()
   {
      this(null);
   }

   /** Creates a Listbox with the given items. */
   public MultiListBox(Object []items)
   {
      super.add(sbar = new ScrollBar());
      sbar.setLiveScrolling(true);
      if (items != null)
      {
         this.items = new Vector(items);
         itemCount = items.length;
      }
      sbar.setMaximum(itemCount);
   }

   /** Adds an array of Objects to the Listbox */
   public void add(Object []moreItems)
   {
      if (itemCount == 0) // guich@310_5: directly assign the array if this listbox is empty
      {
         this.items = new Vector(moreItems);
         itemCount = moreItems.length;
      }
      else
      {
         itemCount += moreItems.length;
         for (int i =0; i < moreItems.length; i++)
            items.add(moreItems[i]);
      }
      sbar.setEnabled(enabled && visibleItems < itemCount);
      sbar.setMaximum(itemCount); // guich@210_12: forgot this line!
   }

   /** Adds an Object to the Listbox */
   public void add(Object item)
   {
      items.add(item);
      itemCount++;
      sbar.setEnabled(enabled && visibleItems < itemCount);
      sbar.setMaximum(itemCount);
   }

   /** Adds an Object to the Listbox at the given index */
   public void insert(Object item, int index)
   {
      items.insert(index,item);
      itemCount++;
      sbar.setEnabled(enabled && visibleItems < itemCount);
      sbar.setMaximum(itemCount);
   }

   /** Empties this ListBox, setting all elements of the array to <code>null</code>
       so they can be garbage collected.
       <b>Attention!</b> If you used the same object array
       to initialize two ListBoxes (or ComboBoxes), this method will null both ListBoxes
       ('cos they use the same array reference),
       and you'll get a null pointer exception!
    */
   public void removeAll() // guich@210_13
   {
      items.clear();
      selectedItems.clear();
      sbar.setMaximum(0);
      itemCount = 0;
      offset=0;  // wolfgang@330_23
      repaint();
   }

   /** Removes the given index from the Listbox */
   public void remove(int itemIndex) // guich@200final_12: new method
   {
      if (0 <= itemIndex && itemIndex < itemCount)
      {
         items.del(itemIndex);
         itemCount--;
         sbar.setMaximum(itemCount);
         sbar.setEnabled(enabled && visibleItems < itemCount);

         if (selectedIndex == itemCount) // last item was removed?
            select(selectedIndex-1);
         if ( itemCount == 0 )  // olie@200b4_196: if after removing the list has 0 items, select( -1 ) is called, which does nothing (see there), then selectedIndex keeps being 0 which is wrong, it has to be -1
            selectedIndex = -1;
         if (itemCount <= visibleItems && offset != 0) // guich@200final_13
            offset = 0;
         repaint();
      }
   }

   /** Removes an Object from the Listbox */
   public void remove(Object item)
   {
      int index;
      if (itemCount > 0 && (index=items.find(item)) != -1)
         remove(index);
   }

   /** Sets the Object at the given Index, starting from 0 */
   public void setItemAt(int i, Object s)
   {
      if (0 <= i && i < itemCount)
      {
         items.set(i,s);
         repaint();
      }
   }

   /** Get the Object at the given Index */
   public Object getItemAt(int i)
   {
      if (0 <= i && i < itemCount)
         return items.items[i];//get(i);
      return "";
   }

   /** Returns the selected item of the Listbox or an empty Object if none is selected */
   public Object getSelectedItem()
   {
      return selectedIndex >= 0 ? items.items[selectedIndex] : ""; // guich@200b4: handle no selected index yet.
   }

   /** Returns the position of the selected item of the Listbox or -1 if the listbox has no selected index yet. */
   public int getSelectedIndex()
   {
      return selectedIndex;
   }
   
   public IntVector getSelectedIndexes() {
   		return selectedItems;
   }

   /** Returns all items in this ListBox. If the elements are Strings, the array
     * can be casted to String[].
     */
   public Object []getItems()
   {
      return items.toObjectArray();
   }

   /** Returns the index of the item specified by the name */
   public int indexOf(Object name)
   {
      return items.find(name);
   }

   /** Select an item and scroll to it if necessary. Note: select must be called only after the control has been added to the container and its rect has been set. */
   public void select(int i)
   {
   	handleClick(i);

      if (0 <= i && i < itemCount && i != selectedIndex && height != 0)
      {
         offset=i;
         int vi = sbar.getVisibleItems();
         int ma = sbar.getMaximum();
         if (offset+vi > ma) // astein@200b4_195: fix list items from being lost when the comboBox.select() method is used
           offset=Math.max(ma-vi,0); // guich@220_4: fixed bug when the listbox is greater than the current item count

         selectedIndex = i;
         sbar.setValue(offset); // guich@210_9: fixed scrollbar update when selecting items
         repaint();
      }
      else
      if (i == -1) // guich@200b4_191: unselect all items
      {
         offset = 0;
         sbar.setValue(0);
         selectedIndex = -1;
         repaint();
      }
      

      
   }

   /** Returns the number of items */
   public int size()
   {
      return itemCount;
   }

   /** do nothing */
   public void add(Control control)
   {
   }
   /** do nothing */
   public void remove(Control control)
   {
   }

   /** returns the preferred width, ie, the size of the largest item plus 20. */
   public int getPreferredWidth()
   {
      int maxWidth = 0;
      int n = itemCount;
      for (int i = 0; i < n; i++)
         maxWidth = Math.max(getItemWidth(i), maxWidth);

      return maxWidth + (simpleBorder?4:6) + sbar.getPreferredWidth();
   }

   /** returns the number of items multiplied by the font metrics height */
   public int getPreferredHeight()
   {
      int n = itemCount;
      int h = Math.max(fmH*n,sbar.getPreferredHeight())+(simpleBorder?4:6);
      return n==1 ? h-1 : h;
   }

   /* this is needed to recalculate the box size for the selected item if the control is resized by the main application */
   protected void onBoundsChanged()
   {
      int btnW = sbar.getPreferredWidth();
      int m = simpleBorder?1:2;
      visibleItems = (height-m-2) / fmH;
      sbar.setMaximum(itemCount);
      sbar.setVisibleItems(visibleItems);
      sbar.setEnabled(visibleItems < itemCount);
      btnX = width - m - btnW;

      if (Settings.uiStyle == Settings.PalmOS)
         {btnX--; m++;}
      sbar.setRect(btnX,m,btnW,height-(m<<1));
   }

   /** Searches this ListBox for an item with the first letter matching the given char. The search is made case insensitive. Note: if you override this class you must implement this method. */
   protected void find(char c)
   {
      for (int i =0; i < itemCount; i++)
      {
         String s = items.items[i].toString(); // guich@220_37
         if (s.length() > 0 && Convert.toUpperCase(s.charAt(0)) == c && selectedIndex != i) // first letter matches and not the already selected index?
         {
            select(i);
            repaint();
            break; // end the for loop
         }
      }
   }
   public void onEvent(Event event)
   {
      PenEvent pe;
      switch (event.type)
      {
         case ControlEvent.WINDOW_MOVED:
            if (myg != null) myg.free();
            myg = createGraphics();
            break;
         case ControlEvent.PRESSED:
            if (event.target == sbar)
            {
               int newOffset = sbar.getValue();
               if (newOffset != offset) // guich@200final_3: avoid unneeded repaints
               {
                  offset = newOffset;
                  repaint();
               }
            }
            break;
         case PenEvent.PEN_DRAG:
         case PenEvent.PEN_DOWN:
            if (event.target != this) break;
            pe = (PenEvent)event;
            if (pe.x < btnX && contains(this.x+pe.x,this.y+pe.y))// && ((pe.y < fmH*drawItems) && (pe.y<fmH*itemCount-1)))
            {
               int newSelection = ((pe.y- (simpleBorder?3:4)) / fmH) + offset; // guich@200b4: corrected line selection
/*               if (newSelection != selectedIndex && newSelection < itemCount)
               {
//                  if (selectedIndex >= 0) drawCursor(myg,selectedIndex,false);
                  drawCursor(myg,selectedIndex,true);
            
                  
               } else if (newSelection == selectedIndex) {
               }
*/
           		handleClick(newSelection);
            	selectedIndex = newSelection;
           		
           		if (selectedItems.find(newSelection) != -1) {
           			drawCursor(myg,newSelection,true);
           		} else {
           			drawCursor(myg,newSelection,false);
           		}
           		

            }
            break;
         case KeyEvent.KEY_PRESS:
            int key = ((KeyEvent)event).key;
            if (key == IKeys.PAGE_UP || key == IKeys.PAGE_DOWN || key == IKeys.UP || key == IKeys.DOWN || key == IKeys.JOG_UP || key == IKeys.JOG_DOWN) // guich@220_19 - guich@330_45
               sbar.onEvent(event);
            else
               find(Convert.toUpperCase((char)key));
            break;
         case PenEvent.PEN_UP:
            if (event.target != this) break;
            pe = (PenEvent)event;
            // Post the event
            int newSelection = ((pe.y- (simpleBorder?3:4)) / fmH) + offset; // guich@200b4_2: corrected line selection
            if (contains(x+pe.x,y+pe.y) && pe.x < btnX && newSelection < itemCount)
               postEvent(new ControlEvent(ControlEvent.PRESSED, this));
            break;
      }
      
   }

   public void setEnabled(boolean enabled)
   {
      if (enabled != this.enabled)
      {
         this.enabled = enabled;
         onColorsChanged(false);
         sbar.setEnabled(enabled && visibleItems < itemCount);
         repaint(); // now the controls have different l&f for disabled states
      }
   }

   protected void onColorsChanged(boolean colorsChanged)
   {
      if (colorsChanged)
         sbar.setBackForeColors(backColor,foreColor);
      fColor = getForeColor();
      back0  = getBackColor().brighter();
      back1  = userCursorColor!=null?userCursorColor:(back0.equ != Color.WHITE.equ)?backColor:back0.getCursorColor();//guich@300_20: use backColor instead of: back0.getCursorColor(); // guich@210_19
      if (fColor.equ == back1.equ) // guich@200b4_206: ops! same color?
         fColor = foreColor;
      Graphics.compute3dColors(enabled,backColor,foreColor,fourColors);
   }

   public void onPaint(Graphics g)
   {
      if (myg == null) myg = createGraphics();
      // Draw background and borders
      g.setBackColor(back0);
      g.fillRect(0,0,btnX,height);
      g.setForeColor(foreColor);
      if (simpleBorder && Settings.uiStyle == Settings.WinCE)
         g.drawRect(0,0,width,height);
      else
         g.draw3dRect(0,0,width,height,(Settings.uiStyle == Settings.PalmOS)?g.R3D_SHADED:g.R3D_CHECK,false,false,fourColors);

      int dx = 3;
      int dy = 3;
      if (Settings.uiStyle == Settings.PalmOS) dy--;
      if (simpleBorder) {dx--; dy--;}

      g.setForeColor(fColor);
      g.setClip(dx-1,dy-1,btnX-dx,fmH * visibleItems+1);
      int greatestVisibleItemIndex = Math.min(itemCount, visibleItems+offset); // code corrected by Bjoem Knafla
      for (int i = offset; i < greatestVisibleItemIndex; ++i,dy += fmH)
         drawItem(g,i,dx,dy); // guich@200b4: let the user extend ListBox and draw itself the items
         
         
//      if (selectedIndex >= 0) drawCursor(g,selectedIndex,true);
	// Alex Moots.  Paint the selected items
	for (int i = 0; i < selectedItems.size(); i ++) {
		drawCursor(g,selectedItems.elementAt(i),true);
		Vm.debug("\tdrawing: " + selectedItems.elementAt(i));
	}
   }

   /** Sets the cursor color for this ListBox. The default is equal to the background slightly darker. Make sure you tested it in 2,4 and 8bpp devices. */
   public void setCursorColor(Color color)
   {
      this.userCursorColor = color;
      onColorsChanged(true);
   }
   /** You can extend ListBox and overide this method to draw the items */
   protected void drawItem(Graphics g, int index, int dx, int dy)
   {
      //Vm. debug(this+" index: "+index+", items.size: "+items.size()+", dx,dy = "+dx+","+dy);
      if (0 <= index && index < itemCount)
         g.drawText(items.items[index].toString(),dx,dy);
   }
   /** Returns the width of the given item index with the current fontmetrics. Note: if you overide this class you must implement this method. */
   protected int getItemWidth(int index)
   {
      return fm.getTextWidth(items.items[index].toString());
   }

   protected void drawCursor(Graphics g, int sel, boolean on)
   {
      if (offset <= sel && sel < visibleItems+offset && sel < itemCount)
      {
         int dx = 3;
         int dy = 4;
         if (Settings.uiStyle == Settings.PalmOS) dy--;
         if (simpleBorder) {dx--; dy--;}
         dy += (sel-offset) * fmH;
         g.setClip(dx-1,dy-1,btnX-dx,Math.min(fmH * visibleItems, this.height-dy)); // guich@200b4_83: fixed selection overflowing paint area
         g.setForeColor(on?back0:back1);
         g.setBackColor(on?back1:back0);
         int w = Math.min(getItemWidth(sel),btnX-4);
         if (w == 0) w = btnX-4; // guich@200final_5: if item is a zero length string, invert the complete row.
         g.eraseRect(dx-1,dy-1,w+2,fmH+fm.getDescent()); // only select the Object - guich@200b4_130
      }
   }

   /** Sets the border of the listbox to be not 3d if flag is true. */
   public void setSimpleBorder(boolean simpleBorder) // guich@200b4_93
   {
      this.simpleBorder = simpleBorder;
   }

   /** Sorts the elements of this ListBox. The current selection is cleared. */
   public void qsort() // guich@220_35
   {
      items.qsort();
      select(-1);
   }
   
   private void handleClick(int clickedOnIndex) {
   	if (clickedOnIndex != -1) {
	   	// Alex Muc.  code to turn on/off the selection of an item for this
	   	// multi select list box.
	   	int foundIndex = selectedItems.find(clickedOnIndex);
	   	// We didn't find the foundIndex in the list of selected indexes, so select it.
	   	if (foundIndex == -1) {
	   	  selectedItems.add(clickedOnIndex);
	   	// We did find the foundIndex in the list of selected indexes, so unselect it.
	   	} else {
	   	  selectedItems.removeElementAt(foundIndex);
	   	}
   	}

   	Vm.debug(clickedOnIndex + " ******SELECTED INDEXES********");
   	for (int i = 0; i < selectedItems.size(); i ++) {
   	  Vm.debug((String) items.elementAt(selectedItems.elementAt(i)));
   	}

   }
}