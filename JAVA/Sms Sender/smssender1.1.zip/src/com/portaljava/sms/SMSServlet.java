package com.portaljava.sms;

import java.io.*;
import java.util.Map;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.portaljava.sms.senders.Sender;

/**
 * Servlet que recebe dados de um formul�rio Html, valida seus dados, 
 * inst�ncia um Enviador de SMS adequado e envia a mensagem.
 * 
 * @author Franklin Samir (franklin@portaljava.com)
 * Data: 04/11/2002
 * 
 */
public class SMSServlet extends HttpServlet {

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		processRequest(request, response);
	}

	public void doPost(
		HttpServletRequest request,
		HttpServletResponse response)
		throws ServletException, IOException {
		processRequest(request, response);
	}

	private boolean validateRequest(HttpServletRequest request) throws ServletException{
		Map formValues = request.getParameterMap();

		/* Verifica se o form obedece o padr�o  */
		if (!( formValues.containsKey("redirectTo")
			&& formValues.containsKey("from"))
			&& formValues.containsKey("toPhone")
			&& formValues.containsKey("fromPhone")
			&& formValues.containsKey("message")) {
			throw new ServletException("Invalid Form format");
		}
		else
			return true;
	}

	private void processRequest(
		HttpServletRequest request,
		HttpServletResponse response)
		throws ServletException, IOException {

		HttpSession session = request.getSession();

		if (validateRequest(request)) {

			
			SMSData data = new SMSData();
			//data.setToName(to);

			data.setToPhone("98185203");
			data.setFromName("from");
			data.setFromPhone("91452725");
			data.setMessageText("teste");
			data.setDDD(51);

			((Sender) SenderFactory.getInstance(data)).send(data);

			/* Redireciona para a URL definida no form. */
			String url = request.getParameter("redirectTo");
			response.sendRedirect(url);
		}
		else
			response.sendRedirect("errorPage.jsp");
			
	}

}
