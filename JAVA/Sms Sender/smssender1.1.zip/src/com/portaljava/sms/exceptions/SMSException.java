package com.portaljava.sms.exceptions;

public class SMSException extends Exception{
	
	public SMSException(String error) {
		new Exception("SMS Exception: " + error );		
	}
	
	public SMSException(Exception error){
		new Exception("SMS Exception: " + error );		
	}

}
