package com.portaljava.sms.senders;

import java.net.*;

import com.portaljava.sms.SMSData;
import com.portaljava.sms.exceptions.SMSException;
public class ClaroDigital extends Sender implements ISender{
	
	public boolean send(SMSData smsData){	
        try {


            String pre1 = Integer.toString( smsData.getDDD() );
            
            //pre1 = pre1.substring(1, pre1.length());
            String min = smsData.getToPhone();
            
            String sender = URLEncoder.encode( smsData.getFromName() );
            
            String msg1 = URLEncoder.encode(smsData.getMessageText());
            String encodedQuery = "pre1=" + pre1 + "&min=" + min + "&sender=" + sender + "&msg=" + msg1+"&janela=Sim" ;
            URL url = new URL("http://www.claroonline.com.br/submitsms.asp?" + encodedQuery);
            System.out.println(url.toString());
            url.openConnection().getInputStream();
        }
        catch(Exception e){
            new SMSException(e);
        }
    
		return false;
	}

}
