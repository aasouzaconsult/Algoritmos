package com.portaljava.sms.senders;

import com.portaljava.sms.SMSData;;

public abstract class Sender {
//	protected SMSData smsData;
	
	public abstract boolean send( SMSData smsData);	
}
