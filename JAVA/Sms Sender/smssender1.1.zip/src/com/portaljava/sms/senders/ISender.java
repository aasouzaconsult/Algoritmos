package com.portaljava.sms.senders;

import com.portaljava.sms.SMSData;


public interface ISender {
	
}
