package com.portaljava.sms;

import java.util.Date;

/**
 * Value Object respons�vel por armazenar os dados de uma SMS.
 * 
 * @author Franklin Samir (franklin@portaljava.com)
 * 
 */
public class SMSData {
	/**
	 * Nome do remetente.	 */
	protected String fromName;
	
	/**
	 * Nome do destinat�rio.	 */
	protected String toName;
	
	/**
	 * Telefone do remetente.	 */
	protected String fromPhone;
	/**
	 * Telefone do destinat�rio	 */
	protected String toPhone;
	
	/**
	 * Mensagem.	 */
	protected String messageText;
	
	/**
	 * Data de envio.	 */
	protected Date sentDate;	
	
	/**
	 * DDD do destinat�rio.	 */
	protected int DDD;
	

	/**
	 * Retorna fromName.
	 * @return String
	 */
	public String getFromName() {
		return fromName;
	}

	/**
	 * Retorna fromPhone.
	 * @return String
	 */
	public String getFromPhone() {
		return fromPhone;
	}

	/**
	 * Retorna messageText.
	 * @return String
	 */
	public String getMessageText() {
		return messageText;
	}

	/**
	 * Retorna sentDate.
	 * @return Date
	 */
	public Date getSentDate() {
		return sentDate;
	}

	/**
	 * Retorna toName.
	 * @return String
	 */
	public String getToName() {
		return toName;
	}

	/**
	 * Retorna toPhone.
	 * @return String
	 */
	public String getToPhone() {
		return toPhone;
	}

	/**
	 * Seta fromName.
	 * @param fromName The fromName to set
	 */
	public void setFromName(String fromName) {
		this.fromName = fromName;
	}

	/**
	 * Seta fromPhone.
	 * @param fromPhone The fromPhone to set
	 */
	public void setFromPhone(String fromPhone) {
		this.fromPhone = fromPhone;
	}

	/**
	 * Seta messageText.
	 * @param messageText The messageText to set
	 */
	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}

	/**
	 * Seta sentDate.
	 * @param sentDate The sentDate to set
	 */
	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}

	/**
	 * Seta toName.
	 * @param toName The toName to set
	 */
	public void setToName(String toName) {
		this.toName = toName;
	}

	/**
	 * Seta toPhone.
	 * @param toPhone The toPhone to set
	 */
	public void setToPhone(String toPhone) {
		this.toPhone = toPhone;
	}

	/**
	 * Retorna DDD.
	 * @return int
	 */
	public int getDDD() {
		return DDD;
	}

	/**
	 * Seta DDD.
	 * @param dDD The dDD to set
	 */
	public void setDDD(int dDD) {
		DDD = dDD;
	}

}
