package com.portaljava.sms;

import com.portaljava.sms.senders.ClaroDigital;
import com.portaljava.sms.senders.Sender;
import com.portaljava.sms.senders.TelefonicaRS;

import java.util.ArrayList;

public class SenderFactory {

	private static Sender sender;

	public synchronized static Sender getInstance(SMSData smsData) {
		int DDD = smsData.getDDD();
		if (DDD == 51 || DDD == 55) {
			if (ehClaro( smsData ))
				sender = new ClaroDigital();
			else
				sender = new TelefonicaRS();

		}

		return sender;
	}

	private static boolean ehClaro(SMSData smsData) {
		String toPhone = smsData.getToPhone();
		
		ArrayList prefixosClaro = new ArrayList();
		prefixosClaro.add("91");
		prefixosClaro.add("92");
		prefixosClaro.add("93");
		prefixosClaro.add("94");
		return prefixosClaro.contains(toPhone.substring(0, 2));
	}
}
