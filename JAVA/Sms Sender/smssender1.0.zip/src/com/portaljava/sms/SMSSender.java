package com.portaljava.sms;

/**
 * @version 	1.0
 * @author Franklin Samir (franklin@reefcroenr.org)
 */

import java.net.*;
import java.io.*;
import java.util.*;

public class SMSSender {
	private String toPhone;
	private String senderPhone;
	private String senderName;
	private String message;

	public SMSSender() {
		init();
	}

	public void init() {
		this.senderPhone = null;
		this.senderName = null;
		this.message = null;
		this.toPhone = null;
	}

	public void setPhone(String phone){
		this.senderPhone = phone;
	}

	public void setToPhone(String aPhone){
		this.toPhone = aPhone;
	}

	public void setName(String name){
		this.senderName = name;
	}

	public void setMessage(String message){
		this.message = message;
	}

	public boolean sendToTelefonica() {
		System.out.println("+++++++START+++++++");
		int phoneSize = senderPhone.length(); //phone sender - j
		int nameSize = senderName.length(); //name sender - i
		int messageSize = message.length(); //k

		if (nameSize < 2) {
			System.out.println("Digite o seu nome.");
		}
		else if (phoneSize < 7) {
			System.out.println("Digite o seu telefone corretamente.");
		}
		else if (messageSize == 0) {
			System.out.println("Digite uma mensagem.");
		}
		else {

			String s = message;

			s.replace('\n', '\0');

			String s1 = new String("knd=2&who=" + senderName.trim() + "&msg=" + message.trim() + "&cel=" + senderPhone.trim() + "&rcp=" + "51" + toPhone.trim());
			s1 = cry(true, s1);

			System.out.println("=Parametro montado");
			System.out.println("=" + s1);

			String s2 = null;
			boolean flag1 = false;

			URL url;

			try {
				url = new URL("http://www2.telefonicacelular-rs.net.br/scripts/jimnogtw2.dll/warp?com=" + s1);
				flag1 = true;
				System.out.println("=Url FASE 1 montada:http://www2.telefonicacelular-rs.net.br/scripts/jimnogtw2.dll/warp?com=" + s1);
			}
			catch (MalformedURLException malformedurlexception) {
				System.out.println("=Exce\347\343o 1 na URL fase 1");
				showMessage("4");
				return false;
			}
			catch (Exception exception) {
				System.out.println("=Exce\347\343o 2 na URL fase 1");
				showMessage("40");
				return false;
			}

			DataInputStream datainputstream;
			try {
				InputStream inputstream = url.openStream();
				datainputstream = new DataInputStream(new BufferedInputStream(inputstream));
				System.out.println("=Abrindo conex\343o FASE 2");
			}
			catch (IOException ioexception) {
				System.out.println("=Exce\347\343o 1 na FASE 2");
				showMessage("4");
				return false;
			}

			flag1 = false;

			try {
				s2 = datainputstream.readLine();
				System.out.println("=Lendo linha 1 =" + s2);
				if (s2.startsWith("SYSERR")) {
					System.out.println("=Erro de sistema detectado: " + s2);
					System.err.println("=Erro de sistema detectado: " + s2);
					showMessage("4");
					boolean flag2 = true;
				}
				else if (s2.startsWith("/NAK")) {
					System.out.println("=Lendo linha de final 9=" + s2);
					s2.substring(s2.indexOf(" "), s2.length());
					showMessage("10");
				}
				else if (s2.startsWith("/BAK")) {
					System.out.println("=Lendo linha de final 9=" + s2);
					s2.substring(s2.indexOf(" "), s2.length());
					showMessage("11");
				}
				else if (s2.startsWith("/BOK")) {
					System.out.println("=Lendo linha de final 9=" + s2);
					s2.substring(s2.indexOf(" "), s2.length());
					showMessage("12");
				}
			}
			catch (IOException ioexception1) {
				if (!s2.startsWith("/AOK")) {
					System.out.println("=Lendo linha de final 9 NOK=" + s2);
					showMessage("20");
				}
			}

			if (s2.startsWith("/AOK")) {
				System.out.println("=Lendo linha de final 9 OK=" + s2);
				showMessage("15");
			}
		}

		System.out.println("+++++++++++++ FINAL ++++++++++++++");
		System.out.println("Enviei mensagem para: "+this.toPhone);
		System.out.println("phone sender : "+this.senderPhone);
		System.out.println("name sender: "+ this.senderName);
		System.out.println("message: "+ this.message);

		return true;
	}

	public void showMessage(String s) {
		boolean flag = false;
		try {
			URL url = new URL("http://www2.telefonicacelular-rs.net.br/aviso/res.htm?tipo=" + s);
			flag = true;
		}
		catch (MalformedURLException e) {
			System.out.println("ERROR - " + e.toString());
			// enviando = false;

			return;
		}
		//se a resposta da telef�nica for "menssagem processada"
		if (flag && s.equals("15")) {
			//  limpaTudo(false);
			//  enviando = false;
			//setaTexto();
		}
		System.out.println("Sa\355 de SHOWMESSAGE");
	}

	public final String cry(boolean flag, String s) {
		String s2 = "";
		String s1 = new String("WAIAD");
		int i = s1.length() - 1;
		Random random = new Random();
		if (i == 0)
			s1 = new String("YALLO");
		int j = -1;
		char c = '\u0100';
		if (flag) {
			String s3 = new String(s);
			int k = random.nextInt() % 10;
			if (k < 0)
				k *= -1;
			s2 = new String(fi(k) + fo(k));
			for (int i1 = 0; i1 < s3.length(); i1++) {
				int l = (ord(s3.charAt(i1)) + k) % 255;
				if (j < i)
					j++;
				else
					j = 0;
				l ^= ord(s1.charAt(j));
				s2 = s2 + new String(fi(l) + fo(l));
				k = l;
			}

		}
		return s2;
	}
	private final String fi(int i) {
		String s = "";
		if (i / 16 == 10)
			return "a";
		if (i / 16 == 11)
			return "b";
		if (i / 16 == 12)
			return "c";
		if (i / 16 == 13)
			return "d";
		if (i / 16 == 14)
			return "e";
		if (i / 16 == 15)
			return "f";
		else
			return String.valueOf(i / 16);
	}

	private final String fo(int i) {
		String s = "";
		if (i % 16 == 10)
			return "a";
		if (i % 16 == 11)
			return "b";
		if (i % 16 == 12)
			return "c";
		if (i % 16 == 13)
			return "d";
		if (i % 16 == 14)
			return "e";
		if (i % 16 == 15)
			return "f";
		else
			return String.valueOf(i % 16);
	}

	private final int ord(char c) {
		String s =
			"00000000000000000000000000000000 !0#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[00^_`abcdefghijklmnopqrstuvwxyz{|}000000000000000000000000000000000000000000000000000000000000000000\300\301\302\303\304\3050\307\310\311\312\313\314\315\316\3170\321\322\323\324\325\32600\331\332\333\334\33500\340\341\342\343\344\3450\347\350\351\352\353\354\355\356\3570\361\362\363\364\365\36600\371\372\373\374\37500";
		if (s.indexOf(c) != -1) {
			if (c != '0')
				return s.indexOf(c);
			else
				return 48;
		}
		else {
			return 0;
		}
	}

}