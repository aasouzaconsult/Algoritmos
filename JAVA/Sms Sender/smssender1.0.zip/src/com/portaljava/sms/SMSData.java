package com.portaljava.sms;

import java.util.Date;

public class SMSData {
	protected String fromName;
	protected String toName;
	protected String fromPhone;
	protected String toPhone;
	protected String messageText;
	protected Date sentDate;	
	protected int DDD;
	

	/**
	 * Returns the fromName.
	 * @return String
	 */
	public String getFromName() {
		return fromName;
	}

	/**
	 * Returns the fromPhone.
	 * @return String
	 */
	public String getFromPhone() {
		return fromPhone;
	}

	/**
	 * Returns the messageText.
	 * @return String
	 */
	public String getMessageText() {
		return messageText;
	}

	/**
	 * Returns the sentDate.
	 * @return Date
	 */
	public Date getSentDate() {
		return sentDate;
	}

	/**
	 * Returns the toName.
	 * @return String
	 */
	public String getToName() {
		return toName;
	}

	/**
	 * Returns the toPhone.
	 * @return String
	 */
	public String getToPhone() {
		return toPhone;
	}

	/**
	 * Sets the fromName.
	 * @param fromName The fromName to set
	 */
	public void setFromName(String fromName) {
		this.fromName = fromName;
	}

	/**
	 * Sets the fromPhone.
	 * @param fromPhone The fromPhone to set
	 */
	public void setFromPhone(String fromPhone) {
		this.fromPhone = fromPhone;
	}

	/**
	 * Sets the messageText.
	 * @param messageText The messageText to set
	 */
	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}

	/**
	 * Sets the sentDate.
	 * @param sentDate The sentDate to set
	 */
	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}

	/**
	 * Sets the toName.
	 * @param toName The toName to set
	 */
	public void setToName(String toName) {
		this.toName = toName;
	}

	/**
	 * Sets the toPhone.
	 * @param toPhone The toPhone to set
	 */
	public void setToPhone(String toPhone) {
		this.toPhone = toPhone;
	}

	/**
	 * Returns the dDD.
	 * @return int
	 */
	public int getDDD() {
		return DDD;
	}

	/**
	 * Sets the dDD.
	 * @param dDD The dDD to set
	 */
	public void setDDD(int dDD) {
		DDD = dDD;
	}

}
