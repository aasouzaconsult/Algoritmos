package com.portaljava.sms;

import com.portaljava.sms.senders.Sender;


public class TestSMS {
	
	public static void main(String args[]){
		SMSData data = new SMSData();
		//data .setToName("to");
		data .setToName("91452725");
		
		//data.setToPhone("98185203");
		data.setToPhone("91452725");//Igor
		data.setFromName("from");
		//data.setFromPhone("9999999");
		data.setFromPhone("91452725");
		data.setMessageText("teste");
		data.setDDD(51);
		
		((Sender)SenderFactory.getInstance( data )).send( data );
			
		
	}

}
