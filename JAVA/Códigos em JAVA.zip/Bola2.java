/**----------------------------------------------------------------------*/
/** Move uma bola de um lado para outro.                                 */
/** Evita tremido desenhando o fundo sem limpar a tela (m�todo update(). */
/** Como ainda treme um pouco, a solu��o � buferiza��o dupla (Bola3).    */
/** Francisco A. S. Grossi                                               */
/**----------------------------------------------------------------------*/

// Para executar este applet, use: appletviewer Bola2.java         
// <applet code=Bola2.class width=600 height=200>
// </applet>

import java.awt.*;
import java.applet.*;

public class Bola2 extends Applet implements Runnable {
  Thread tarefa;
  final int xco = 40, yco = 40; 
  int x = xco, dx = 4;
  int largura, altura, di�metro;  

  public void init() {
    largura  = getWidth() - 2 * xco;
    altura   = getHeight() - 2 * yco;
    di�metro = altura;
  }

  public void start() {
    if (tarefa == null); {
      tarefa = new Thread(this);
      tarefa.start();
    }
  }

  public void stop() {
    tarefa = null;
  }

  public void run() {
    while (tarefa != null) {
      x += dx; 
      if (x > xco + largura - di�metro) {
        x = xco + largura - di�metro;
        dx *= -1;
      }
      else if (x < xco) {
        x = xco;  
        dx *= -1;
      }
      repaint();
      try {tarefa.sleep(100);} 
      catch (InterruptedException e) {}
    }
  }

  public void update(Graphics tela) {
    paint(tela);
  }

  public void paint(Graphics tela) {

    // Desenha ret�ngulo preto onde a bola se desloca  
    tela.setColor(Color.black);
    tela.fillRect(xco,yco,largura,altura);

    // Desenha bola vermelha
    tela.setColor(Color.red);
    tela.fillOval(x,yco,di�metro,di�metro);

  }

}
