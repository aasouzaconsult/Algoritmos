/*-----------------------------------------------------------------------*/
/* L� um n�mero inteiro e positivo e determina se � primo ou composto.   */
/* Francisco A. S. Grossi                                                */
/*-----------------------------------------------------------------------*/
public class Primo {
  public static void main(String[] s) {
  
   long numero,fator,ultimo;
    boolean primo;

   do 
     numero = Teclado.readLong("Entre um n�mero inteiro maior que 1: ");
   while (numero < 2); 

   primo = numero < 4 || numero % 2 == 1; 
   ultimo = (long) Math.sqrt(numero);
            
   for (fator=3; primo && fator <= ultimo; fator += 2)
     primo = numero % fator != 0;

   if (primo) System.out.println(numero + " � primo");
   else System.out.println(numero + " � composto");
  }

}