/**----------------------------------------------------------------------*/
/** L� v�rios n�meros inteiros entre 1 e 50 e escreve sua moda. Se houver*/
/** mais de uma moda, informa a de maior valor. O fim de dados � indicado*/
/** pela leitura de qualquer n�mero fora do intervalo.                   */
/** Algoritmo: cada n�mero lido � usado como �ndice de um vetor (1 a 50) */
/** cujos elementos s�o usados para contar as freq��ncias correspondentes*/
/** Para cada n�mero lido, soma-se 1 ao elemento cujo �ndice � o n�mero. */
/** Declara-se o vetor com 51 elementos e usam-se os elementos 1 a 50    */
/** para que a correla��o entre �ndice e n�mero seja direta.             */
/** Francisco A. S. Grossi                                               */
/**----------------------------------------------------------------------*/

public class Moda {

  public static void main(String[] args) {
    final int n = 51;              // Tamanho do vetor de freq��ncias 
    int[] frequencia = new int[n];
    int i, x, moda;

    System.out.println("Entre v�rios n�meros entre 1 " + (n-1));
    System.out.println("N�mero fora do intervalo indica fim de dados");

    x = Teclado.readInt("");       // L� o primeiro
    while (x > 0 && x < n) {       // Enquanto for v�lido 
      ++frequencia[x];             // Soma 1 � freq��ncia de x
      x = Teclado.readInt("");     // L� o seguinte 
    }

    for (moda = 1, i = 2; i < n; ++i)
      if (frequencia[i] >= frequencia[moda]) moda = i;

    if (frequencia[moda] > 0)
       System.out.println("\nA moda � " + moda + " e ocorre " +
          frequencia[moda] + "vezes");
    else System.out.println("\nSeq��ncia vazia");
  }

}