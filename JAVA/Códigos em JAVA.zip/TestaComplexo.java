/**----------------------------------------------------------------------*/
/** Programa de teste para a classe de racionais.                        */
/** Usa classe CONSOLE (inclu�da nesta p�gina) para leitura direta.      */
/** Como descende de Object, pode usar o m�todo equals()                 */
/** Como o m�todo toString foi substitu�do, um racional pode ser usado   */
/** diretamente no PRINTLN, pois ele � convertido por este m�todo.       */
/** Francisco A. S. Grossi                                               */
/**----------------------------------------------------------------------*/
public class TestaComplexo {

  public static void main(String argumentos[]) {

    int r = Teclado.readInt("Parte real do primeiro:");
    int i = Teclado.readInt("Parte imagin�ria do primeiro:");
    Complexo a = new Complexo(r,i);

    r = Teclado.readInt("Parte real do segundo:");
    i = Teclado.readInt("Parte imagin�ria do segundo:");
    Complexo b = new Complexo(r,i);

    if(a.equals(b))
      System.out.println("\nOs dois s�o iguais");
    else System.out.println("\nOs dois s�o diferentes");

    System.out.println("Adi��o       = " + a.soma(b));
    System.out.println("Subtra��o    = " + a.subtrai(b));
    System.out.println("Produto      = " + a.multiplica(b));
    System.out.println("Quociente    = " + a.divide(b));
  }

}