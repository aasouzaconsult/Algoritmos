/*-----------------------------------------------------------------------*/
/* Verifica se um n�mero inteiro e positivo � perfeito usando dois       */
/* algoritmos com diferentes efici�ncias.                                */
/* Um n�mero � perfeito quando ele � igual � soma de seus divisores.     */
/* Francisco A. S. Grossi                                                */
/*-----------------------------------------------------------------------*/
import Teclado;
public class Perfeito {
/*-----------------------------------------------------------------------*/
/* Verifica se n�mero � perfeito - algoritmo ineficiente.                */
/*-----------------------------------------------------------------------*/
  public static boolean perfeito1(long numero) {
    long soma,i;
    soma = 1;                            /* 1 divide qualquer n�mero   */
    for (i=2; i <= numero/2; ++i)        /* At� metade do n�mero       */
      if (numero % i == 0) soma += i;    /* Acumula, se divide n�mero  */
    return numero == soma;               /* True ou false              */
   }
/*-----------------------------------------------------------------------*/
/* Verifica se n�mero � perfeito - algoritmo eficiente.                  */
/*-----------------------------------------------------------------------*/
   public static boolean perfeito2(long numero) {
     long soma,i;
     double raiz = Math.sqrt(numero);    /* Limite para o divisor      */
     soma = 1;                           /* 1 divide qualquer n�mero   */
     for (i=2; i < raiz; ++i)            /* At� antes da raiz quadrada */
       if (numero % i == 0)              /* Se divide n�mero           */
         soma += i + numero/i;           /* Soma divisor e quociente   */
     if (raiz == (int) raiz)             /* Se raiz for inteira, ela   */
       soma += (int) raiz;               /* precisa ser somada         */
     return numero == soma;              /* True ou false              */
   }
/*-----------------------------------------------------------------------*/
/* Programa principal.                                                   */
/* L� um n�mero e verifica se � inteiro e positivo.                      */
/* Invoca as duas fun��es e diz se o n�mero � ou n�o perfeito.           */
/*-----------------------------------------------------------------------*/
  public static void main(String argumentos[]) {
    long numero;

    do {
      numero = Teclado.readLong("Entre um n�mero n�o negativo: ");
    } while (numero < 0);

    if (perfeito1(numero))                   
      System.out.println(numero + " � perfeito");
    else System.out.println(numero + " n�o � perfeito\n");

   if (perfeito2(numero))                    
      System.out.println(numero + " � perfeito");
   else System.out.println(numero + " n�o � perfeito\n");
  }

}