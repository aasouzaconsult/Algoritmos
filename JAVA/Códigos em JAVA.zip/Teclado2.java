/**----------------------------------------------------------------------*/
/** Mostra informa��es a respeito de eventos de teclado.                 */
/** Francisco A. S. Grossi                                               */
/**----------------------------------------------------------------------*/

// Para executar este applet, use: appletviewer Teclado2.java   
// <applet code=Teclado2.class width=400 height=500>
// </applet>

import java.awt.*; 
import java.applet.*;
import java.awt.event.*;

public class Teclado2 extends Applet 
       implements KeyListener, ActionListener {

  TextArea area = new TextArea(25,50);
  TextField entrada = new TextField(30);
  Button limpa = new Button("Limpa");
 
  public void init() {
    Panel painel = new Panel();
    painel.setLayout(new BorderLayout());
    painel.add(entrada,BorderLayout.NORTH);
    painel.add(area,BorderLayout.CENTER);
    painel.add(limpa,BorderLayout.SOUTH);
    area.setEditable(false);
    add(painel);
    limpa.addActionListener(this);
    entrada.addKeyListener(this);
    entrada.requestFocus();
  }

  public void keyPressed(KeyEvent e) {
    mostra(e,"Evento: KEY PRESSED");
  }
  
  public void keyTyped(KeyEvent e) {
    mostra(e,"Evento: KEY TYPED");
  }

  public void keyReleased(KeyEvent e) {
    area.append("Evento: KEY RELEASED\n");
  }

  public void actionPerformed(ActionEvent e) {
    if (e.getSource() == limpa) {
      area.setText("");
      entrada.setText("");
      entrada.requestFocus();
    }
  }

  protected void mostra(KeyEvent e, String s){
    char simbolo = e.getKeyChar();
    int codigo = e.getKeyCode();
    int modificadores = e.getModifiers();

    String str4 = "N�o h� modificadores";
    String str1 = "Caractere = '" + simbolo + "'";
    String str2 = "C�digo = " + codigo + " ("
       + e.getKeyText(codigo) + ")";
    String str3 = e.getKeyModifiersText(modificadores);
    if (str3.length() > 0) 
       str4 = "Modificadores = " + str3;
    area.append(s + "\n   " + str1 + "\n   "
      + str2 + "\n   " + str4 + "\n");
  }

}