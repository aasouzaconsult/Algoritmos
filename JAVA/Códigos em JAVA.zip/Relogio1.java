/**----------------------------------------------------------------------*/
/** Exemplo de um applet com thread: rel�gio digital simples.            */
/** A classe Applet cont�m m�todos vazios para todos os m�todos          */
/** obrigat�rios; portanto, somente � neces�rio codificar aqueles        */
/** que cont�m algum c�digo do usu�rio. Os m�todos vazios est�o          */
/** codificados neste exemplo para explicar o seu funcionamento.         */
/** Francisco A. S. Grossi                                               */
/**----------------------------------------------------------------------*/

// Para executar este applet, use: appletviewer Relogio1.java            
// <applet code=Relogio1.class width=500 height=100>
// </applet>

import java.awt.*;
import java.util.*;
import java.applet.*;

public class Relogio1 extends Applet implements Runnable {
  Font fonte = new Font("TimesRoman",Font.BOLD,24);
  Thread tarefa;
  AudioClip tique;
/*-----------------------------------------------------------------------*/
/* Chamado pelo browser quando o applet � carregado.                     */
/*-----------------------------------------------------------------------*/
  public void init() {
    tique = getAudioClip(getCodeBase(),"tique.au");
  }
/*-----------------------------------------------------------------------*/
/* Chamado ap�s o init() e cada vez que o us�rio retorna � p�gina.       */
/*-----------------------------------------------------------------------*/
  public void start() {
    if (tarefa == null) {
      tarefa = new Thread(this);
      tarefa.start();
    }
  }
/*-----------------------------------------------------------------------*/
/* Deve ser chamado quando o applet deve deixar de executar.             */
/* Chamado automaticamente quando o us�rio minimiza ou deixa a p�gima.   */ 
/* Normalmente, modifica uma vari�vel que indica o fim de sua execu��o.  */
/*-----------------------------------------------------------------------*/
  public void stop() {
    tarefa = null;
  }
/*-----------------------------------------------------------------------*/
/* Chamado por uma mensagem start() emitido, geralmente no m�todo start()*/
/*-----------------------------------------------------------------------*/
  public void run() {
    while (tarefa != null) {
      try {
        tarefa.sleep(1000);
        if (tique != null) tique.play();
      } 
      catch (InterruptedException e) {}
      repaint();    // invoca paint sem necessidade de par�metro
    }
  }
/*-----------------------------------------------------------------------*/
/* Chamado ap�s o init() e o m�todo start() come�ou a ser executado.     */
/* Chamado tamb�m todas as vezes em que o applet precisa ser redesenhado */
/* devido, por exemplo, a cobertura da tela por outra janela.            */
/*-----------------------------------------------------------------------*/
  public void paint(Graphics tela) {
    GregorianCalendar data = new GregorianCalendar();
    tela.setFont(fonte);
    tela.drawString("" + data.getTime(),10,50);
  }
/*-----------------------------------------------------------------------*/
/* Chamado pelo browser quando o applet � removido da mem�ria, o que     */
/* ocorre, normalmente, quando o usu�rio abandona a p�gina.              */
/*-----------------------------------------------------------------------*/
  public void destroy() {
  }

}