/**----------------------------------------------------------------------*/
/** Mostra as coordenadas dos cliques do mouse.                          */
/** Mostra se o clique ocorreu dentro ou fora do ret�ngulo.              */
/** Informa se o mouse est� dentro ou fora da �rea do applet.            */
/** Francisco A. S. Grossi                                               */
/**----------------------------------------------------------------------*/

// Para executar este applet, use: appletviewer Mouse1.java         
// <applet code=Mouse1.class width=600 height=200>
// </applet>

import java.awt.*;
import java.applet.*;
import java.awt.event.*; 

public class Mouse1 extends Applet implements MouseListener {
  int xpos = -1;                     // Coordenada X do �ltimo clique
  int ypos = -1;                     // Coordenada Y do �ltimo clique
  int xco=40,yco=40,largura,altura;  // Ret�ngulo
  String msgarea = "Applet come�ou"; 
  String msgret = "";                // Dentro ou fora do ret�ngulo
  Font fonte = new Font("Courier New",Font.BOLD,14);

  public void init() {
    setBackground(Color.orange);
    setFont(fonte);
    addMouseListener(this);
  } 

  public void paint(Graphics g) {
    g.setColor(Color.blue); 
    Rectangle rec = getBounds();
    largura = rec.width-2*xco;
    altura = rec.height-2*yco;
    g.fillRect(xco,yco,largura,altura);
    g.setColor(Color.white); 
    if (xpos >= 0) g.drawString("(" + xpos + "," + ypos + ")",xpos,ypos); 
    g.setColor(Color.black); 
    g.drawString("Ret�ngulo " + largura + "X" + altura + 
                 " em (" + xco + "," + yco + ")",xco,yco+altura+15);
    g.drawString(msgret,xco,yco+altura+30);
    showStatus(msgarea);
  } 

  public void mouseClicked (MouseEvent e) { 
    String bot�o,posi��o;
    xpos = e.getX();            // Coordenada X do clique
    ypos = e.getY();            // Coordenada Y do clique
    int n = e.getClickCount();  // Quantidade de cliques
    String s = (n > 1) ? "es" : "";
    
    if ((e.getModifiers() & InputEvent.BUTTON1_MASK) != 0)
      bot�o = "esquerdo ";
    else if ((e.getModifiers() & InputEvent.BUTTON2_MASK) != 0)
      bot�o = "do meio ";
    else bot�o = "direito ";

    if (xpos >= xco && xpos <= xco+largura &&
        ypos >= yco && ypos <= yco+altura) 
      posi��o = "dentro";
    else posi��o = "fora";
    
    msgret = "Clicou " + n + " vez" + s + " com o bot�o " +
                bot�o + posi��o + " do ret�ngulo azul";

    repaint(); 
  } 

   public void mouseEntered (MouseEvent e) {
     msgarea = "Mouse na �rea do applet";
     repaint();
   } 

   public void mouseExited (MouseEvent e) {
     msgarea = "Mouse fora da �rea do applet";
     repaint();
   }  

   public void mousePressed (MouseEvent e) {} 
   public void mouseReleased (MouseEvent e) {}  

}