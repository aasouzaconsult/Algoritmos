/**----------------------------------------------------------------------*/
/** Mostra as coordenadas do passeio do mouse pela tela.                 */
/** Informa se o mouse est� dentro ou fora da �rea do applet.            */
/** Evita tremidos apagando apenas a parte alterada da tela              */
/** Francisco A. S. Grossi                                               */
/**----------------------------------------------------------------------*/

// Para executar este applet, use: appletviewer Mouse2.java         
// <applet code=Mouse2.class width=600 height=200>
// </applet>

import java.awt.*;
import java.applet.*;
import java.awt.event.*; 

public class Mouse2 extends Applet 
       implements MouseListener, MouseMotionListener {
  Point corrente;                  // Coordenada do �ltimo clique
  Point anterior;                  // Coordenada anterior  
  String sc, sa;                   // Escreve posi��o do ponto  
  String msgarea = "Applet come�ou"; 
  Font fonte = new Font("Courier New",Font.BOLD,14);

  public void init() {
    setBackground(Color.blue);
    setFont(fonte);
    addMouseListener(this);
    addMouseMotionListener(this);
  } 

  public void update(Graphics g) {
    if (anterior != null) {
      g.setColor(getBackground()); 
      g.drawString(sa,anterior.x,anterior.y);
    }
    paint(g);
  }

  public void paint(Graphics g) {
    if (corrente != null) {
      sc = "(" + corrente.x + "," + corrente.y + ")";
      g.setColor(Color.white); 
      g.drawString(sc,corrente.x,corrente.y); 
      g.setColor(Color.black); 
      showStatus(msgarea);
      anterior = corrente;         // Lembra anterior para apagar 
      sa = sc;                     // Lembra anterior para apagar 
    }
  } 

  public void mouseMoved (MouseEvent e) { 
    corrente = e.getPoint();     
    repaint(); 
  } 

   public void mouseEntered (MouseEvent e) {
     msgarea = "Mouse na �rea do applet";
     repaint();
   } 

   public void mouseExited (MouseEvent e) {
     msgarea = "Mouse fora da �rea do applet";
     repaint();
   }  

   public void mouseClicked (MouseEvent e) {}
   public void mousePressed (MouseEvent e) {} 
   public void mouseReleased (MouseEvent e) {}  
   public void mouseDragged (MouseEvent e) {}

}