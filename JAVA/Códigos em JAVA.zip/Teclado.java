/**----------------------------------------------------------------------*/
/** Classe para leitura direta de valores do teclado.                    */
/** Francisco A. S. Grossi                                               */
/**----------------------------------------------------------------------*/
import java.io.*;
public final class Teclado { 
/*-----------------------------------------------------------------------*/
/* Apenas emite uma mensagem (prompt).                                   */
/*-----------------------------------------------------------------------*/
  public final static void printPrompt(String prompt) {
    System.out.print(prompt + " ");
    System.out.flush();
  }
/*-----------------------------------------------------------------------*/
/* L� um string SEM prompt inicial; o NL final n�o faz parte do string.  */
/*-----------------------------------------------------------------------*/
  public final static String readLine() {
    String leitura = "";
    BufferedReader in = new BufferedReader(
      new InputStreamReader(System.in));
    try {leitura = in.readLine();}
    catch (IOException e) {}
    return leitura;
  }
/*-----------------------------------------------------------------------*/
/* L� um string COM prompt inicial; o NL final n�o faz parte do string.  */
/*-----------------------------------------------------------------------*/
  public final static String readLine(String prompt) {
    printPrompt(prompt);
    return readLine();
  }
/*-----------------------------------------------------------------------*/
/* L� um caractere qualquer, inclusive NL.                               */
/*-----------------------------------------------------------------------*/
  public final static char readChar(String prompt) {
    String s;
    do {
      s = readLine(prompt);
    } while (s.length() == 0);
    return s.charAt(0); 
  }
/*-----------------------------------------------------------------------*/
/* L� um inteiro de 8 bits; rejeita entrada inv�lida e pede novamente.   */
/*-----------------------------------------------------------------------*/
  public static byte readByte(String prompt) {
    while (true) {
      printPrompt(prompt);
      try {return Byte.parseByte(readLine().trim());}
      catch(NumberFormatException e) {
        System.out.println("N�o � n�mero inteiro; entre novamente!");
      }
    }
  }
/*-----------------------------------------------------------------------*/
/* L� um inteiro de 16 bits; rejeita entrada inv�lida e pede novamente.  */
/*-----------------------------------------------------------------------*/
  public static short readShort(String prompt) {
    while (true) {
      printPrompt(prompt);
      try {return Short.parseShort(readLine().trim());}
      catch(NumberFormatException e) {
        System.out.println("N�o � n�mero inteiro; entre novamente!");
      }
    }
  }
/*-----------------------------------------------------------------------*/
/* L� um inteiro de 32 bits; rejeita entrada inv�lida e pede novamente.  */
/*-----------------------------------------------------------------------*/
  public final static int readInt(String prompt) {
    while (true) {
      printPrompt(prompt);
      try {return Integer.parseInt(readLine().trim());}
      catch(NumberFormatException e) {
        System.out.println("N�o � n�mero inteiro; entre novamente!");
      }
    }
  }
/*-----------------------------------------------------------------------*/
/* L� um inteiro de 64 bits; rejeita entrada inv�lida e pede novamente.  */
/*-----------------------------------------------------------------------*/
  public final static long readLong(String prompt) {
    while (true) {
      printPrompt(prompt);
      try {return Long.parseLong(readLine().trim());}
      catch(NumberFormatException e) {
        System.out.println("N�o � n�mero inteiro; entre novamente!");
      }
    }
  }
/*-----------------------------------------------------------------------*/
/* L� um real de 32 bits; rejeita entrada inv�lida e pede novamente.     */
/*-----------------------------------------------------------------------*/
  public final static float readFloat(String prompt){
    while (true) {
      printPrompt(prompt);
      try {return Float.parseFloat(readLine().trim());} 
      catch(NumberFormatException e) {
        System.out.println("N�o � n�mero real; tente novamente!");
      }
    }
  }
/*-----------------------------------------------------------------------*/
/* L� um real de 64 bits; rejeita entrada inv�lida e pede novamente.     */
/*-----------------------------------------------------------------------*/
  public final static double readDouble(String prompt){
    while (true) {
      printPrompt(prompt);
      try {return Double.parseDouble(readLine().trim());} 
      catch(NumberFormatException e) {
        System.out.println("N�o � n�mero real; tente novamente!");
      }
    }
  }

}