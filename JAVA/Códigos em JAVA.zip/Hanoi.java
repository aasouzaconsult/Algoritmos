/*-----------------------------------------------------------------------*/
/* Torre de Han�i: lista os movimentos necess�rios para completar o jogo.*/
/* O objetivo � transferir todos os discos empilhados em uma haste       */
/* para uma outra haste, inicialmente vazia, usando uma terceira haste   */
/* para armazenamento tempor�rio. Os discos est�o ordenados por tamanho  */
/* com o maior disco em baixo. Pode-se mover apenas um disco por vez e,  */
/* em nenhum momento, um disco maior pode pousar sobre um disco maior.   */
/* Como o algoritmo � exponencial, o n�mero de discos n�o deve ser grande*/
/* Solu��o iterativa (n�o recursiva).                                    */
/* Francisco A. S. Grossi                                                */
/*-----------------------------------------------------------------------*/
public class Hanoi {
/*-----------------------------------------------------------------------*/
/* 1)Transfere n-1 discos da haste 'a' para a haste 'c' ('b' auxiliar)   */
/* 2)Move o �ltimo disco da haste  'a' para a haste 'b'                  */
/* 3)Transfere n-1 discos da haste 'c' para a haste 'b' ('a' auxiliar)   */
/* Par�metros: 1) N�mero de discos que devem ser transferidos            */
/*             2) Haste onde est�o os discos                             */
/*             3) Haste para onde v�o os discos                          */
/*             4) Haste auxiliar                                         */
/*-----------------------------------------------------------------------*/
  public static void transfere(int n, char a, char b, char c) {
    if (n > 0) {
       transfere(n-1,a,c,b);
       System.out.println("Move disco " + n + " da haste " + a +
		            " para haste " + b);
       transfere(n-1,c,b,a);
    }
  }
/*-----------------------------------------------------------------------*/
/* Programa principal: Move n discos de A para B, usando C como auxiliar.*/
/* Identificam-se as hastes pelas letras A,B,C.                          */
/*-----------------------------------------------------------------------*/
  public static void main(String argumentos[]) {
    int numero;

    do {
      numero = Teclado.readInt("Entre o n�mero de discos:");
    } while (numero < 0 || numero > 16);
    
    transfere(numero,'A','B','C');  
  }
}
