/*-----------------------------------------------------------------------*/
/* Constr�i um vetor booleano cujos elementos contidos em �ndices primos */
/* cont�m TRUE. Este algoritmo chama-se como Crivo de Eratosthenes por   */
/* ter sido idealizado pelo astr�nomo grego Eratosthenes (276-195 A.C).  */
/* Par�metros: vetor e seu �ndice superior                               */
/* Francisco A. S. Grossi                                                */
/*-----------------------------------------------------------------------*/
public class Crivo {
  
  public static boolean[] crivo(int lim) {
    int raiz = (int) Math.sqrt(lim);   
    boolean[] primos = new boolean[lim+1];

    for (int i = 2; i <= lim; i++) 
      primos[i] = true;                    // Assume todos primos
 
    for (int i = 2; i <= raiz; i++)        // Ap�s raiz, fatores repetem
      if (primos[i])                       // Se for primo ent�o marca
        for (int j = i; j <= lim / i; j++) // todos os seus m�ltiplos
          primos[i*j] = false;             // como n�o primos
    
    return primos;
  }
/*-----------------------------------------------------------------------*/
/* Exemplo de invoca��o do Crivo para determinar se n�meros s�o primos.  */
/*-----------------------------------------------------------------------*/
  public static void main(String[] s) {
    final int limite = 1000;
    boolean[] primos = crivo(limite);
    int n = Teclado.readInt("Entre um n�mero inteiro (<2 termina):");

    while (n > 1) {
      if (primos[n]) System.out.println(n + " � primo");
      else System.out.println(n + " � composto");
      n = Teclado.readInt("Entre um n�mero inteiro (<2 termina):");
    }

  }

}