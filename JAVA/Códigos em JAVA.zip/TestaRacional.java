/**----------------------------------------------------------------------*/
/** Programa de teste para a classe de racionais.                        */
/** Usa classe CONSOLE (inclu�da nesta p�gina) para leitura direta.      */
/** Como descende de Object, pode usar o m�todo equals()                 */
/** Como o m�todo toString foi substitu�do, um racional pode ser usado   */
/** diretamente no PRINTLN, pois ele � convertido por este m�todo.       */
/** Francisco A. S. Grossi                                               */
/**----------------------------------------------------------------------*/
import Racional;
public class TestaRacional {

  public static void main(String argumentos[]) {
    Racional a = new Racional();
    Racional b = new Racional();
    Racional c = new Racional(); 

    a.setRacional(Teclado.readInt("Entre o numerador do primeiro  : "),
                  Teclado.readInt("Entre o denominador do primeiro: ")
                 );
    b.setRacional(Teclado.readInt("Entre o numerador do segundo   : "),
                  Teclado.readInt("Entre o denominador do segundo : ")
                 );

    if (a.equals(b))
      System.out.println("\nOs dois s�o iguais");
    else System.out.println("\nOs dois s�o diferentes");

    c = a.soma(b);
    System.out.println("Adi��o       = " + c);
    c.inverte();
    System.out.println("Inverso soma = " + c);
    c = a.subtrai(b);
    System.out.println("Subtra��o    = " + c);
    c = a.multiplica(b);
    System.out.println("Produto      = " + c);
    c = a.divide(b);
    System.out.println("Quociente    = " + c);
  }

}