/**----------------------------------------------------------------------*/
/** Desloca um ret�ngulo com o passeio do mouse.                         */
/** Se houver intersec��o com outro ret�ngulo (no centro da �rea),       */
/** muda a cor da intersec��o para a combina��o das duas cores.          */
/** Francisco A. S. Grossi                                               */
/**----------------------------------------------------------------------*/

// Para executar este applet, use: appletviewer Mouse3.java
// <applet code=Mouse3.class width=400 height=400>
// </applet>

import java.awt.*;
import java.applet.*;
import java.awt.event.*;

public class Mouse3 extends Applet 
       implements MouseListener, MouseMotionListener {
  Image trabalho;
  Graphics fora;
  Rectangle r1, r2, r3;
  Color rb = new Color(255,0,255);
  int largura, altura;
  boolean dentro = false;

  public void init() {
    trabalho = createImage(getSize().width,getSize().height);
    fora = trabalho.getGraphics();

    largura = getSize().width;
    altura = getSize().height;

    int lr1 = largura/5; int ar1 = altura/5; 
    r1 = new Rectangle((largura-lr1)/2,(altura-ar1)/2,lr1,ar1);
    int lr2 = largura/10; int ar2 = altura/10; 
    r2 = new Rectangle((largura-lr2)/2,(altura-ar2)/2,lr2,ar2);

    addMouseListener(this);
    addMouseMotionListener(this);
  }

  public void update(Graphics g)  {
    fora.setColor(getBackground());
    fora.fillRect(0,0,largura,altura);
    fora.setColor(getForeground());
    paint(g);
  }

  public void paint(Graphics g) {
    fora.setColor(Color.red);
    fora.fillRect(r1.x,r1.y,r1.width,r1.height);

    if (dentro) {
      fora.setColor(Color.blue);
      fora.fillRect(r2.x,r2.y,r2.width,r2.height);
      if (r1.intersects(r2)) {
        fora.setColor(rb);
        r3 = r1.intersection(r2);
        fora.fillRect(r3.x,r3.y,r3.width,r3.height);
      }  
    }
    
    g.drawImage(trabalho,0,0,this);
    showStatus("Passeie com o mouse (sem clicar).");
  }

  public void destroy() {
    fora.dispose();
  }

  public void mouseMoved(MouseEvent e) {
    r2.setLocation(e.getX()-r2.width/2,e.getY()-r2.height/2);
    repaint();
  }

  public void mouseEntered(MouseEvent e) {
    dentro = true;
  }
  
  public void mouseExited(MouseEvent e) {
    dentro = false;
  }

  public void mousePressed(MouseEvent e) {}
  public void mouseReleased(MouseEvent e) {}
  public void mouseClicked(MouseEvent e) {}
  public void mouseDragged(MouseEvent e) {}

}
