package ljk.copa2002.bd;
import java.sql.*;

public class BD {
  Connection con;
  PreparedStatement sttTodos, sttJogo, sttPais, sttInclua;
  String url;
    ResultSet rs;
  
  public BD() {
   con = null;
   url = "jdbc:mysql://localhost/xxe";
     rs = null;
  }  
  
  public void crieConexao() throws Exception {
      if (con == null) {
        Class.forName("org.gjt.mm.mysql.Driver");
        con = DriverManager.getConnection(url);
        sttTodos = con.prepareStatement("select * from copa2002 order by jogo");
        sttJogo = con.prepareStatement("select * from copa2002 where jogo = ?");
        sttPais = con.prepareStatement("select * from copa2002 where pais1 = ? or pais2 = ? order by jogo");
        sttInclua = con.prepareStatement("insert into copa2002 values (?, ?, ?, ?, ?, ?)");
      }
  }
  
  public boolean procureTodos() throws Exception {
        return processeStatement(sttTodos);
  }
  
  public boolean procureJogo(int jogo) throws Exception {
    sttJogo.setInt(1,jogo);
    return processeStatement(sttJogo);
  }
  
  public boolean procurePais(String pais) throws Exception {
    sttPais.setString(1,pais);
    sttPais.setString(2,pais);
    return processeStatement(sttPais);
  }
  
  public boolean incluaJogo(int jogo, Date data, String pais1, String pais2, 
                            int gols1,int gols2) throws Exception {
    sttInclua.setInt(1,jogo);
    sttInclua.setDate(2,data);
    sttInclua.setString(3,pais1);
    sttInclua.setString(4,pais2);
    sttInclua.setInt(5,gols1);
    sttInclua.setInt(6,gols2);
    return processeStatement(sttInclua);
  }
  
    
    protected boolean processeStatement(PreparedStatement s) throws Exception  {
        boolean resultado;
        try {
          rs = null;
          resultado = s.execute();
          if (resultado)
             rs = s.getResultSet();
          return(resultado);
        }
        catch (Exception e) {
          con = null;
          throw e;
        }
    }
    
    public ResultSet getResultSet()  {
        return(rs);
    }
} 