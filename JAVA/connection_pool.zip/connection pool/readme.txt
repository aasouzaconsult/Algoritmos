
     	O presente pacote ilustra um pouco da teoria de constru��o de Pool de Conex�es.

	Trata-se na verdade da implementa��o mais simples que pode funcionar a contento (sem surpresas desagrad�veis na obten��o e libera��o das conex�es! :-) ).

	O tema pool de conex�es pode ser extendido muito al�m do presente exemplo, como a implementa��o de filas (queue) de libera��o, otimiza��o do n�mero de conex�es no pool conforme sua utiliza��o, cria��o din�mica de conex�es por estimativa (o sistema faria uma estat�stica de utiliza��o por hora do dia, "aprendendo" sobre as necessidades do sistema e deixa no pool o melhor n�mero de conex�es para atender � demanda naquela determinada hora e dia da semana...).

	Implementa��es como estas n�o precisam necess�riamente ser criadas pelos "g�nios" do Apache Jakarta. N�s, brasileiros, temos muito a contribuir!!!

	O pacote fornecido � formado dos seguintes fontes:

    * ConnectionFactory: Uma "f�brica" que produz conex�es baseadas em um arquivo de configura��o .properties. Ela n�o � um singleton, o que significa q vc. pode criar mais de um objeto f�brica
 em seu projeto, cada um com um arquivo de configura��o diferente.

    * PooledConnectionFactory: Uma f�brica que deriva de ConnectionFactory e implementa o conceito de pool de conex�es. Quando se pede uma conex�o a ela, ela a retira do pool. Quando se fecha uma de suas conex�es (m�todo close), ela � devolvida ao pool. Na verdade, as conex�es fornecidas s�o implementadas por uma classe interna encapsulada chamada PooledConnection, oculta do cliente. Ao cliente q chama a conex�o, parecer� q ele est� lidando com uma conex�o comum (implementa a interface java.sql.Connection).

    * TestaPooledConectionFactory � um simples teste da f�brica de conex�es em pool.



ATEN��O:
    Todos os c�digos est�o sendo oferecidos sob licen�a GPL, com a inten��o �nica de estimular o aprendizado. N�o podem ser usados com fins comerciais sem autoriza��o pr�via do autor. Se redistribu�dos para outros sites que n�o o www.portaljava.com, o autor e a fonte devem ser sempre citados.

===================================================================

    Copernico
                Cl�udio Marcelo Silva

                Instrutor do Centro de Treinamento AOPEC.
		
 		www.aopec.com.br

                claudio.marcelo@aopec.com.br
                
