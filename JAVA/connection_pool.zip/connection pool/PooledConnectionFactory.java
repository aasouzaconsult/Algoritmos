/*
 *  PooledConnectionFactory.java - Short Description
 *  Copyright (C) 15 de Fevereiro de 2003 author
 *  email
 *  webaddress
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
import java.sql.*;
import java.util.*;
import java.io.*;
/**
 *  Implementa��o de uma f�brica de conex�es que suporta o esquema de pool de
 *  conex�es.
 *
 *@author     Cl�udio Marcelo Silva - AOPEC
 *@created    4 de Fevereiro de 2003
 */
public class PooledConnectionFactory extends ConnectionFactory {
	//Array de conex�es.
	private Connection[] connections;
	//quantidade de conex�es dispon�veis em um dado momento.
	private int disponible = 0;
	//Controla se a f�brica est� fechada.
	private boolean closed = true;


	/**
	 *  Construtor da f�brica de conex�es.
	 *
	 *@param  config         java.util.File: arquivo de configura��o.
	 *@exception  Exception  Caso n�o seja poss�vel criar as conex�es.
	 */
	public PooledConnectionFactory(File config) throws Exception {
		super(config);
		connections = new Connection[
				Integer.parseInt(
				conProp.getProperty("pool.size").toString()
				)
				];
		//Carrega da classe do driver na mem�ria, executando seu construtor.
		Class.forName(conProp.getProperty("driver")).newInstance();
		for (int i = 0; i < connections.length; i++) {
			Connection c = DriverManager.getConnection(
					conProp.getProperty("url"),
					conProp.getProperty("user"),
					conProp.getProperty("password")
					);
			connections[i] = new PooledConnection(c, this);
		}
		this.disponible = connections.length;
		this.closed = false;
	}


	/**
	 *  Encerra a f�brica, fechando todo o array de conex�es.
	 *
	 *@exception  SQLException  Caso n�o seja poss�vel fechar conex�es.
	 */
	public synchronized void closePool() throws SQLException {

		for (int i = 0; i < connections.length; i++) {
			PooledConnection pc = (PooledConnection) connections[i];
			pc.realClose();
		}
		this.closed = true;
		this.disponible = 0;
	}


	/**
	 *  retorna se a f�brica est� fechada.
	 *
	 *@return    true, se a f�brica est� fechada.
	 */
	public boolean isClosed() {
		return this.closed;
	}


	/**
	 *  Obt�m uma conex�o do pool.
	 *
	 *@return                   uma conex�o java.sql.Connection
	 *@exception  SQLException
	 */
	public synchronized Connection getConnection() throws SQLException {
		/*
		 *  Ordena as conex�es de forma que conex�es livres fiquem por �ltimo
		 */
		Arrays.sort(this.connections);
		if (this.disponible < 1) {
			throw new SQLException(
					"N�o h� conex�es dispon�veis. Tente mais tarde."
					);
		}
		System.out.println("Conex�o solicitada!");
		System.out.println("Existem agora " + this.disponible + " conex�es disponiveis.");
		//Reduz o �ndice de conex�es livres.
		this.disponible--;
		PooledConnection pc = (PooledConnection) this.connections[this.connections.length - 1];
		//Torna a conex�o ocupada.
		pc.setBusy(true);
		//"Reabre" conex�o "fechada"
		pc.reopen();
		Connection c = pc;
		return c;
	}


	/**
	 *  M�todo Executado por uma PooledConnection quando essa conex�o � liberada.
	 *  Aumentando as conex�es dispon�veis no pool
	 */
	void releaseConnection() {
		this.disponible++;
	}


	/**
	 *  Classe de implementa��o de uma PooledConnection. Possui uma conex�o
	 *  java.sql.Connection como atributo e transfere para a mesma a maioria das
	 *  chamadas da interface java.sql.Connection, q tamb�m implementa.
	 *
	 *@author     Administrador
	 *@created    4 de Fevereiro de 2003
	 */
	private static class PooledConnection implements Connection, Comparable {
		//A verdadeira conex�o, gerenciada por PooledConnection.
		private Connection connection;
		//Referencia para a f�brica que criou esse objeto.
		private PooledConnectionFactory factory;
		//Cole��o q permite manter o controle das conex�es criadas
		private Vector statements = new Vector();
		// boolean: conex�o ocupada?
		private boolean busy = false;
		// boolean: conex�o liberada pelo cliente?
		private boolean closed = true;


		/**
		 *  Construtor para PooledConnection Recebe uma conex�o estabelecida e uma
		 *  refer�ncia para a f�brica que a criou.
		 *
		 *@param  c  java.sql.Connection
		 *@param  f  PooledConnectionFactory
		 */
		public PooledConnection(Connection c, PooledConnectionFactory f) {
			this.factory = f;
			this.connection = c;
			this.closed = false;
		}


		/**
		 *  Invocado pela f�brica
		 */
		void reopen() {
			this.closed = false;
		}


		/**
		 *  Invocado pela f�brica
		 *
		 *@param  b  The new busy value
		 */
		void setBusy(boolean b) {
			this.busy = b;
		}


		/**
		 *  Testa se a conex�o est� ocupada
		 *
		 *@return    boolean
		 */
		public boolean isBusy() {
			return this.busy;
		}


//========================Implementa��o dos m�todos de java.sql.Connection==========================

		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@exception  SQLException
		 */
		public void clearWarnings() throws SQLException {
			connection.clearWarnings();
		}


		/**
		 *  Ao inv�s de fechar a conex�o agregada, este m�todo apenas libera a conex�o
		 *  de volta ao pool. O m�todo de fechamento verdadeiro da conex�o foi movido
		 *  para realClose(), e s� pode ser acessado pela f�brica.
		 *
		 *@exception  SQLException  se alguma opera��o de banco falha.
		 */
		public void close() throws SQLException {
			//rollback nas transa��es pendentes para "limpar" a conex�o.
			connection.rollback();
			//Fechando todos os estamentos abertos nesta conex�o.
			for (Enumeration en = statements.elements(); en.hasMoreElements(); ) {
				Statement st = (Statement) en.nextElement();
				st.close();
			}
			//D� ao objeto atual a condi��o de "fechado".
			this.closed = true;
			/*
			 *  Avisa a factory de que uma conex�o foi liberada logo
			 *  ap�s liberar a conex�o
			 */
			this.setBusy(false);
			this.factory.releaseConnection();
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@exception  SQLException
		 */
		public void commit() throws SQLException {
			connection.commit();
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@return                   Description of the Return Value
		 *@exception  SQLException
		 */
		public Statement createStatement() throws SQLException {
			Statement st = connection.createStatement();
			//registra o estamento antes de retorn�-lo
			statements.addElement(st);
			return st;
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  resultSetType         Description of the Parameter
		 *@param  resultSetConcurrency  Description of the Parameter
		 *@return                       Description of the Return Value
		 *@exception  SQLException
		 */
		public Statement createStatement(
				int resultSetType,
				int resultSetConcurrency) throws SQLException {
			Statement st = connection.createStatement(resultSetType, resultSetConcurrency);
			//registra o estamento antes de retorn�-lo
			statements.addElement(st);
			return st;
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  resultSetType         Description of the Parameter
		 *@param  resultSetConcurrency  Description of the Parameter
		 *@param  resultSetHoldability  Description of the Parameter
		 *@return                       Description of the Return Value
		 *@exception  SQLException
		 */
		public Statement createStatement(
				int resultSetType,
				int resultSetConcurrency,
				int resultSetHoldability) throws SQLException {
			Statement st = connection.createStatement(
					resultSetType,
					resultSetConcurrency,
					resultSetHoldability);
			//registra o estamento antes de retorn�-lo
			statements.addElement(st);
			return st;
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@return                   The autoCommit value
		 *@exception  SQLException
		 */
		public boolean getAutoCommit() throws SQLException {
			return connection.getAutoCommit();
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@return                   The catalog value
		 *@exception  SQLException
		 */
		public String getCatalog() throws SQLException {
			return connection.getCatalog();
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@return                   The holdability value
		 *@exception  SQLException
		 */
		public int getHoldability() throws SQLException {
			return connection.getHoldability();
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@return                   The metaData value
		 *@exception  SQLException
		 */
		public DatabaseMetaData getMetaData() throws SQLException {
			return connection.getMetaData();
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@return                   The transactionIsolation value
		 *@exception  SQLException
		 */
		public int getTransactionIsolation() throws SQLException {
			return connection.getTransactionIsolation();
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@return                   The typeMap value
		 *@exception  SQLException  Description of the Exception
		 */
		public Map getTypeMap() throws SQLException {
			return connection.getTypeMap();
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@return                   The warnings value
		 *@exception  SQLException
		 */
		public SQLWarning getWarnings() throws SQLException {
			return connection.getWarnings();
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@return                   The closed value
		 *@exception  SQLException
		 */
		public boolean isClosed() throws SQLException {
			return this.closed;
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@return                   The readOnly value
		 *@exception  SQLException
		 */
		public boolean isReadOnly() throws SQLException {
			return connection.isReadOnly();
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  sql               Description of the Parameter
		 *@return                   Description of the Return Value
		 *@exception  SQLException
		 */
		public String nativeSQL(String sql) throws SQLException {
			return nativeSQL(sql);
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  sql               Description of the Parameter
		 *@return                   Description of the Return Value
		 *@exception  SQLException
		 */
		public CallableStatement prepareCall(String sql) throws SQLException {
			CallableStatement cs = connection.prepareCall(sql);
			statements.addElement(cs);
			return cs;
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  sql                   Description of the Parameter
		 *@param  resultSetType         Description of the Parameter
		 *@param  resultSetConcurrency  Description of the Parameter
		 *@return                       Description of the Return Value
		 *@exception  SQLException
		 */
		public CallableStatement prepareCall(String sql,
				int resultSetType,
				int resultSetConcurrency) throws SQLException {
			CallableStatement cs = connection.prepareCall(
					sql,
					resultSetType,
					resultSetConcurrency
					);
			statements.addElement(cs);
			return cs;
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  sql                   Description of the Parameter
		 *@param  resultSetType         Description of the Parameter
		 *@param  resultSetConcurrency  Description of the Parameter
		 *@param  resultSetHoldability  Description of the Parameter
		 *@return                       Description of the Return Value
		 *@exception  SQLException
		 */
		public CallableStatement prepareCall(String sql,
				int resultSetType,
				int resultSetConcurrency,
				int resultSetHoldability) throws SQLException {
			CallableStatement cs = connection.prepareCall(
					sql,
					resultSetType,
					resultSetConcurrency,
					resultSetHoldability
					);
			statements.addElement(cs);
			return cs;
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  sql               Description of the Parameter
		 *@return                   Description of the Return Value
		 *@exception  SQLException
		 */
		public PreparedStatement prepareStatement(String sql) throws SQLException {
			PreparedStatement ps = connection.prepareStatement(sql);
			statements.addElement(ps);
			return ps;
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  sql                Description of the Parameter
		 *@param  autoGeneratedKeys  Description of the Parameter
		 *@return                    Description of the Return Value
		 *@exception  SQLException
		 */
		public PreparedStatement prepareStatement(
				String sql,
				int autoGeneratedKeys) throws SQLException {
			PreparedStatement ps = connection.prepareStatement(
					sql,
					autoGeneratedKeys
					);
			statements.addElement(ps);
			return ps;
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  sql               Description of the Parameter
		 *@param  columnIndexes     Description of the Parameter
		 *@return                   Description of the Return Value
		 *@exception  SQLException
		 */
		public PreparedStatement prepareStatement(
				String sql,
				int[] columnIndexes) throws SQLException {
			PreparedStatement ps = connection.prepareStatement(
					sql,
					columnIndexes
					);
			statements.addElement(ps);
			return ps;
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  sql                   Description of the Parameter
		 *@param  resultSetType         Description of the Parameter
		 *@param  resultSetConcurrency  Description of the Parameter
		 *@return                       Description of the Return Value
		 *@exception  SQLException
		 */
		public PreparedStatement prepareStatement(
				String sql,
				int resultSetType,
				int resultSetConcurrency) throws SQLException {
			PreparedStatement ps = connection.prepareStatement(
					sql,
					resultSetType,
					resultSetConcurrency
					);
			statements.addElement(ps);
			return ps;
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  sql                   Description of the Parameter
		 *@param  resultSetType         Description of the Parameter
		 *@param  resultSetConcurrency  Description of the Parameter
		 *@param  resultSetHoldability  Description of the Parameter
		 *@return                       Description of the Return Value
		 *@exception  SQLException
		 */
		public PreparedStatement prepareStatement(
				String sql,
				int resultSetType,
				int resultSetConcurrency,
				int resultSetHoldability) throws SQLException {
			PreparedStatement ps = connection.prepareStatement(
					sql,
					resultSetType,
					resultSetConcurrency,
					resultSetHoldability
					);
			statements.addElement(ps);
			return ps;
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  sql               Description of the Parameter
		 *@param  columnNames       Description of the Parameter
		 *@return                   Description of the Return Value
		 *@exception  SQLException
		 */
		public PreparedStatement prepareStatement(
				String sql,
				String[] columnNames) throws SQLException {
			PreparedStatement ps = connection.prepareStatement(
					sql,
					columnNames
					);
			statements.addElement(ps);
			return ps;
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  savepoint         Description of the Parameter
		 *@exception  SQLException
		 */
		public void releaseSavepoint(Savepoint savepoint) throws SQLException {
			connection.releaseSavepoint(savepoint);
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@exception  SQLException
		 */
		public void rollback() throws SQLException {
			connection.rollback();
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  savepoint         Description of the Parameter
		 *@exception  SQLException
		 */
		public void rollback(Savepoint savepoint) throws SQLException {
			connection.rollback(savepoint);
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  autoCommit        The new autoCommit value
		 *@exception  SQLException
		 */
		public void setAutoCommit(boolean autoCommit) throws SQLException {
			connection.setAutoCommit(autoCommit);
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  catalog           The new catalog value
		 *@exception  SQLException
		 */
		public void setCatalog(String catalog) throws SQLException {
			connection.setCatalog(catalog);
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  holdability       The new holdability value
		 *@exception  SQLException
		 */
		public void setHoldability(int holdability) throws SQLException {
			connection.setHoldability(holdability);
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  readOnly          The new readOnly value
		 *@exception  SQLException
		 */
		public void setReadOnly(boolean readOnly) throws SQLException {
			connection.setReadOnly(readOnly);
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@return                   Description of the Return Value
		 *@exception  SQLException
		 */
		public Savepoint setSavepoint() throws SQLException {
			return connection.setSavepoint();
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  name              The new savepoint value
		 *@return                   Description of the Return Value
		 *@exception  SQLException
		 */
		public Savepoint setSavepoint(String name) throws SQLException {
			return connection.setSavepoint(name);
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  level             The new transactionIsolation value
		 *@exception  SQLException
		 */
		public void setTransactionIsolation(int level) throws SQLException {
			connection.setTransactionIsolation(level);
		}


		/**
		 *  M�todo descrito na documenta��o de java.sql.Connection
		 *
		 *@param  map               The new typeMap value
		 *@exception  SQLException
		 */
		public void setTypeMap(Map map) throws SQLException {
			connection.setTypeMap(map);
		}


//==================================================================================================

		/**
		 *  O m�todo real close fecha realmente a conex��o agregada. � chamado pela
		 *  f�brica na ocsi�o de seu encerramento.
		 *
		 *@exception  SQLException
		 */
		void realClose() throws SQLException {
			connection.close();
		}


		/**
		 *  M�todo que permite a opera��o de ordena��o na qual as conex�es livres
		 *  ficam por �ltimo.
		 *
		 *@param  o                       outra PooledConnection
		 *@return                         -1 se &lt, 0, se == e 1, se &gt
		 *@exception  ClassCastException  Description of the Exception
		 */
		public int compareTo(Object o) throws ClassCastException {
			if (!(o instanceof PooledConnectionFactory.PooledConnection)) {
				throw new ClassCastException(
						"Tipo inadequado no pool de conex�es");
			}
			PooledConnectionFactory.PooledConnection pc = (PooledConnectionFactory.PooledConnection) o;
			if (this.isBusy() == pc.isBusy()) {
				return 0;
			}
			if (this.isBusy()) {
				return -1;
			} else {
				return 1;
			}
		}
	}
}

