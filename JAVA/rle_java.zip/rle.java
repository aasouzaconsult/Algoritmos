//Algoritmo exemplificando a utiliza��o do m�todo RLE para compacta��o.
//Possui o m�todo para compactar e descompactar.

//M�todo criado em 05/06/2003 por Douglas Rabuske Herzog
//pela Universidade de Santa Cruz do Sul - UNISC
//para a cadeira de Estrutura de Dados II
//do professor Abraham Rabelo

import javax.swing.*;

public class rle {

    public static void main( String[] args ) {

    	String stringIni, stringCod, stringDecod;
    	boolean valida;
    	int i, tam;
    	char c;

    	//Leitura e valida��o da string a codificar
		do {
    		valida = true;
        
        	stringIni = JOptionPane.showInputDialog("Entre com os algarismos:");
        
        	//Valida��o da string: s� pode conter algarismos
        	tam = stringIni.length();
     
     		if ( tam == 0 )
     			valida = false;
     		else {
           		valida = true;
           	
           		i = 0;
                    	
        		while ( i < tam ) {       
        			c = stringIni.charAt( i );                              
       				i++;
				}            
       		}
		} while( !valida );
 	  	  	  	
   		//Codifica a string inicial   	
   		stringCod = codifica ( stringIni );   	
   	    	
   		JOptionPane.showMessageDialog( null, "A string " + stringIni + " codificada: " + stringCod );

   		//Decodifica a string codificada
   		stringDecod = decodifica ( stringCod );
   	   	
   		JOptionPane.showMessageDialog( null, "A string " + stringCod + " decodificada: " + stringDecod );
   	}

	static String codifica( String s ) {
   		String cod = "";
   		int i, j, k, tam, cont;
		char c, cn;

    	tam = s.length();

    	//n�o faz sentido codificar strings com menos de 3 caracteres
   		if ( tam <= 3 )
    		return s;

    	i = 0;
   		c = cn = s.charAt( i );
   	
   		while ( i < tam ) {
    		cont = 1;
        	i++;

    		//conta n�mero de caracteres seguidos iguais
     		while ( i < tam && ( cn = s.charAt( i ) ) == c ) {
        		cont++;
            	i++;
        	}

     		//se mais de 3 caracteres seguidos comprime
     		if ( cont > 3 )
        		cod += "#" + c + cont;
    		//sen�o mant�m caracteres originais
     		else
        		for ( k = 1; k <= cont; k++ )
            		cod += c;
        
        	c = cn;
   		}

   		return cod;
	}

	static String decodifica( String s ) {
   		String decod = "";
   		String aux = "";
   		int i, j, k, tam;
   			
    	//Pega o tamanho da String que ser� decodificada
    	tam = s.length() - 1;
       	   		   	   	
   		//Ira percorrer cada elemento da String decodificando quando necess�rio
   		for ( i = 0; i <= tam; i++ ) {   		   		
   			//Se o caracter encontrado for diferente de "#" apenas concatena o caracter
   			if ( ( s.charAt( i ) ) != ( ( "#".charAt( 0 ) ) ) )
   				decod += s.charAt( i );
			//Se o caracter for "#" significa que um trecho a ser decodificado
			else {			
				//Utiliza uma String Auxiliar por causa de um bug na convers�o de char para integer
				aux = String.valueOf( s.charAt( i+2 ) );												
				
				//Colhe da String o n�mero de vezes que determinado caracter deve ser repetido (decodificando)
				k = Integer.parseInt( aux );			
			
				//Faz o la�o concatenando o caracter (decodificando)
				for ( j = 1; j <= k; j++ )
					decod += s.charAt( i + 1 );				
			
				//Pula dois elementos pois eles n�o precisam ser analisados (bloco compactado)
				i = i + 2;
			}				
   		}
   		   		     
   		return decod;
	}
}