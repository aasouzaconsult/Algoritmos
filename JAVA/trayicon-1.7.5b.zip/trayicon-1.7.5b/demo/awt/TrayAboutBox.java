/***
 * Windows Tray Icon
 * -----------------
 *
 * Written by Jan Struyf
 *
 *  jan.struyf@cs.kuleuven.ac.be
 *  http://jeans.studentenweb.org/java/trayicon/trayicon.html
 *
 * Please mail me if you
 *	- 've found bugs
 *	- like this program
 *	- don't like a particular feature
 *	- would like something to be modified
 *
 * I always give it my best shot to make a program useful and solid, but
 * remeber that there is absolutely no warranty for using this program as
 * stated in the following terms:
 *
 * THERE IS NO WARRANTY FOR THIS PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE
 * LAW. THE COPYRIGHT HOLDER AND/OR OTHER PARTIES WHO MAY HAVE MODIFIED THE
 * PROGRAM, PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
 * TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
 * PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
 * REPAIR OR CORRECTION.
 *
 * IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW WILL ANY COPYRIGHT HOLDER,
 * OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE PROGRAM,
 * BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE
 * PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
 * INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE
 * PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR OTHER
 * PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *
 * May the Force be with you... Just compile it & use it!
 */

package demo.awt;

import java.awt.*;
import java.awt.event.*;
import java.io.*;

import com.jeans.trayicon.*;

// Stupid about box for demo app
public class TrayAboutBox extends Dialog {

	// Create new about box given parent frame
	public TrayAboutBox(Frame parent)  {
		// Make modal dialog given parent and title
		super(parent, "About TrayIcon", true);
		// Layout stuff
        setBackground(SystemColor.control);
		setLayout(new GridLayout(0,1));
		add(new Label("TrayIcon version "+WindowsTrayIcon.TRAY_VERSION));
		add(new Label("Written by Jan Struyf <Jan.Struyf@cs.kuleuven.ac.be>"));		
		Panel buttons = new Panel();
		buttons.setLayout(new FlowLayout());
		Button button = new Button("OK");
		button.addActionListener(new CloseListener());		
		buttons.add(button);
        add(buttons, BorderLayout.SOUTH);				
		// Close listeners for OK button and window button
		addWindowListener(new CloseWindowListener());
		pack();
	}

	// Close listener for OK button
	private class CloseListener implements ActionListener {

		public void actionPerformed(ActionEvent evt) {
			dispose();
		}

	}

	// Close listener for windows button
	private class CloseWindowListener extends WindowAdapter {

		public void windowClosing(WindowEvent evt) {
			dispose();
		}

	}
}
