/*** 
 * Windows Tray Icon
 * -----------------
 *
 * Written by Jan Struyf
 *
 *  jeans@ace.ulyssis.org, jan.struyf@cs.kuleuven.ac.be
 *  http://www.surf.to/jeans
 *
 * Please mail me if you
 *	- 've found bugs  
 *	- like this program
 *	- don't like a particular feature
 *	- would like something to be modified   
 *
 * I always give it my best shot to make a program useful and solid, but
 * remeber that there is absolutely no warranty for using this program as
 * stated in the following terms:
 * 
 * THERE IS NO WARRANTY FOR THIS PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE
 * LAW. THE COPYRIGHT HOLDER AND/OR OTHER PARTIES WHO MAY HAVE MODIFIED THE 
 * PROGRAM, PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
 * TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
 * PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
 * REPAIR OR CORRECTION.
 *
 * IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW WILL ANY COPYRIGHT HOLDER, 
 * OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE PROGRAM,
 * BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE 
 * PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
 * INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE
 * PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR OTHER
 * PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * May the Force be with you... Just compile it & use it!
 */
 
package demo.awt;

import java.awt.*;
import java.awt.event.*;
import java.io.*;

import com.jeans.trayicon.*;

// Demo app for Java Tray Icon
public class TrayDialogDemo {

	protected WindowsTrayIcon m_hIcon;
	
	public TrayDialogDemo() throws TrayIconException, InterruptedException {
		// Set callback method to send windows messages through Tray Icon library (see WindowsMessageCallback)
		WindowsTrayIcon.setWindowsMessageCallback(new WindowsMessageCallback());		
		// Load 16x16 icon gif
		Image france = loadImage("Duke16.gif");		
		m_hIcon = new WindowsTrayIcon(france, 16, 16);
		m_hIcon.setPopup(makePopup());
		m_hIcon.setVisible(true);
		WindowsTrayIcon.keepAlive();
	}
	
	// Create the popup menu for each Tray Icon (on right mouse click)
	public TrayIconPopup makePopup() {
		// Make new popup menu
		TrayIconPopup popup = new TrayIconPopup();
		// Add about, configure  & exit item
		TrayIconPopupSimpleItem item = new TrayIconPopupSimpleItem("&About");
		item.addActionListener(new AboutListener());
		popup.addMenuItem(item);
		// Add configure item
		item = new TrayIconPopupSimpleItem("&Configure");
		item.addActionListener(new ConfigureListener());
		popup.addMenuItem(item);
		// Add a separator
		TrayIconPopupSeparator sep = new TrayIconPopupSeparator();
		popup.addMenuItem(sep);
		// Add exit item
		item = new TrayIconPopupSimpleItem("E&xit");
		item.addActionListener(new ExitListener());
		popup.addMenuItem(item);
		return popup;
	}	

	// Load a gif image (used for loading the 16x16 icon gifs)
	public static Image loadImage(String fileName) {
		return Toolkit.getDefaultToolkit().getImage("demo"+File.separator+"images"+File.separator+fileName);
	}

	// Main proc
	public static void main(String[] args) {			
		try {							
			String appName = "DemoTray";
			// First check if there's another instance of our app running by sending a windows message
			// to a hidden icon window "TestTray" - each Tray Icon app has a hidden window that receives
			// the mouse/menu messages for it's Tray Icons
			long result = WindowsTrayIcon.sendWindowsMessage(appName, 1234);
			if (result != -1) {
				// If window exists, there's already an instance of our app running
				// Print message and exit (other app will restore its window when receiving 
				// our message - see WindowsMessageCallback
				System.out.println("Already running other instance of "+appName+" (returns: "+result+")");
				return;
			}
			// Init the Tray Icon library given the name for the hidden window
			WindowsTrayIcon.initTrayIcon(appName);
			// Show our main window
			TrayDialogDemo demo = new TrayDialogDemo();			
		} catch (TrayIconException e) {
			System.out.println("Error: "+e.getMessage());
		} catch (InterruptedException e) {
		}
	}
	
	// Callback listener handles incomming windows messages. In this demo, a windows message is send when the
	// user tries to start a second instance of the demo app. You can try this one by opening two MS-DOS prompts
	// and say in each one "java demo.TestTrayIcon"
	// MS-DOS 1:
	// 	C:\TrayIcon>java demo.TestTrayIcon
	//	...
	//	Other instance started (parameter: 1234)
	//
	// MS-DOS 2:
	// 	C:\TrayIcon>java demo.TestTrayIcon
	// 	Already running other instance of TestTray (returns: 4321)	
	private class WindowsMessageCallback implements TrayIconCallback {
		
		public int callback(int param) {
			// Param contains the integer value send with sendWindowsMessage(appName, param)
			System.out.println("Other instance started (parameter: "+param+")");
			// Return integer value to other process
			return 4321;
		}
		
	}

	// Callback listener handles exit button / exit popup menu
	private class ExitListener implements ActionListener {
		
		public void actionPerformed(ActionEvent evt) {
			// Free all Tray Icon resources - always call this on exit
			WindowsTrayIcon.cleanUp();
			// Exit application
			System.exit(0);
		}

	}

	// Callback listener handles about button
	private class AboutListener implements ActionListener {
		
		public void actionPerformed(ActionEvent evt) {
			System.out.println("About selected.");
			DemoAboutBox box = new DemoAboutBox();			
    		centerDialog(box);			
			box.show();			
		}

	}

	// Callback listener handles about button
	private class ConfigureListener implements ActionListener {
		
		public void actionPerformed(ActionEvent evt) {
			// TestTrayIcon.this instead of this$0 for Java 1.3 compatibility
			ConfigureBox box = new ConfigureBox();			
			box.show();			
		}

	}

	public static void centerDialog(Window frame) {
		Dimension dialogSize = frame.getSize();
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setLocation(screenSize.width/2 - dialogSize.width/2,
		                  screenSize.height/2 - dialogSize.height/2);
	}
}

class ConfigureBox extends Frame {
	
	public ConfigureBox() {
		super("Configure TrayIcon");
		// Layout stuff
		setBackground(SystemColor.control);		
		setLayout(new GridLayout(0,1));
		add(new Label("Hello"));
		addWindowListener(new CloseWindowListener());
		pack();
		setSize(300,200);
		TrayDialogDemo.centerDialog(this);		
	}
		
	// Close listener for windows button
	private class CloseWindowListener extends WindowAdapter {
		
		public void windowClosing(WindowEvent evt) {
			dispose();
		}

	}			
	
}

// Stupid about box for demo app
class DemoAboutBox extends Frame {

	// Create new about box given parent frame
	public DemoAboutBox()  {
		// Make modal dialog given parent and title
		super("About TrayIcon");
		// Layout stuff
		setBackground(SystemColor.control);
		setLayout(new GridLayout(0,1,3,3));
		add(new Label("TrayIcon version "+WindowsTrayIcon.TRAY_VERSION));
		add(new Label("Written by Jan Struyf <Jan.Struyf@cs.kuleuven.ac.be>"));
		Panel buttons = new Panel();
		buttons.setLayout(new FlowLayout());
		Button button = new Button("OK");
		button.addActionListener(new CloseListener());		
		buttons.add(button);
        add(buttons, BorderLayout.SOUTH);				
		// Close listeners for OK button and window button			
		addWindowListener(new CloseWindowListener());
		pack();
	}
	
	// Close listener for OK button
	private class CloseListener implements ActionListener {
		
		public void actionPerformed(ActionEvent evt) {
			dispose();
		}

	}	
	
	// Close listener for windows button
	private class CloseWindowListener extends WindowAdapter {
		
		public void windowClosing(WindowEvent evt) {
			dispose();
		}

	}		
}

