
package demo.swing;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;

import com.jeans.trayicon.*;

public class TR {
    
    public final static int SHOW = 0;
    public final static int ABOUT = 1;
    public final static int OPTIONS = 2;    
    public final static int TEST = 3;    
    public final static int EN_TEST = 4;
    public final static int BL_TEST = 5;
    public final static int CH_TEST = 6;    
    public final static int EXIT = 7;
    public final static int NB_ITEMS = 8;

    public static String[] m_Strings;

    public static String get(int idx) {
        String str = m_Strings[idx];
        StringBuffer buf = new StringBuffer();        
        for (int i = 0; i < str.length(); i++) {
            int ch = str.charAt(i);
            if (ch != '&') buf.append((char)ch);
        }
        return buf.toString();
    }
    
    public static void load(String fname) throws IOException {
        m_Strings = new String[NB_ITEMS];
        LineNumberReader rdr = new LineNumberReader(new InputStreamReader(new FileInputStream(fname), "UTF8"));
        for (int i = 0; i < NB_ITEMS; i++) {
            m_Strings[i] = rdr.readLine();
        }    
        rdr.close();
    }
}
