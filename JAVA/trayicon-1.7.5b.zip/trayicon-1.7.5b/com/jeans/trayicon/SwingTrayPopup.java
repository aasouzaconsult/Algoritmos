
package com.jeans.trayicon;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class SwingTrayPopup extends JPopupMenu {

	WindowsTrayIcon m_Icon;
	MouseListener m_Listener;

	public SwingTrayPopup() {
	}
	
	public void setTrayIcon(WindowsTrayIcon icon) {
		if (icon != null) {
			m_Icon = icon;            
			m_Listener = new ActivateListener();
			m_Icon.addMouseListener(m_Listener);
		} else {
			if (m_Icon != null) {
				m_Icon.removeMouseListener(m_Listener);
				m_Icon = null;
			}
        	}            
    	}
    	
	public void showMenu(int xp, int yp) {
		TrayDummyComponent frame = WindowsTrayIcon.getDummyComponent();

		// This should show the menu at a better location :-)
		//  * Thanks to Danny <danny@isfantastisch.nl> for the 
		//    setAlwaysOnTop and updateUI() hint
        
		WindowsTrayIcon.setMouseClickHook(new ClickListener());
		WindowsTrayIcon.setAlwaysOnTop(frame, true);
		Dimension d = getPreferredSize();
		show(frame, xp-d.width, yp-d.height);
		updateUI();        
	}		

	// Callback listener handles icon events
	private class ClickListener extends MouseAdapter {

	}
	
	// Callback listener handles icon events
	private class ActivateListener extends MouseAdapter {

		public void mousePressed(MouseEvent evt) {
		    if (evt.isPopupTrigger() && (evt.getModifiers() & MouseEvent.BUTTON2_MASK) != 0 && evt.getClickCount() == 1) {
				showMenu(evt.getX(), evt.getY());
			}
		}
	}
}
