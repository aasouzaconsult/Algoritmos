//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HookResources.rc
//
#define IDR_HOOK_MENU                   101
#define IDM_CALLWNDPROC                 0
#define IDM_CBT                         1
#define IDM_DEBUG                       2
#define IDM_GETMESSAGE                  3
#define IDM_KEYBOARD                    4
#define IDM_MOUSE                       5
#define IDM_MSGFILTER                   6

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
