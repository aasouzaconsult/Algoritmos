PostGIS plug in for JUMP 1.1.

For installation instructions see doc/INSTALL.txt.