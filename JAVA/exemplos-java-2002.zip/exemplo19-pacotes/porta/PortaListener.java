/** 
	R�mulo Silva de Oliveira
	Departamento de Automa��o e Sistemas - UFSC
*/

package porta;

public interface PortaListener{
	public void portaAlterou(EventoPortaAberta e);
	}
	 	
