
Windows Tray Icon
-----------------

Written by Jan Struyf

jan.struyf@cs.kuleuven.ac.be
http://jeans.studentenweb.org/java/trayicon/trayicon.html

RUNNING (Last modified 07/16/01)

* Make sure you have Sun's JDK or JRE 1.1.8, 1.2.x or 1.3.x
	* If you have another version and it doesn't work, please mail me
	* If you have Microsoft Visual J++, please be patient for TrayIcon v1.6

* Download TrayIcon-xx.ZIP (You can unzip it using WinZip or whatever)
* Install it in a directory of your choice (C:\TrayIcon)
* Open a MS-Dos command prompt and say:
	* If you have Java/JDK
          	cd C:\TrayIcon
        	javac demo\TestTrayIcon.java
          	java demo.TestTrayIcon

	* If you have JRE 1.1.8
        	cd C:\TrayIcon
		    jre -cp . demo.TestTrayIcon

* Now the demo app should start.
* If something does not work, don't hesitate to mail me (jan.struyf@cs.kuleuven.ac.be).
	* Always include the next 7 things in bug reports:
	    1) The version of TrayIcon you are using
		2) Your OS name/version (Win95/98/NT/2K/..)
		3) Your Java vendor (Sun/Microsoft/..)
		4) Your Java version (1.1.8, 1.2, 1.2.2,..)
			* You can obtain this by running java -version on some systems
		5) Your PATH
			* echo %PATH%
		6) Your CLASSPATH (if not empty)
			* echo %CLASSPATH%
	    7) A detailed description of your problem

	* I'll try to fix it asap :O)

* If you have build an application with TrayIcon (small or big, expensive or free does
  not matter), please let me know the URL.
  	* This is because I'm planning to add some links to existing
  	  apps that use TrayIcon on my site (new 09/02/00).

* If you want to use TrayIcons in several apps then copy TRAYICON.DLL to your
  WINDOWS/SYSTEM directory.
* The demo source is in demo/TestTrayIcon.java
* The TrayIcon main class is jeans/trayicon/WindowsTrayIcon.java
  (you can put this in your classpath if you want to).
* The javadoc information is in jeans/trayicon/WindowsTrayIcon.html
* It's possible to include jeans/trayicon/* in a JAR file with your app

C++ Source code in:

	jeans/trayicon/c++/WindowsTrayIcon.cpp

Java Source code in:

	jeans/trayicon/WindowsTrayIcon.java

Java example file in:

	demo/TestTrayIcon.java

Quick usage:

// Initialisation
	public static void main(String[] args) {
		try {
			if (WindowsTrayIcon.isRunning("TestApp")) {
				// App already running, show error message and exit
			}
			WindowsTrayIcon.initTrayIcon("TestApp");
			...

// Termination
	...
	WindowsTrayIcon.cleanUp();
	System.exit(0);

// Create Tray Icon
	icon = new WindowsTrayIcon(image, 16, 16);
	icon.setToolTipText("SomeTooltip");
	icon.addActionListener(new SomeActionListener());
	icon.setVisible(true);
	...

See demo/TestTrayIcon.java for more info..
Or contact me :O)


Good luck :O)

/**
 * WindowsTrayIcon
 *
 * Written by Jan Struyf
 *
 *  jan.struyf@cs.kuleuven.ac.be
 *  http://jeans.studentenweb.org/java/trayicon/trayicon.html
 *
 * Changelog
 *
 * Version pre1.6c (07/16/01)
 *	* Fixed minor compilation warnings reported by the more strict VC++ 6.0
 *
 * Version pre1.6b (12/16/00)
 *	* Fixed memory leak for 'animating icons'
 *      * ReleaseDC -> DeleteDC
 *
 * Version pre1.6 (09/02/00)
 *	* Support for old JDK/JRE 1.1.x
 *	* TrayIcon 1.6 will support Microsoft Visual J++
 *
 * Version 1.5 (07/03/00)
 *	* Tray icon popup menu support
 *	* Added code for sendWindowsMessage()
 *
 * Version 1.4 (06/29/00)
 *	* Added DllMain function to clean init code
 *	* Removed redundant LoadLibrary/FreeLibrary calls
 *	* Added code for isRunning()
 *
 * Version 1.3 (06/09/00)
 *	* Trail bug fix for NT (no public release)
 *		(Patch from 'Daniel Hope <danielh@inform.co.nz>')
 *
 * Version 1.2 (05/03/00)
 *	* Message handler for first icon fixed
 *	* WM_RBUTTONDOWN message handler fixed
 *	* Classes are now unregistered on exit
 *		(Patch from 'Daniel Rejment <daniel@rejment.com>')
 *
 * Version 1.0 (06/29/99)
 *	* Initial release
 *
 * Please mail me if you
 *	- 've found bugs
 *	- like this program
 *	- don't like a particular feature
 *	- would like something to be modified
 *
 * I always give it my best shot to make a program useful and solid, but
 * remeber that there is absolutely no warranty for using this program as
 * stated in the following terms:
 *
 * THERE IS NO WARRANTY FOR THIS PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE
 * LAW. THE COPYRIGHT HOLDER AND/OR OTHER PARTIES WHO MAY HAVE MODIFIED THE
 * PROGRAM, PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
 * TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
 * PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
 * REPAIR OR CORRECTION.
 *
 * IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW WILL ANY COPYRIGHT HOLDER,
 * OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE PROGRAM,
 * BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE
 * PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED
 * INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE
 * PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR OTHER
 * PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *
 * May the Force be with you... Just compile it & use it!
 */