///////////////////////////////////////////////////////////////////////////
//
// Projeto: CafeBemBrasileiro
// Arquivo: CafeBB_ControladorIHC.java
// Descricao: Esta classe implementa a interface ControladorIHC para 
//            o hardware da cafeteira CafeBemBrasileiro.
//
///////////////////////////////////////////////////////////////////////////

public class CafeBB_ControladorIHC implements ControladorIHC
{
  private Hardware cafeteiraCafeBB;

  public CafeBB_ControladorIHC(Hardware oHardware)
  {
    cafeteiraCafeBB= oHardware;
  }

  public void indicaFim()
  {
    cafeteiraCafeBB.atuLuzIndicadora(Estado.indicadoraLigada);
  }

  public void indicaPronto()
  {
    cafeteiraCafeBB.atuLuzIndicadora(Estado.indicadoraDesligada);
  }

  public boolean checaInicio()
  {
    return cafeteiraCafeBB.leEstadoInterruptor().equals(
					     Estado.interruptorPressionado);
  }
}
