///////////////////////////////////////////////////////////////////////////
//
// Projeto: CafeBemBrasileiro
// Arquivo: ClienteVaporizador.java
// Descricao: Interface para um cliente generico do vaporizador de uma 
//            cafeteira. Um vaporizador so pode informar aos seus 
//            clientes que o cafe ja esta pronto.
//
///////////////////////////////////////////////////////////////////////////

public interface ClienteVaporizador
{
    public void cafeFeito();
}
