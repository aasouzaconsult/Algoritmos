///////////////////////////////////////////////////////////////////////////
//
// Projeto: CafeBemBrasileiro
// Arquivo: ControladorVaporizador.java
// Descricao: Interface para o dispositivo que vaporiza agua e a joga
//            sobre o po' de cafe em uma cafeteira. Um vaporizador pode
//            ser instruido a fazer duas coisas: jogar agua ou nao
//            jogar agua. Um vaporizador tambem pode informar se 
//            existe agua para ser vaporizada. 
//
///////////////////////////////////////////////////////////////////////////

public interface ControladorVaporizador 
{
    public void jogaAgua();
    public void naoJogaAgua();
    public boolean temAgua();
}
