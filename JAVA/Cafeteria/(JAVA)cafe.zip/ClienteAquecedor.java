///////////////////////////////////////////////////////////////////////////
//
// Projeto: CafeBemBrasileiro
// Arquivo: ClienteAquecedor.java
// Descricao: Interface para todos os clientes do aquecedor de uma 
//            cafeteira. ClienteAquecedor podem ser informados da
//            presenca ou ausencia da jarra, ou se o ciclo ja' 
//            terminou ou nao. cicloCompleto significa que uma jarra
//            vazia foi colocada no aquecedor apos o cafe ter sido feito.
//
///////////////////////////////////////////////////////////////////////////

public interface ClienteAquecedor 
{
    public void jarra();
    public void semJarra();
    public void cicloCompleto();
}
