///////////////////////////////////////////////////////////////////////////
//
// Projeto: CafeBemBrasileiro
// Arquivo: CafeBB_ControladorAquecedor.java
// Descricao: Esta classe implementa a interface ControladorAquecedor
//            para o harware especifico da cafeteira CafeBemBrasileiro 
//
///////////////////////////////////////////////////////////////////////////

public class CafeBB_ControladorAquecedor implements ControladorAquecedor 
{
  private Hardware cafeteiraCafeBB;

  public CafeBB_ControladorAquecedor(Hardware oHardware)
  {
    cafeteiraCafeBB= oHardware;
  }

  public void ligaAquecedor()
  {
    cafeteiraCafeBB.atuElementoAquecedor(Estado.aquecedorLigado);
  }

  public void desligaAquecedor()
  {
    cafeteiraCafeBB.atuElementoAquecedor(Estado.aquecedorDesligado);
  }

  public Estado estadoAquecedor()
  {
    return cafeteiraCafeBB.leEstadoAquecedor();
  }
}
