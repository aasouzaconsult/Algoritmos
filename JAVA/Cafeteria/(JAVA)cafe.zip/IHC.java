///////////////////////////////////////////////////////////////////////////
//
// Projeto: CafeBemBrasileiro
// Arquivo: IHC.java
// Descricao: Classe abstrata que implementa a interface homem computador
//            de uma cafeteira. Esta classe conhece clientes da IHC e o
//            controlador do hardware. Ela permite que classes externas 
//            notifiquem o estado do ciclo de confeccao do cafe
//
///////////////////////////////////////////////////////////////////////////

public abstract class IHC
{
    private ControladorIHC controlador;
    private ClienteIHC     cliente;

    public IHC(ControladorIHC oControlador, ClienteIHC oCliente)
    {
	controlador= oControlador;
	cliente= oCliente;
    }

    // Estimulos externos
    public abstract void cafeFeito();
    public abstract void cicloCompleto();

    // Interface para as subclasses
    protected ControladorIHC pegaControlador() { return controlador; }
    protected ClienteIHC pegaCliente() { return cliente; }
}
