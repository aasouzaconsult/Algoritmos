///////////////////////////////////////////////////////////////////////////
//
// Projeto: CafeBemBrasileiro
// Arquivo: Hardware.java
// Descricao: Classe que implementa a interface e encarna o 'hardware' da 
//            cafeteira.
//
///////////////////////////////////////////////////////////////////////////

public class Hardware implements Runnable
{
  //////////////////////////////////////////////////////////////////
  // Estados dos componentes do hardware
  private Estado estadoAquecedor;
  private Estado estadoVaporizador;
  private Estado estadoInterruptor;
  private Estado estadoElementoVaporizador;
  private Estado estadoElementoAquecedor;
  private Estado estadoLuzIndicadora;
  private Estado estadoValvulaPressao;

  // Estado dos reservatorios
  private int nivelDeAgua;
  private int nivelDeCafe;

  // Janela da interface
  private JanelaCafeteira jc;
  
  // Construtor define o estado da maquina ao ser 'ligada' e
  // e' idependente do estado inicial do software de controle
  public Hardware()
  {
    estadoAquecedor= Estado.jarraVazia;
    estadoVaporizador= Estado.vaporizadorVazio;
    estadoInterruptor= Estado.interruptorSolto;
    estadoElementoVaporizador= Estado.vaporizadorDesligado;
    estadoElementoAquecedor= Estado.aquecedorDesligado;
    estadoLuzIndicadora= Estado.indicadoraLigada;
    estadoValvulaPressao= Estado.valvulaFechada;

    nivelDeAgua= 0;
    nivelDeCafe= 0;

    jc= new JanelaCafeteira(this);
  }
  
  //////////////////////////////////////////////////////////////////
  // Metodos que implementam a interface do hardware. Esta 
  // interface e' usada pelo software de controle.
  
  // Aquecedor
  public Estado leEstadoAquecedor()
  {
    return estadoAquecedor;
  }

  public void atuElementoAquecedor(Estado modo)
  {
    if (modo.equals(Estado.aquecedorLigado) || 
	modo.equals(Estado.aquecedorDesligado))
      estadoElementoAquecedor= modo;
    jc.repaint();
  }
  
  
  // Vaporizador
  public Estado leEstadoVaporizador()
  {
    return estadoVaporizador;
  }

  public void atuEstadoElementoVaporizador(Estado modo)
  {
    if (modo.equals(Estado.vaporizadorLigado) || 
	modo.equals(Estado.vaporizadorDesligado))
      estadoElementoVaporizador= modo;
    jc.repaint();
  }


  // Interruptor
  public Estado leEstadoInterruptor()
  {
    Estado modo= estadoInterruptor;
    estadoInterruptor= Estado.interruptorSolto;
    return modo;
  }


  // Luz indicadora
  public void atuLuzIndicadora(Estado modo)
  {
    if (modo.equals(Estado.indicadoraLigada) || 
	modo.equals(Estado.indicadoraDesligada))
      estadoLuzIndicadora= modo;
    jc.repaint();
  }

  // Valvula de pressao
  public void atuValvulaPressao(Estado modo)
  {
    if (modo.equals(Estado.valvulaAberta) || 
	modo.equals(Estado.valvulaFechada))
      estadoValvulaPressao= modo;
    jc.repaint();
  }
  
  ////////////////////////////////////////////////////////////////////
  // Metodos usados na 'implementacao' do harware. Sao usados pela
  // interface grafica.
  public Estado leEstadoLuzIndicadora()
  {
    return estadoLuzIndicadora;
  }

  public Estado leEstadoElementoVaporizador()
  {
    return estadoElementoVaporizador;
  }

  public Estado leEstadoValvulaPressao()
  {
    return estadoValvulaPressao;
  }

  public Estado leEstadoElementoAquecedor()
  {
    return estadoElementoAquecedor;
  }

  public void colocaJarra()
  {
    if (nivelDeCafe == 0)
      estadoAquecedor= Estado.jarraVazia;
    else
      estadoAquecedor= Estado.jarraNaoVazia;
  }

  public void removeJarra()
  {
    estadoAquecedor= Estado.placaVazia;
  }

  public void pressionaBotao()
  {
    estadoInterruptor= Estado.interruptorPressionado;
  }

  public synchronized int pegaNivelDeAgua()
  {
    return nivelDeAgua;
  }

  public synchronized int pegaNivelDeCafe()
  {
    return nivelDeCafe;
  }

  public synchronized void ajustaNivelDeAgua(int nivel)
  {
    if ((nivel >= 0) && (nivel <= 100))
    {
      nivelDeAgua= nivel;
      if (nivelDeAgua == 0)
	estadoVaporizador= Estado.vaporizadorVazio;
      else
	estadoVaporizador= Estado.vaporizadorNaoVazio;
    } 
  }

  public synchronized void ajustaNivelDeCafe(int nivel)
  {
    if ((nivel >= 0) && (nivel <= 100))
    {
      nivelDeCafe= nivel;
      if (!estadoAquecedor.equals(Estado.placaVazia))
	if (nivelDeCafe == 0)
	  estadoAquecedor= Estado.jarraVazia;
	else
	  estadoAquecedor= Estado.jarraNaoVazia;
    } 
  }

  public synchronized void fazCafe()
  {
    if (estadoVaporizador.equals(Estado.vaporizadorNaoVazio) &&
	estadoElementoVaporizador.equals(Estado.vaporizadorLigado) &&
	estadoValvulaPressao.equals(Estado.valvulaFechada))
    {
      ajustaNivelDeAgua(pegaNivelDeAgua() - 1);
      ajustaNivelDeCafe(pegaNivelDeCafe() + 1);

      jc.repaint();
    }
  }

  ////////////////////////////////////////////////////////////////////
  // Implementacao do 'funcionamento' do hardware. E' totalmente 
  // independente do software de controle e engloba a interface
  // grafica.
  public void run()
  {
    // Inicia a vaporizacao da agua
    new Serpentina(this).start();
    // Inicia a interface gr�fica
    jc.show();
  } 
}

class Serpentina extends Thread
{
  private Hardware cafeteira;

  public Serpentina(Hardware oHardware)
  {
    cafeteira= oHardware;
  }

  public void run()
  {
    try {
      while (true)
      {
	sleep(1000);
	cafeteira.fazCafe();
      }
    } catch (InterruptedException e) {}
  }
}





