///////////////////////////////////////////////////////////////////////////
//
// Projeto: CafeBemBrasileiro
// Arquivo: Cafeteira.java
// Descricao: Esta classe e' o centro da comunicacao entre o
//            aquecedor, vaporizador e IHC. Ela implementa todas as tres
//            interfaces de clientes e direciona as mensagens entre
//            estas abstracoes.
//
///////////////////////////////////////////////////////////////////////////

public class Cafeteira 
     implements ClienteVaporizador, ClienteAquecedor, ClienteIHC
{
    private IHC         suaIHC;
    private Aquecedor   seuAquecedor;
    private Vaporizador seuVaporizador;

    // Construtor inicializa as partes da cafeteira
    public Cafeteira()
    {
	suaIHC= null;
	seuAquecedor= null;
	seuVaporizador= null;
    }

    //////////////////////////////////////////////////////////////////
    // ClienteIHC
    public boolean checaPronto()
    {
	return seuAquecedor.checaPronto() &&
	       seuVaporizador.checaPronto();
    }

    public void fazerCafe()
    {
	seuAquecedor.fazerCafe();
	seuVaporizador.fazerCafe();
    }
    
    
    //////////////////////////////////////////////////////////////////
    // ClienteVaporizador
    public void cafeFeito()
    {
	suaIHC.cafeFeito();
	seuAquecedor.cafeFeito();
    } 


    //////////////////////////////////////////////////////////////////
    // ClienteAquecedor
    public void jarra()
    {
	seuVaporizador.jarra();
    }

    public void semJarra()
    {
	seuVaporizador.semJarra();
    }

    public void cicloCompleto()
    {
	suaIHC.cicloCompleto();
    }

    /////////////////////////////////////////////////////////////////
    // Funcoes para efetivamente 'colar' os componentes
    public void ajustaIHC(IHC aIHC)
    {
	suaIHC= aIHC;
    }

    public void ajustaAquecedor(Aquecedor oAquecedor)
    {
	seuAquecedor= oAquecedor;
    }

    public void ajustaVaporizador(Vaporizador oVaporizador)
    {
	seuVaporizador= oVaporizador;
    }
}
