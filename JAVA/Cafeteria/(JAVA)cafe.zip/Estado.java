///////////////////////////////////////////////////////////////////////////
//
// Projeto: CafeBemBrasileiro
// Arquivo: Estado.java
// Descricao: Classe que engloba os estados dos componentes de hardware.
//
///////////////////////////////////////////////////////////////////////////

public class Estado
{
  // Estados dos componentes do hardware
  public static final Estado jarraNaoVazia=          new Estado(0); 
  public static final Estado jarraVazia=             new Estado(1); 
  public static final Estado placaVazia=             new Estado(2); 
  public static final Estado vaporizadorVazio=       new Estado(3);
  public static final Estado vaporizadorNaoVazio=    new Estado(4); 
  public static final Estado interruptorPressionado= new Estado(5); 
  public static final Estado interruptorSolto=       new Estado(6); 
  public static final Estado vaporizadorLigado=      new Estado(7);
  public static final Estado vaporizadorDesligado=   new Estado(8); 
  public static final Estado aquecedorLigado=        new Estado(9);
  public static final Estado aquecedorDesligado=     new Estado(10); 
  public static final Estado indicadoraLigada=       new Estado(11);
  public static final Estado indicadoraDesligada=    new Estado(12); 
  public static final Estado valvulaAberta=          new Estado(13);
  public static final Estado valvulaFechada=         new Estado(14);


  private int id;

  private Estado(int id)
  {
    this.id= id;
  }

  public boolean equals(Object obj)
  {
    return (obj != null) && (obj instanceof Estado) &&
      ((Estado)obj).id == id;
  }
}
