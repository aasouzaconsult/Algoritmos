///////////////////////////////////////////////////////////////////////////
//
// Projeto: CafeBemBrasileiro
// Arquivo: CafeBB_Vaporizador.java
// Descricao: Esta classe implementa o modelo de controle do vaporizador
//            da cafeteira CafeBemBrasileiro.
//
///////////////////////////////////////////////////////////////////////////

public class CafeBB_Vaporizador extends Vaporizador
{
  private EstadoVaporizador estado;

  public CafeBB_Vaporizador(ControladorVaporizador oControlador, 
			    ClienteVaporizador oCliente)
  {
    super(oControlador, oCliente);
    estado= EstadoVaporizador.naoFazendo;
    pegaControlador().naoJogaAgua();
  }

  ////////////////////////////////////////////////////////////////////
  // Estimulos externos
  public boolean checaPronto()
  {
    return pegaControlador().temAgua();
  }

  public void jarra()
  {
    if (estado.equals(EstadoVaporizador.fazendoJarRemovida))
    {
      estado= EstadoVaporizador.vaporizando;
      pegaControlador().jogaAgua(); 
    }
    else
      /* Ignora outros estados */;
  }

  public void semJarra()
  {
    if (estado.equals(EstadoVaporizador.vaporizando))
    {
      estado= EstadoVaporizador.fazendoJarRemovida;
      pegaControlador().naoJogaAgua(); 
    }
    else
      /* Ignora outros estados */;
  }

  public void fazerCafe()
  {
    if (estado.equals(EstadoVaporizador.naoFazendo))
    {
      estado= EstadoVaporizador.vaporizando;
      pegaControlador().jogaAgua(); 
    }
    else
      /* Ignora outros estados */;
  }

  ////////////////////////////////////////////////////////////////////
  // Eventos da Maquina de Estados
  public void cafeFeito()
  {
    if (estado.equals(EstadoVaporizador.vaporizando))
    {
      estado= EstadoVaporizador.naoFazendo;
      pegaControlador().naoJogaAgua();
      pegaCliente().cafeFeito();
    }
    else if (estado.equals(EstadoVaporizador.fazendoJarRemovida))
    {
      estado= EstadoVaporizador.naoFazendo;
      pegaCliente().cafeFeito();
    }
    else
      /* Ignora outros estados */;
  }

  ////////////////////////////////////////////////////////////////////
  // Liga ao programa principal
  public void verifica()
  {
    if ( !pegaControlador().temAgua() )
      cafeFeito();
  }
}

class EstadoVaporizador
{
  // Estados da maquina de estados do controle
  public static final EstadoVaporizador naoFazendo= 
                                                  new EstadoVaporizador(0); 
  public static final EstadoVaporizador vaporizando=
                                                  new EstadoVaporizador(1); 
  public static final EstadoVaporizador fazendoJarRemovida=
                                                  new EstadoVaporizador(2); 


  private int id;

  private EstadoVaporizador(int id)
  {
    this.id= id;
  }

  public boolean equals(Object obj)
  {
    return (obj != null) && (obj instanceof EstadoVaporizador) &&
      ((EstadoVaporizador)obj).id == id;
  }
}
