///////////////////////////////////////////////////////////////////////////
//
// Projeto: CafeBemBrasileiro
// Arquivo: ControladorIHC.java
// Descricao: Interface para todos os controladores de hardware da IHC.
//            O hardware da IHC pode ser comandado para mostrar ao usuario
//            que o cafe' esta' pronto ou que a cafeteira esta pronta para 
//            fazer cafe'. Ele tambem pode descobrir se o usuario iniciou
//            um ciclo de confeccao de cafe.
//
///////////////////////////////////////////////////////////////////////////

public interface ControladorIHC 
{
    public void indicaFim();
    public void indicaPronto();
    public boolean checaInicio();
}
