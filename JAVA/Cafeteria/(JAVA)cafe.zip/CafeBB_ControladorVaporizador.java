///////////////////////////////////////////////////////////////////////////
//
// Projeto: CafeBemBrasileiro
// Arquivo: CafeBB_ControladorVaporizador.java
// Descricao: Esta classe implementa a interface para o hardware do
//            vaporizador da cafeteira CafeBemBrasileiro
//
///////////////////////////////////////////////////////////////////////////

public class CafeBB_ControladorVaporizador implements ControladorVaporizador 
{
  private Hardware cafeteiraCafeBB;

  public CafeBB_ControladorVaporizador(Hardware oHardware)
  {
    cafeteiraCafeBB= oHardware;
  }
  
  public void jogaAgua()
  {
    cafeteiraCafeBB.atuEstadoElementoVaporizador(Estado.vaporizadorLigado); 
    cafeteiraCafeBB.atuValvulaPressao(Estado.valvulaFechada);
  }

  public void naoJogaAgua()
  {
    cafeteiraCafeBB.atuEstadoElementoVaporizador(Estado.vaporizadorDesligado); 
    cafeteiraCafeBB.atuValvulaPressao(Estado.valvulaAberta);
  }

  public boolean temAgua()
  {
    return cafeteiraCafeBB.leEstadoVaporizador().equals(
					        Estado.vaporizadorNaoVazio);
  }
}
