///////////////////////////////////////////////////////////////////////////
//
// Projeto: CafeBemBrasileiro
// Arquivo: JanelaCafeteira.java
// Descricao: Classe que implementa a interface grafica que permite 
//            manipular o 'hardware' e observar o funcionamento da 
//            cafeteira.
//
///////////////////////////////////////////////////////////////////////////

import java.awt.*;

public class JanelaCafeteira extends Frame
{
  private Hardware cafeteira;
  private Label labelVaporizador;
  private Label labelValvula;
  private Label labelAquecedor;
  private Label labelIndicadora;
  private Scrollbar scrollCafe;
  private Scrollbar scrollAgua;
  private Checkbox checkJarra;
  private Button buttonFazer;

  public JanelaCafeteira(Hardware oHardware)
  {
    super();

    // Ajusta referencia ao 'hardware'
    cafeteira= oHardware;

    // Prepara frame principal
    setSize(350,230);
    setResizable(false);
    setTitle("Cafeteira CafeBemBrasileiro");

    // Instacia componentes da interface
    labelVaporizador= new Label();
    labelValvula= new Label();
    labelAquecedor= new Label();
    labelIndicadora= new Label();
    scrollAgua= new Scrollbar(Scrollbar.HORIZONTAL, 0, 0, 0, 100);
    scrollCafe= new Scrollbar(Scrollbar.HORIZONTAL, 0, 0, 0, 100);
    checkJarra= new Checkbox("Jarra na cafeteira", true);
    buttonFazer= new Button("Fazer Caf�");

    // Prepara painel dos estados do hardware
    Panel p1= new Panel();
    p1.setLayout(new GridLayout(4,1));
    p1.add(labelVaporizador);
    p1.add(labelValvula);
    p1.add(labelAquecedor);
    p1.add(labelIndicadora);
    
    // Prepara o painel dos reservatorios
    Panel p2= new Panel();
    p2.setLayout(new GridLayout(2,1));
    p2.add(scrollAgua);
    p2.add(new Label("�gua no Reservat�rio"));
    Panel p3= new Panel();
    p3.setLayout(new GridLayout(2,1));
    p3.add(scrollCafe);
    p3.add(new Label("Caf� na Jarra"));
    Panel p4= new Panel();
    p4.setLayout(new GridLayout(3,1));
    p4.add(p2);
    p4.add(p3);
    p4.add(checkJarra);

    // Prepara o painel principal
    setLayout(new FlowLayout(FlowLayout.CENTER, 5, 10));
    add(p1);
    add(p4);
    add(buttonFazer);
  }

  public boolean handleEvent(Event e)
  {
    if (e.id == Event.WINDOW_DESTROY)
      System.exit(0);
    else if (e.id == Event.SCROLL_ABSOLUTE || e.id == Event.SCROLL_LINE_DOWN
	     || e.id == Event.SCROLL_LINE_UP || e.id == Event.SCROLL_PAGE_DOWN
	     || e.id == Event.SCROLL_PAGE_UP)
    {
      cafeteira.ajustaNivelDeAgua(scrollAgua.getValue());
      cafeteira.ajustaNivelDeCafe(scrollCafe.getValue());
    }
    return super.handleEvent(e);
  }

  public boolean action(Event evt, Object arg)
  {
    if (arg.equals("Fazer Caf�"))
    {
      cafeteira.pressionaBotao();
      repaint();
      return true;
    }
    else if (evt.target.equals(checkJarra))
    {
      if (checkJarra.getState())
	cafeteira.colocaJarra();
      else
	cafeteira.removeJarra();
      repaint();
      return true;
    }
    else
      return super.action(evt, arg);
  }

  public void repaint()
  {
    if (cafeteira.leEstadoElementoVaporizador().equals(
                                                 Estado.vaporizadorLigado))
      labelVaporizador.setText("Vaporizador Ligado");
    else
      labelVaporizador.setText("Vaporizador Desligado");

    if (cafeteira.leEstadoValvulaPressao().equals(Estado.valvulaAberta))
      labelValvula.setText("V�lvula de Press�o Aberta");
    else
      labelValvula.setText("V�lvula de Press�o Fechada");

    if (cafeteira.leEstadoElementoAquecedor().equals(Estado.aquecedorLigado))
      labelAquecedor.setText("Aquecedor Ligado");
    else
      labelAquecedor.setText("Aquecedor Desligado");

    if (cafeteira.leEstadoLuzIndicadora().equals(Estado.indicadoraLigada))
      labelIndicadora.setText("Luz Indicadora Ligada");
    else
      labelIndicadora.setText("Luz Indicadora Desligada");
      
    scrollAgua.setValue(cafeteira.pegaNivelDeAgua());
    scrollCafe.setValue(cafeteira.pegaNivelDeCafe());

    super.repaint();
  }
}
