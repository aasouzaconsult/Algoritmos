///////////////////////////////////////////////////////////////////////////
//
// Projeto: CafeBemBrasileiro
// Arquivo: ControladorAquecedor.java
// Descricao: Interface generica para o controlador de harware do 
//            aquecedor de uma cafeteira. O aquecedor pode ser ligado ou
//            desligado. Ele tambem pode informar se a jarra esta presente
//            e o seu estado. 
//
///////////////////////////////////////////////////////////////////////////

public interface ControladorAquecedor 
{
    public void ligaAquecedor();
    public void desligaAquecedor();
    public Estado estadoAquecedor();
}
