///////////////////////////////////////////////////////////////////////////
//
// Projeto: CafeBemBrasileiro
// Arquivo: CafeBB_Aquecedor.java
// Descricao: Esta classe implementa o controle do sistema do aquecedor
//            da cafeteira CafeBemBrasileiro.
//
///////////////////////////////////////////////////////////////////////////

public class CafeBB_Aquecedor extends Aquecedor
{
  private EstadoAquecedor estado;
  
  public CafeBB_Aquecedor(ControladorAquecedor oControlador, 
			  ClienteAquecedor oCliente)
  {
    super(oControlador, oCliente);
    estado= EstadoAquecedor.naoFazendo;
    pegaControlador().desligaAquecedor();
  }

  ////////////////////////////////////////////////////////////////////
  // Estimulos externos
  public void fazerCafe()
  {
    if (estado.equals(EstadoAquecedor.naoFazendo))
      estado= EstadoAquecedor.fazendoJarVazia;
    else
      /* Ignora outros estados */;
  }
  
  public void cafeFeito()
  {
    if (estado.equals(EstadoAquecedor.fazendoJarVazia))
    {
      estado= EstadoAquecedor.naoFazendo;
      pegaCliente().cicloCompleto();
    } 
    else if (estado.equals(EstadoAquecedor.fazendoAquecendo))
      estado= EstadoAquecedor.cafeFeito;
    else if (estado.equals(EstadoAquecedor.jarVaziaRemovida))
    {
      estado= EstadoAquecedor.naoFazendo;
      pegaCliente().cicloCompleto();
    }
    else if (estado.equals(EstadoAquecedor.jarCheiaRemovida))
      estado= EstadoAquecedor.feitoJarRemovida;
    else
      /* Ignora outros estados */;
  }

  public boolean checaPronto()
  {
    return pegaControlador().estadoAquecedor().equals(Estado.jarraVazia);
  }

  ////////////////////////////////////////////////////////////////////
  // Eventos da Maquina de Estados
  public void jarraVazia()
  {
    if (estado.equals(EstadoAquecedor.fazendoAquecendo))
    {
      estado= EstadoAquecedor.fazendoJarVazia;
      pegaControlador().desligaAquecedor();
    }
    else if (estado.equals(EstadoAquecedor.jarVaziaRemovida) ||
	     estado.equals(EstadoAquecedor.jarCheiaRemovida))
    {
      estado= EstadoAquecedor.fazendoJarVazia;
      pegaCliente().jarra();
    }
    else if (estado.equals(EstadoAquecedor.cafeFeito))
    {
      estado= EstadoAquecedor.naoFazendo;
      pegaControlador().desligaAquecedor();
      pegaCliente().cicloCompleto();
    }
    else if (estado.equals(EstadoAquecedor.feitoJarRemovida))
    {
      estado= EstadoAquecedor.naoFazendo;
      pegaCliente().cicloCompleto();
    }
    else
      /* Ignora outros estados */;
  }

  public void jarraNaoVazia()
  {
    if (estado.equals(EstadoAquecedor.fazendoJarVazia))
    {
      estado= EstadoAquecedor.fazendoAquecendo;
      pegaControlador().ligaAquecedor();
    }
    else if (estado.equals(EstadoAquecedor.jarVaziaRemovida) ||
	     estado.equals(EstadoAquecedor.jarCheiaRemovida))
    {
      estado= EstadoAquecedor.fazendoAquecendo;
      pegaControlador().ligaAquecedor();
      pegaCliente().jarra();
    }
    else if (estado.equals(EstadoAquecedor.feitoJarRemovida))
    {
      estado= EstadoAquecedor.cafeFeito;
      pegaControlador().ligaAquecedor();
    }
    else
      /* Ignora outros estados */;
  }
  
  public void placaVazia()
  {
    if (estado.equals(EstadoAquecedor.fazendoJarVazia))
    {
      estado= EstadoAquecedor.jarVaziaRemovida;
      pegaCliente().semJarra();
    }
    else if (estado.equals(EstadoAquecedor.fazendoAquecendo))
    {
      estado= EstadoAquecedor.jarCheiaRemovida;
      pegaCliente().semJarra();
      pegaControlador().desligaAquecedor();
    }
    else if (estado.equals(EstadoAquecedor.cafeFeito))
    {
      estado= EstadoAquecedor.feitoJarRemovida;
      pegaControlador().desligaAquecedor();
    }
    else
      /* Ignora outros estados */;
  }

  ////////////////////////////////////////////////////////////////////
  // Liga ao programa principal
  public void verifica()
  {
    if (pegaControlador().estadoAquecedor().equals(Estado.placaVazia))
      placaVazia();
    else if (pegaControlador().estadoAquecedor().equals(Estado.jarraVazia))
      jarraVazia();
    else if (pegaControlador().estadoAquecedor().equals(Estado.jarraNaoVazia))
      jarraNaoVazia();
  }
}

class EstadoAquecedor
{
  // Estados da maquina de estados do controle
  public static final EstadoAquecedor naoFazendo=      new EstadoAquecedor(0); 
  public static final EstadoAquecedor fazendoJarVazia= new EstadoAquecedor(1); 
  public static final EstadoAquecedor fazendoAquecendo=new EstadoAquecedor(2); 
  public static final EstadoAquecedor jarVaziaRemovida=new EstadoAquecedor(3);
  public static final EstadoAquecedor jarCheiaRemovida=new EstadoAquecedor(4); 
  public static final EstadoAquecedor cafeFeito=       new EstadoAquecedor(5); 
  public static final EstadoAquecedor feitoJarRemovida=new EstadoAquecedor(6); 


  private int id;

  private EstadoAquecedor(int id)
  {
    this.id= id;
  }

  public boolean equals(Object obj)
  {
    return (obj != null) && (obj instanceof EstadoAquecedor) &&
      ((EstadoAquecedor)obj).id == id;
  }
}
