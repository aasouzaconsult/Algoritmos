import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

public class TesteBD1 extends Frame implements ActionListener, ItemListener
{
  Panel p, p1, p2, p3;
  Button b1, b2, b3, b4, b5, b6;
  java.awt.List list1;
  TextField t1, t2, t3, t4, t5;
  Label l1, l2, l3, l4, l5, l6;
  String urlODBC = "jdbc:odbc:TesteBD";
  Vector listaDeFuncionarios;

  TesteBD1()
  {
    setTitle("Exemplo de Banco de Dados");
    setSize(640, 230);
    setResizable(false);

    addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){System.exit(0);}});
    p = new Panel();
    p.setLayout(new BorderLayout());
    p1 = new Panel();
    list1 = new java.awt.List(2,false);
    list1.addItemListener(this);
    l6 = new Label("Escolha: ");
    p1.add(l6);
    p1.add(list1);
    p.add(p1, "North");

    p2 = new Panel();
    p2.setLayout(new GridLayout(5,3));
    l1 = new Label("Nome: ", Label.RIGHT);
    l2 = new Label("Endere�o: ", Label.RIGHT);
    l3 = new Label("Sal�rio: ", Label.RIGHT);
    l4 = new Label("Data de contrata��o: ", Label.RIGHT);
    l5 = new Label("Optante (Sim/N�o): ", Label.RIGHT);
    t1 = new TextField(40);
    t2 = new TextField(40);
    t3 = new TextField(40);
    t4 = new TextField(40);
    t5 = new TextField(40);
    p2.add(l1); p2.add(t1);p2.add(new Label());
    p2.add(l2); p2.add(t2);p2.add(new Label());
    p2.add(l3); p2.add(t3);p2.add(new Label());
    p2.add(l4); p2.add(t4);p2.add(new Label());
    p2.add(l5); p2.add(t5);p2.add(new Label());
    p.add(p2, "Center");

    p3 = new Panel();
    b1 = new Button("Limpar");       b1.addActionListener(this); p3.add(b1);
    b2 = new Button("Incluir");      b2.addActionListener(this); p3.add(b2);
    b3 = new Button("Alterar");      b3.addActionListener(this); p3.add(b3);
    b4 = new Button("Excluir");      b4.addActionListener(this); p3.add(b4);
    b5 = new Button("Ler da Tabela");b5.addActionListener(this); p3.add(b5);
    b6 = new Button("Encerrar");     b6.addActionListener(this); p3.add(b6);
    p.add(p3, "South");

    add(p);
  }

  public void actionPerformed(ActionEvent evt)
  {
    String arg = evt.getActionCommand();
    if (arg.equals("Limpar"))
      limpar();
    else
      if (arg.equals("Ler da Tabela"))
        ler();
      else
        if (arg.equals("Excluir"))
          excluir();
        else
          if (arg.equals("Incluir"))
            incluir();
          else
            if (arg.equals("Alterar"))
              alterar();
            else
              if (arg.equals("Encerrar"))
                System.exit(0);
  }

  public void itemStateChanged(ItemEvent evt)
  {
    int qual = list1.getSelectedIndex();
    atualizaTela(qual);
  }

  public void limpar()
  {
    t1.setText("");
    t2.setText("");
    t3.setText("");
    t4.setText("");
    t5.setText("N�o");
  }

  public void ler()
  {
    String nome, endereco, contratacao;
    float salario;
    boolean optou;

    Funcionario f = null;
    listaDeFuncionarios = new Vector();
    list1.removeAll();

    try
    {
      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
      Connection con = DriverManager.getConnection (urlODBC, "", "");
      Statement stmt = con.createStatement();
      String query = "SELECT * FROM Funcionarios ORDER BY nome";
      ResultSet rs = stmt.executeQuery(query);

      while (rs.next())
      {
        nome        = rs.getString(1);
        endereco    = rs.getString(2);
        salario     = rs.getFloat(3);
        contratacao = rs.getString(4);
        optou       = rs.getBoolean(5);

        f = new Funcionario(nome,endereco,salario,contratacao,optou);
        listaDeFuncionarios.addElement(f);
        list1.add(f.devolveNome());
        atualizaTela(0);
      }
      stmt.close();
      con.close();
    }
    catch (SQLException ex)
    {
      String qualErro;
      qualErro = "Problemas no acesso ao banco de dados !\nAs mensagens retornadas s�o:"+
                 "\nSQLState: " + ex.getSQLState() +
                 "\nMensagem: " + ex.getMessage() +
                 "\nC�digo do erro: " + ex.getErrorCode();
      Erro e = new Erro(this, qualErro);
      e.setVisible(true);
    }
    catch (java.lang.Exception ex)
    {
      String qualErro;
      qualErro = "O driver JDBC:ODBC n�o foi encontrado !\nA mensagem de erro �:"+
                 "\nMensagem: " + ex.getMessage();
      Erro e = new Erro(this, qualErro);
      e.setVisible(true);
    }
  }

  public void atualizaTela(int i)
  {
    Funcionario f = (Funcionario) listaDeFuncionarios.get(i);
    t1.setText(f.devolveNome());
    t2.setText(f.devolveEndereco());
    t3.setText(Float.toString(f.devolveSalario()));
    t4.setText(f.devolveContratacao());
    t5.setText((f.devolveOptou()?"Sim":"N�o"));
  }

  public void incluir()
  {
    String nome, endereco, contratacao;
    float salario;
    boolean optou;

    nome = t1.getText();
    if (nome.length() == 0)
    {
      String qualErro;
      qualErro = "� obrigat�rio o fornecimento de um nome";
      Erro e = new Erro(this, qualErro);
      e.pack();
      e.setVisible(true);
    }
    else
    {
      if (t2.getText().length() == 0)
        endereco = "nao fornecido";
      else
        endereco = t2.getText();

      if (t3.getText().length() == 0)
        salario = 0;
      else
        salario = Float.parseFloat(t3.getText());

      if (t4.getText().length() == 0)
      {
        java.util.Date d = new java.util.Date();
        contratacao = d.toLocaleString();
      }
      else
        contratacao = t4.getText();

      if (t5.getText().toUpperCase().equals("SIM"))
        optou = true;
      else
        optou = false;

      try
      {
        Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        Connection con = DriverManager.getConnection (urlODBC, "", "");
        Statement stmt = con.createStatement();

        String query = "INSERT INTO Funcionarios (nome, endereco, salario, contratacao, optou) "+
                       "VALUES ('" + nome + "','" + endereco + "'," + salario +
                       ", '" + contratacao + "', " + optou + ")";
        System.out.println(query);

        int resultado = stmt.executeUpdate(query);

        stmt.close();
        con.close();

        if (resultado != 1)
        {
          String qualErro;
          qualErro = "Problemas na inser��o do novo funcionario";
          Erro e = new Erro(this, qualErro);
          e.setVisible(true);
        }
        else
        {
          Funcionario f = new Funcionario(nome,endereco,salario,contratacao,optou);
          listaDeFuncionarios.addElement(f);
          list1.add(f.devolveNome());
          atualizaTela(0);
        }
      }
      catch (SQLException ex)
      {
        String qualErro;
        qualErro = "Problemas no acesso ao banco de dados !\nAs mensagens retornadas s�o:"+
                   "\nSQLState: " + ex.getSQLState() +
                   "\nMensagem: " + ex.getMessage() +
                   "\nC�digo do erro: " + ex.getErrorCode();
        Erro e = new Erro(this, qualErro);
        e.setVisible(true);
      }
      catch (java.lang.Exception ex)
      {
        String qualErro;
        qualErro = "O driver JDBC:ODBC n�o foi encontrado !\nA mensagem de erro �:"+
                   "\nMensagem: " + ex.getMessage();
        Erro e = new Erro(this, qualErro);
        e.setVisible(true);
      }
    }
  }

  public void alterar()
  {
    String nome, endereco, contratacao;
    float salario;
    boolean optou;

    nome = t1.getText();
    if (nome.length() == 0)
    {
      String qualErro;
      qualErro = "N�o d� para alterar se n�o for fornecido um nome !";
      Erro e = new Erro(this, qualErro);
      e.setVisible(true);
    }
    else
    {
      if (t2.getText().length() == 0)
        endereco = "nao fornecido";
      else
        endereco = t2.getText();

      if (t3.getText().length() == 0)
        salario = 0;
      else
        salario = Float.parseFloat(t3.getText());

      if (t4.getText().length() == 0)
      {
        java.util.Date d = new java.util.Date();
        contratacao = d.toLocaleString();
      }
      else
        contratacao = t4.getText();

      if (t5.getText().toUpperCase().equals("SIM"))
        optou = true;
      else
        optou = false;

      try
      {
        Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        Connection con = DriverManager.getConnection (urlODBC, "", "");
        Statement stmt = con.createStatement();

        String query = "UPDATE Funcionarios SET nome='"+nome+"', endereco='"+endereco+
                       "', salario="+salario+", contratacao='"+contratacao+
                       "', optou="+optou+" WHERE nome='"+nome+"'";

        System.out.println(query);

        int resultado = stmt.executeUpdate(query);

        if (resultado != 1)
        {
          String qualErro;
          qualErro = "Problemas na altera��o dos dados do funcionario";
          Erro e = new Erro(this, qualErro);
          e.setVisible(true);
        }
        stmt.close();
        con.close();
      }
      catch (SQLException ex)
      {
        String qualErro;
        qualErro = "Problemas no acesso ao banco de dados !\nAs mensagens retornadas s�o:"+
                   "\nSQLState: " + ex.getSQLState() +
                   "\nMensagem: " + ex.getMessage() +
                   "\nC�digo do erro: " + ex.getErrorCode();
        Erro e = new Erro(this, qualErro);
        e.setVisible(true);
      }
      catch (java.lang.Exception ex)
      {
        String qualErro;
        qualErro = "O driver JDBC:ODBC n�o foi encontrado !\nA mensagem de erro �:"+
                   "\nMensagem: " + ex.getMessage();
        Erro e = new Erro(this, qualErro);
        e.setVisible(true);
      }
    }
  }

  public void excluir()
  {
    String nome = t1.getText();
    if (nome.length() == 0)
    {
      String qualErro;
      qualErro = "N�o d� para excluir se n�o for fornecido um nome !";
      Erro e = new Erro(this, qualErro);
      e.setVisible(true);
    }
    else
    {
      try
      {
        Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        Connection con = DriverManager.getConnection (urlODBC, "", "");
        Statement stmt = con.createStatement();

        String query = "DELETE * FROM Funcionarios WHERE nome='"+nome+"'";

        System.out.println(query);

        int resultado = stmt.executeUpdate(query);

        stmt.close();
        con.close();

        if (resultado != 1)
        {
          String qualErro;
          qualErro = "Problemas na exclus�o dos dados do funcionario";
          Erro e = new Erro(this, qualErro);
          e.setVisible(true);
        }
        else
        {
          listaDeFuncionarios.remove(list1.getSelectedIndex());
          list1.remove(nome);
        }
        limpar();
      }
      catch (SQLException ex)
      {
        String qualErro;
        qualErro = "Problemas no acesso ao banco de dados !\nAs mensagens retornadas s�o:"+
                   "\nSQLState: " + ex.getSQLState() +
                   "\nMensagem: " + ex.getMessage() +
                   "\nC�digo do erro: " + ex.getErrorCode();
        Erro e = new Erro(this, qualErro);
        e.setVisible(true);
      }
      catch (java.lang.Exception ex)
      {
        String qualErro;
        qualErro = "O driver JDBC:ODBC n�o foi encontrado !\nA mensagem de erro �:"+
                   "\nMensagem: " + ex.getMessage();
        Erro e = new Erro(this, qualErro);
        e.setVisible(true);
      }
    }
  }

  public static void main(String args[])
  {
    TesteBD1 t = new TesteBD1();
    t.setVisible(true);
  }
}

class Funcionario
{
  String nome;
  String endereco;
  float salario;
  String contratacao;
  boolean optou;
  Funcionario(String n, String e, float s, String c, boolean o)
  {
    nome = n;
    endereco = e;
    salario = s;
    optou = o;
    contratacao = c;
  }
  public String devolveNome()
  {
    return nome;
  }
  public String devolveEndereco()
  {
    return endereco;
  }
  public float devolveSalario()
  {
    return salario;
  }
  public boolean devolveOptou()
  {
		return optou;
	}
  public String devolveContratacao()
  {
		return contratacao;
	}
	public String toString()
	{
		return ("\nNome............: " + nome +
		        "\nEndereco........: " + endereco +
            "\nSalario.........: " + salario +
            "\nData contratacao: " + contratacao +
            "\nOptante.........: " + ((optou)?"Sim":"N�o"));
  }
}

class Erro extends Dialog implements ActionListener
{
  private TextArea ta;
  private Panel p;
  private Button bOK;

  Erro(Frame f, String mensagem)
  {
    super(f);
    setVisible(true);
    setTitle("Aten��o !");
    this.setBounds(50, 50, 400, 200);
    setLayout(new BorderLayout());
    ta = new TextArea(5,80);
    ta.setText(mensagem);
    ta.setEditable(false);
    bOK = new Button("Fechar este aviso");
    bOK.addActionListener(this);
    add(ta, "Center");
    p = new Panel();
    p.add(bOK);
    add(p, "South");
  }
  public void actionPerformed (ActionEvent evt)
  {
    String arg = evt.getActionCommand();
    if (arg.equals("Fechar este aviso"))
      setVisible(false);
  }
}
