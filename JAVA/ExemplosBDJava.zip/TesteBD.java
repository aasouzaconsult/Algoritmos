import java.sql.*;
class TesteBD
{
  public static void main (String args[])
  {
    String url = "jdbc:odbc:meuBD";
    String query = "SELECT * FROM Tabela1";
    String query2="INSERT INTO Tabela1(campo1,campo2)VALUES('VITOR','KARINA')";
    try
    {
      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
      Connection con = DriverManager.getConnection (url, "", "");
      Statement stmt = con.createStatement();
      int resultado = stmt.executeUpdate(query2);
      ResultSet rs = stmt.executeQuery(query);
      printResultSet(rs);
      rs.close();
      stmt.close();
      con.close();
    }
    catch (SQLException ex)
    {
      System.out.println ("SQLException:");
      while (ex != null)
      {
        System.out.println ("SQLState: " + ex.getSQLState());
        System.out.println ("Message:  " + ex.getMessage());
        System.out.println ("Vendor:   " + ex.getErrorCode());
        ex = ex.getNextException();
        System.out.println ("");
      }
    }
    catch (java.lang.Exception ex)
    {
      ex.printStackTrace();
    }
  }

  private static void printResultSet (ResultSet rs) throws SQLException
  {
    int numCols = rs.getMetaData().getColumnCount();
    while (rs.next())
    {
      for (int i = 1; i <= numCols; i++)
      {
        System.out.println(rs.getString(i) + " | ");
      }
      System.out.println();
    }
  }
}